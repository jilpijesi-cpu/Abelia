package com.mythos.app.ui

import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mythos.app.ProviderChoice
import com.mythos.app.UserSettings
import com.mythos.app.agent.StepStatus
import kotlin.math.exp
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow

private const val LABEL_HOLD_MS = 500L

@Composable
private fun rememberHeldLabel(target: String): String {
    var shown by remember { mutableStateOf(target) }
    var since by remember { mutableLongStateOf(0L) }
    val queue = remember { Channel<String>(4, BufferOverflow.DROP_OLDEST) }
    LaunchedEffect(target) { queue.trySend(target) }
    LaunchedEffect(queue) {
        for (next in queue) {
            if (next == shown) continue
            val wait = LABEL_HOLD_MS - (SystemClock.uptimeMillis() - since)
            if (wait > 0) delay(wait)
            shown = next
            since = SystemClock.uptimeMillis()
        }
    }
    return shown
}

@Composable
fun ChatScreen(
    chat: List<ChatItem>,
    running: Boolean,
    settings: UserSettings,
    incognito: Boolean,
    text: String,
    onTextChange: (String) -> Unit,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onNewChat: () -> Unit,
    onMenu: () -> Unit,
    onPickProvider: (ProviderChoice) -> Unit,
    onOpenSettings: (SettingsSection) -> Unit,
    onExport: () -> Unit,
    ws: WorkspaceHooks,
    attachments: List<Attachment>,
    onAttach: (AttachSource) -> Unit,
    onRemoveAttachment: (Attachment) -> Unit,
    onUndo: (ChangesItem) -> Unit,
    loadDiff: suspend (ChangesItem, String) -> String,
    onOpenFile: (ChangesItem, String, Boolean) -> Unit = { _, _, _ -> },
    onOpenPath: (String, Boolean) -> Unit = { _, _ -> },
    onSendEmail: (EmailDraftItem) -> Unit = {},
    onEditEmail: (EmailDraftItem, List<String>, List<String>, String, String) -> Unit = { _, _, _, _, _ -> },
    activity: LiveActivity? = null,
    subAgents: SubAgentStatus = SubAgentStatus(),
    chatTitle: String? = null,
    onRenameChat: (String) -> Unit = {},
    onDeleteChat: () -> Unit = {},
) {
    var renameOpen by rememberSaveable { mutableStateOf(false) }
    var menuOpen by rememberSaveable { mutableStateOf(false) }
    var sheet by rememberSaveable { mutableStateOf(SheetKind.NONE) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val initialIds = remember { chat.map { it.id }.toSet() }
    val played = remember { HashSet<Long>() }

    val allBlocks = toBlocks(chat)
    var released by remember { mutableIntStateOf(allBlocks.size) }
    if (released > allBlocks.size) released = allBlocks.size
    var releasedAt by remember { mutableLongStateOf(0L) }
    val latestBlocks by rememberUpdatedState(allBlocks)
    LaunchedEffect(allBlocks.size) {
        if (released > allBlocks.size) released = allBlocks.size
        while (released < latestBlocks.size) {
            val list = latestBlocks
            if (released > list.size) {
                released = list.size
                break
            }
            val prev = list.getOrNull(released - 1)
            if (prev != null && list[released] !is UserBlock) {
                val now = SystemClock.uptimeMillis()
                val doneAt = (prev as? TextBlock)?.let { RevealClock.doneAt(it.item.id) }
                if (!releaseReady(prev, now, releasedAt, doneAt)) {
                    delay(40L)
                    continue
                }
            }
            (prev as? TextBlock)?.let { RevealClock.clear(it.item.id) }
            released++
            releasedAt = SystemClock.uptimeMillis()
        }
    }
    val blocks = allBlocks.take(released.coerceAtMost(allBlocks.size))
    val lastTextId = (blocks.lastOrNull() as? TextBlock)?.item?.id
    var settledId by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(lastTextId, running) {
        if (lastTextId == null || !running) return@LaunchedEffect
        while (true) {
            val d = RevealClock.doneAt(lastTextId)
            settledId = if (d != null && SystemClock.uptimeMillis() - d >= TEXT_PAUSE_MS) lastTextId else null
            delay(40L)
        }
    }
    val extraLive = needsExtraLive(blocks, running, activity, textSettled = lastTextId == null || settledId == lastTextId)
    val baseLabel = liveLabel(blocks, activity)
    val lastTool = (blocks.lastOrNull() as? StepsBlock)?.items?.lastOrNull() as? ToolItem
    var thinkTick by remember { mutableIntStateOf(0) }
    val waiting = running && baseLabel == THINKING_LABEL
    LaunchedEffect(waiting, lastTool?.id) {
        thinkTick = 0
        while (waiting) {
            delay(THINK_ROTATE_MS)
            thinkTick++
        }
    }
    val label = rememberHeldLabel(if (waiting) thinkingPhrase(lastTool, thinkTick) else baseLabel)

    var stalled by remember { mutableStateOf(false) }
    val progress = progressKey(chat, activity)
    LaunchedEffect(progress, running) {
        stalled = false
        if (running) {
            delay(STALL_MS)
            stalled = true
        }
    }
    // Detik sejak kemajuan terakhir: hitungan kecil di samping label supaya menunggu model yang lambat tampak bekerja, bukan macet.
    var idleSecs by remember { mutableIntStateOf(0) }
    LaunchedEffect(progress, running) {
        idleSecs = 0
        while (running) {
            delay(1_000L)
            idleSecs++
        }
    }
    var subTick by remember { mutableIntStateOf(0) }
    val subActive = running && subAgents.running.isNotEmpty()
    LaunchedEffect(subActive) {
        subTick = 0
        while (subActive) {
            delay(THINK_ROTATE_MS)
            subTick++
        }
    }
    val subText = if (subActive) subAgents.phrase(subTick) else null
    val showStall = running && (stalled || subText != null)
    val total = blocks.size + (if (extraLive) 1 else 0) + (if (showStall) 1 else 0)

    // Chat baru dari beranda / pesan baru: pesan pengguna disematkan di ATAS layar dan jawaban mengalir di bawahnya lalu layar mengikuti teks begitu jawaban memenuhi layar; pengguna bebas menggeser kapan saja.
    val startsPinned = remember {
        PIN_USER_MESSAGE_ON_SEND && ((running && allBlocks.lastOrNull() is UserBlock) || (allBlocks.size == 1 && allBlocks[0] is UserBlock))
    }
    var stick by remember { mutableStateOf(!startsPinned) }
    var pinned by remember { mutableStateOf<Long?>(if (startsPinned) (allBlocks.lastOrNull() as? UserBlock)?.item?.id else null) }
    val userDragged = remember { booleanArrayOf(false) }
    val pinAnimating = remember { booleanArrayOf(false) }
    val lastUserIdx = blocks.indexOfLast { it is UserBlock }
    val lastUserId = (blocks.getOrNull(lastUserIdx) as? UserBlock)?.item?.id
    val lastUserIdxNow by rememberUpdatedState(lastUserIdx)
    val totalNow by rememberUpdatedState(total)
    // Ruang kosong di ujung daftar agar pesan pengguna bisa naik ke atas walau jawabannya masih pendek (nilai mentah).
    var rawTail by remember { mutableIntStateOf(0) }
    LaunchedEffect(lastUserId) {
        if (PIN_USER_MESSAGE_ON_SEND && lastUserId != null && lastUserId !in initialIds && lastUserId != pinned) {
            stick = false
            pinned = lastUserId
        }
    }
    LaunchedEffect(listState) {
        snapshotFlow {
            val info = listState.layoutInfo
            val ui = lastUserIdxNow
            val n = totalNow
            if (ui < 0) return@snapshotFlow 0
            // patch14: jumlah item di hasil ukur (n item + 1 spacer) belum tentu sama dengan daftar yang baru disusun. Pada bingkai peralihan itu
            // "after.size < n - ui" salah menyimpulkan 0, spacer ambruk, daftar terjepit ke atas (terlihat sebagai kilasan isi lama), lalu pulih.
            if (info.totalItemsCount != n + 1) return@snapshotFlow -1
            val after = info.visibleItemsInfo.filter { it.key != TAIL_KEY && it.index >= ui }
            when {
                after.none { it.index == ui } -> -1                       // pesan pengguna di luar layar: pertahankan nilai lama
                after.size < n - ui -> 0                                   // isi sudah lebih panjang dari layar
                else -> {
                    val viewport = info.viewportSize.height - info.beforeContentPadding - info.afterContentPadding
                    (viewport - after.sumOf { it.size }).coerceAtLeast(0)
                }
            }
        }.collect { v -> if (v >= 0) rawTail = v }
    }
    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect {
            if (it is DragInteraction.Start) {
                userDragged[0] = true
                pinned = null
            }
        }
    }
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { moving ->
            if (!moving && userDragged[0]) {
                userDragged[0] = false
                stick = !listState.canScrollForward && rawTail == 0
            }
        }
    }
    LaunchedEffect(pinned) {
        val id = pinned ?: return@LaunchedEffect
        val idx = latestBlocks.indexOfFirst { it is UserBlock && it.item.id == id }
        // Satu gulir halus saja. Koreksi setelah ruang kosong di ujung terhitung ditangani LaunchedEffect(rawTail) di bawah.
        if (idx >= 0 && !atItemTop(listState, idx)) {
            pinAnimating[0] = true
            try { listState.animateScrollToItem(idx) } finally { pinAnimating[0] = false }
            // Satu koreksi akhir tepat setelah animasi: ruang kosong di ujung sudah terhitung, selisihnya hanya beberapa piksel.
            // Dulu koreksi ini jatuh acak saat teks pertama tiba dan terlihat sebagai lompatan.
            withFrameNanos { }
            withFrameNanos { }
            val idx2 = latestBlocks.indexOfFirst { it is UserBlock && it.item.id == id }
            if (pinned == id && idx2 >= 0 && !listState.isScrollInProgress && !atItemTop(listState, idx2)) listState.scrollToItem(idx2)
        }
    }
    LaunchedEffect(rawTail) {
        val id = pinned ?: return@LaunchedEffect
        if (pinAnimating[0] || listState.isScrollInProgress) return@LaunchedEffect
        val idx = latestBlocks.indexOfFirst { it is UserBlock && it.item.id == id }
        if (idx >= 0 && !atItemTop(listState, idx)) listState.scrollToItem(idx)
    }
    // Setelah jawaban memenuhi layar (tak ada lagi ruang kosong di bawahnya), layar mulai mengikuti teks yang mengalir.
    // Hanya jika pengguna belum menyentuh daftar: begitu pengguna menggeser, pin dilepas dan kendali sepenuhnya miliknya
    // (kembali mengikuti bila ia menggulir ke dasar atau menekan tombol turun).
    var roomSeenFor by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(rawTail, pinned) {
        val id = pinned ?: return@LaunchedEffect
        if (rawTail > 0) {
            roomSeenFor = id
        } else if (shouldStartFollowing(id, roomSeenFor, rawTail, userDragged[0])) {
            stick = true
            pinned = null
        }
    }
    // Mengikuti dasar daftar saat teks mengalir: SATU pelari yang bergerak tiap bingkai dengan gerak meredam halus.
    // Dulu: gulir 4000 px sekali tiap 3 bingkai + animateScrollToItem tiap blok baru (menahan gulir ~300 ms lalu menyusul
    // dengan lompatan), sehingga layar naik per baris. dispatchRawDelta tidak memakai mutex gulir, jadi tidak saling membatalkan.
    val wake = remember { Channel<Unit>(Channel.CONFLATED) }
    val stickNow by rememberUpdatedState(stick)
    val follow = remember { { wake.trySend(Unit); Unit } }
    LaunchedEffect(Unit) {
        // Membuka chat lama: langsung ke dasar satu kali (tanpa animasi panjang).
        if (stick && totalNow > 0) listState.scrollToItem(maxOf(0, totalNow - 1))
    }
    LaunchedEffect(total) { if (total > 0) wake.trySend(Unit) }
    LaunchedEffect(listState) {
        for (ping in wake) {
            var last = withFrameNanos { it }
            var idle = 0
            while (idle < 24) {
                val now = withFrameNanos { it }
                val dt = ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                last = now
                if (!stickNow || listState.isScrollInProgress) {
                    idle++
                    continue
                }
                val dist = distanceToBottom(listState)
                if (dist <= 0f) {
                    idle++
                    continue
                }
                idle = 0
                val step = (dist * (1f - exp(-16f * dt))).coerceAtLeast(1f).coerceAtMost(dist)
                listState.dispatchRawDelta(step)
            }
        }
    }

    val density = LocalDensity.current
    var inputPx by remember { mutableIntStateOf(0) }
    val inputDp = with(density) { inputPx.toDp() }
    val tailDp = with(density) { (if (stick) 0 else rawTail).toDp() }
    // Latar polos: bilah atas & area input solid seperti semula. Latar gambar/gradien/foto: keduanya TRANSPARAN (warna solid tidak akan
    // pernah persis sama dengan gambar di belakangnya dan tampak seperti pita), dan teks yang tergulir dipudarkan dengan mask pada daftar.
    val solidBg = AppBackground.option.kind == BgKind.SOLID
    val bgTop = if (solidBg) AppBackground.topColor else Color.Transparent
    val bgBottom = if (solidBg) AppBackground.bottomColor else Color.Transparent
    val topBarPx = with(density) { (WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 60.dp).toPx() }
    val fadePx = with(density) { 14.dp.toPx() }
    val firstUser = chat.firstOrNull { it is UserItem } as? UserItem
    val derivedTitle = remember(firstUser?.id) { firstUser?.text?.lineSequence()?.firstOrNull().orEmpty().trim().take(48) }
    val title = chatTitle ?: derivedTitle
    // Daftar chat memenuhi SELURUH layar; bilah atas dan kartu input mengambang di atasnya, jadi teks tembus di belakang ikon
    // dan satu-satunya pembatas adalah tepi layar HP.
    Box(Modifier.fillMaxSize().appBackground()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().then(
                if (solidBg) Modifier else Modifier
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        val h = size.height
                        // Pudar berakhir tepat di tepi atas blok kartu input (14 dp di bawah puncak area input, sesuai Spacer pudar di bawah).
                        val bottomEdge = (h - inputPx + fadePx).coerceAtLeast(topBarPx + 2 * fadePx)
                        val stops = arrayOf(
                            0f to Color.Transparent,
                            (topBarPx / h).coerceIn(0f, 1f) to Color.Transparent,
                            ((topBarPx + fadePx) / h).coerceIn(0f, 1f) to Color.Black,
                            ((bottomEdge - fadePx) / h).coerceIn(0f, 1f) to Color.Black,
                            (bottomEdge / h).coerceIn(0f, 1f) to Color.Transparent,
                            1f to Color.Transparent,
                        )
                        drawRect(Brush.verticalGradient(colorStops = stops), blendMode = BlendMode.DstIn)
                    }
            ),
            contentPadding = PaddingValues(
                top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 60.dp + 12.dp,
                bottom = inputDp + 8.dp
            )
        ) {
                itemsIndexed(blocks, key = { i, b -> if (running && i == blocks.lastIndex && b is StepsBlock) LIVE_SLOT_KEY else blockKey(b) }) { i, b ->
                    // Baris langkah (StepsBlock) berganti kunci dari LIVE_SLOT_KEY ke kunci biasa saat selesai: dengan fade ia akan meredup lalu muncul lagi (kedipan),
                    // jadi untuknya hanya penempatan yang dianimasikan.
                    val steps = b is StepsBlock
                    Box(Modifier.animateItem(fadeInSpec = if (steps) null else FLOW_FADE_IN, placementSpec = FLOW_PLACE, fadeOutSpec = if (steps) null else FLOW_FADE_OUT)) {
                    when (b) {
                        is UserBlock -> ItemView(b.item, active = false, animate = false, onTick = follow)
                        is StepsBlock -> StepsView(b.items, live = running && i == blocks.lastIndex, label = label, isWaiting = waiting, afterUser = i > 0 && blocks[i - 1] is UserBlock, elapsed = if (waiting) idleSecs else 0)
                        is TextBlock -> {
                            val id = b.item.id
                            DisposableEffect(id) { onDispose { played.add(id) } }
                            TextItemView(
                                b.item, animate = id !in initialIds && id !in played, onTick = follow,
                                sources = if (b.item is FinalItem) sourcesFor(chat, id) else AnswerSources(emptyList(), emptyList()),
                                onRetry = if (b.item is FinalItem && !running) ({ lastUserText(chat)?.let(onSend); Unit }) else null
                            )
                        }
                        is TailBlock -> {
                            val id = b.item.id
                            DisposableEffect(id) { onDispose { played.add(id) } }
                            ItemView(
                                b.item, active = false, animate = id !in initialIds && id !in played, onTick = follow,
                                canUndo = !running, onUndo = onUndo, loadDiff = loadDiff, onOpenFile = onOpenFile,
                                onOpenPath = onOpenPath, onSendEmail = onSendEmail, onEditEmail = onEditEmail
                            )
                        }
                    }
                    }
                }
                if (extraLive) {
                    item(key = LIVE_SLOT_KEY) {
                        Box(Modifier.animateItem(fadeInSpec = FLOW_FADE_IN, placementSpec = FLOW_PLACE, fadeOutSpec = FLOW_FADE_OUT)) {
                            StepsView(emptyList(), live = true, label = label, isWaiting = waiting, afterUser = blocks.lastOrNull() is UserBlock, elapsed = if (waiting) idleSecs else 0)
                        }
                    }
                }
                if (showStall) {
                    item(key = "stalled") { StallNote(subText ?: STALL_TEXT, tight = extraLive || blocks.lastOrNull() is StepsBlock) }
                }
                item(key = TAIL_KEY) { Spacer(Modifier.height(tailDp)) }
        }
        // Bilah atas SOLID (tidak tembus pandang): pesan yang tergulir ke atas terpotong rapi di bawah bilah, tidak lagi menumpuk dengan judul
        // dan ikon. Di bawahnya ada dasar pudar tipis supaya pemotongannya halus.
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().background(bgTop)) {
            TopBar {
                // PATCH38: judul sesi di TENGAH bilah atas (tengah lebar layar, bukan tengah tinggi layar), memakai font tetap
                // (serif tebal) supaya mudah dibedakan dari teks lain. Padding kiri-kanan sama (100 dp) agar tetap di tengah dan
                // tidak menabrak dua ikon di kanan (2 x 48 dp).
                Text(
                    title,
                    modifier = Modifier.align(Alignment.Center).padding(horizontal = 100.dp),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, letterSpacing = 0.3.sp, color = MythosColors.Ink)
                )
                Row(Modifier.align(Alignment.CenterEnd), verticalAlignment = Alignment.CenterVertically) {
                    GlyphButton(onNewChat, label = "Chat baru") { EditGlyph() }
                    Box {
                        GlyphButton({ menuOpen = true }, label = "Menu lainnya") { HeaderKebabGlyph() }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            // Menu titik tiga HANYA untuk sesi chat ini. Pengaturan umum (model, izin, Google, tampilan) ada di sidebar > Pengaturan.
                            DropdownMenuItem(text = { Text("Ubah judul sesi") }, onClick = { menuOpen = false; renameOpen = true })
                            DropdownMenuItem(text = { Text("Ekspor proyek (ZIP)") }, onClick = { menuOpen = false; onExport() })
                            DropdownMenuItem(text = { Text("Hapus sesi ini") }, onClick = { menuOpen = false; onDeleteChat() })
                        }
                    }
                }
            }
            }
            Box(Modifier.fillMaxWidth().height(14.dp).background(Brush.verticalGradient(0f to bgTop, 1f to bgTop.copy(alpha = 0f))))
        }
        if (renameOpen) {
            var draft by remember { mutableStateOf(title) }
            AlertDialog(
                onDismissRequest = { renameOpen = false },
                title = { Text("Ubah judul sesi") },
                text = {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it.take(60) },
                        singleLine = true,
                        placeholder = { Text("Judul sesi") },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = { TextButton(onClick = { onRenameChat(draft); renameOpen = false }) { Text("Simpan") } },
                dismissButton = { TextButton(onClick = { renameOpen = false }) { Text("Batal") } },
            )
        }
        if (!stick && listState.canScrollForward) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = inputDp + 12.dp)
                    .shadow(4.dp, CircleShape, ambientColor = Color(0x14000000), spotColor = Color(0x22000000))
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .clickable {
                        stick = true
                        pinned = null
                        scope.launch {
                            listState.scrollToItem(maxOf(0, total - 1))
                            listState.scrollBy(100_000f)
                        }
                    },
                contentAlignment = Alignment.Center
            ) { ArrowDownGlyph() }
        }
        val chip = uiModelChip(settings)
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .onSizeChanged { inputPx = it.height }
        ) {
            // Pudar halus hanya di tepi atas; mulai dari sini ke bawah (kartu input + area tombol navigasi) latar SOLID,
            // supaya teks yang tergulir tidak tembus terlihat di belakang kartu atau di belakang tombol navigasi.
            Spacer(Modifier.fillMaxWidth().height(14.dp).background(Brush.verticalGradient(listOf(bgBottom.copy(alpha = 0f), bgBottom))))
            Column(Modifier.fillMaxWidth().background(bgBottom)) {
            MythosInputCard(
                text = text,
                onText = onTextChange,
                placeholder = "Chat Mythos...",
                modelName = chip.first,
                effort = chip.second,
                provider = chipProvider(settings),
                running = running,
                onPlus = { sheet = SheetKind.ADD },
                onModel = { sheet = SheetKind.MODEL },
                onMic = { sheet = SheetKind.VOICE },
                onSend = { if (text.isNotBlank() || attachments.isNotEmpty()) onSend(text.trim()) },
                onStop = onStop,
                dashed = false,
                attachments = attachments,
                onRemoveAttachment = onRemoveAttachment,
                nav = NavShortcuts(ws.onNavProjects, ws.onNavCode, ws.onNavArtifacts, ws.onNavBrowser, ws.onNavHistory, ws.onNavSettings),
            )
            Spacer(Modifier.fillMaxWidth().windowInsetsBottomHeight(WindowInsets.navigationBars))
            }
        }
    }
    MythosSheets(sheet, { sheet = SheetKind.NONE }, { sheet = it }, settings, onPickProvider, onOpenSettings, ws, onAttach)
}

@Composable
private fun ActivityRow(
    live: Boolean,
    label: String,
    icon: GroupIcon,
    expandable: Boolean,
    expanded: Boolean,
    onToggle: () -> Unit,
    elapsed: Int = 0,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clickable(enabled = expandable, onClick = onToggle)
            .padding(start = ChatMargin + ACTIVITY_INSET, end = ChatMargin + ACTIVITY_INSET),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(74.px)) {
            Crossfade(targetState = live, animationSpec = tween(280, easing = FastOutSlowInEasing), label = "lead") { l ->
                when {
                    l -> LoaderDots()
                    icon == GroupIcon.TERMINAL -> TerminalGlyph()
                    else -> ClockGlyph()
                }
            }
        }
        AnimatedContent(
            targetState = label,
            transitionSpec = {
                fadeIn(tween(340, delayMillis = 90, easing = LinearOutSlowInEasing)).togetherWith(fadeOut(tween(220, easing = FastOutSlowInEasing)))
                    .using(SizeTransform(clip = false) { _, _ -> tween(340, easing = FastOutSlowInEasing) })
            },
            modifier = Modifier.weight(1f, fill = false),
            label = "activity"
        ) { l -> ShimmerText(l, live) }
        if (SHOW_ELAPSED && live && elapsed >= 4) {
            Spacer(Modifier.width(8.dp))
            Text(
                "${elapsed} dtk",
                style = TextStyle(fontFamily = MythosSans, fontWeight = FontWeight.Normal, fontSize = 12.sp, color = MythosColors.Hint),
                maxLines = 1,
            )
        }
        if (expandable) {
            Spacer(Modifier.width(5.dp))
            ChevronGlyph(if (expanded) 90f else 0f)
        }
    }
}

@Composable
private fun StepsView(items: List<ChatItem>, live: Boolean, label: String, isWaiting: Boolean = false, afterUser: Boolean = false, elapsed: Int = 0) {
    var open by remember(items.firstOrNull()?.id) { mutableStateOf(false) }
    var peek by remember(items.firstOrNull()?.id) { mutableStateOf(false) }
    val hasItems = items.isNotEmpty()
    // patch22: satu getar ringan setiap teks live AI tampil atau berubah (mis. "Proses berpikir" -> "Menyusun langkah kerja"). [label] sudah label yang ditahan/ditampilkan.
    val liveTick = rememberSoftHaptic()
    LaunchedEffect(live, label) { if (live) liveTick(SOFT_HAPTIC_LIVE_GAP_MS) }
    LaunchedEffect(live, hasItems) {
        peek = false
        if (!DETAIL_PEEK_ENABLED || !live || !hasItems) return@LaunchedEffect
        while (true) {
            delay(DETAIL_PEEK_EVERY_MS)
            peek = true
            delay(DETAIL_PEEK_SHOW_MS)
            peek = false
        }
    }
    val lastLive = remember(items.firstOrNull()?.id) { arrayOf<String?>(null) }
    if (live && !isWaiting && label != THINKING_LABEL && items.none { it is NoticeItem && oneLineNarration(it.text) == label }) lastLive[0] = label
    Column(Modifier.fillMaxWidth().padding(top = if (afterUser) 6.dp else 0.dp, bottom = 20.dp)) {
        ActivityRow(
            live = live,
            label = if (live) label else finishedLabel(lastLive[0], items),
            elapsed = if (live) elapsed else 0,
            icon = groupIcon(items),
            expandable = items.isNotEmpty(),
            expanded = open || peek,
            onToggle = { open = !open }
        )
        AnimatedVisibility(visible = (open || peek) && items.isNotEmpty(), enter = expandVertically(tween(220)) + fadeIn(tween(220)), exit = fadeOut(tween(220))) {
            Column {
                (if (open) items else items.takeLast(DETAIL_PEEK_MAX)).forEach { ItemView(it, active = false, animate = false, onTick = {}) }
            }
        }
    }
}

@Composable
private fun StallNote(text: String, tight: Boolean) {
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    // Tinggi tata letak 0: catatan hanya menggambar di ruang kosong bawah baris aktivitas, jadi muncul/hilangnya tidak menggeser isi.
    Box(Modifier.layout { measurable, constraints ->
        val p = measurable.measure(constraints)
        layout(p.width, 0) { p.place(0, 0) }
    }) {
    AnimatedVisibility(
        visibleState = visible,
        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 2 }
    ) {
        Crossfade(targetState = text, animationSpec = tween(300), label = "stall-note") { t ->
            Text(
                t,
                style = TextStyle(fontFamily = MythosSans, fontWeight = FontWeight.Normal, fontSize = 11.5.sp, color = androidx.compose.ui.graphics.Color(0xFF85847F)),
                modifier = Modifier.offset(y = if (tight) (-20).dp else 0.dp).padding(start = ChatMargin + ACTIVITY_INSET + 74.px, top = if (tight) 0.dp else 8.dp, bottom = 8.dp)
            )
        }
    }
    }
}

@Composable
private fun StepRowShell(
    expandable: Boolean,
    expanded: Boolean,
    onToggle: () -> Unit,
    detail: (@Composable () -> Unit)? = null,
    head: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(36.dp)
                .clickable(enabled = expandable, onClick = onToggle)
                .padding(start = ChatMargin + ACTIVITY_INSET, end = ChatMargin + ACTIVITY_INSET),
            verticalAlignment = Alignment.CenterVertically
        ) { head() }
        if (expanded && detail != null) {
            Box(Modifier.fillMaxWidth().padding(start = ChatMargin + ACTIVITY_INSET + 74.px, end = ChatMargin + ACTIVITY_INSET, bottom = 8.dp)) { detail() }
        }
    }
}

@Composable
private fun StepRow(
    title: String,
    active: Boolean,
    animate: Boolean,
    failed: Boolean = false,
    plainDot: Boolean = true,
    detail: (@Composable () -> Unit)? = null,
) {
    var open by remember(title.removeSuffix("…")) { mutableStateOf(false) }
    val base = cleanLine(title).removeSuffix("…")
    val typed = rememberTyped(base, animate)
    val shown = typed + if (title.endsWith("…") && typed.length == base.length) "…" else ""
    val visible = remember { MutableTransitionState(!animate).apply { targetState = true } }
    AnimatedVisibility(visibleState = visible, enter = fadeIn(tween(650)) + expandVertically(tween(450))) {
        StepRowShell(expandable = detail != null, expanded = open, onToggle = { open = !open }, detail = detail) {
            Box(Modifier.width(74.px)) {
                when {
                    active -> LoaderDots()
                    failed -> StaticDot(MythosColors.Error)
                    plainDot -> StaticDot(androidx.compose.ui.graphics.Color(0xFFB8B6B1))
                }
            }
            ShimmerText(shown, active, Modifier.weight(1f))
            if (detail != null) {
                Spacer(Modifier.width(28.px))
                ChevronGlyph(if (open) 90f else 0f)
            }
        }
    }
}

@Composable
private fun Mono(text: String, color: androidx.compose.ui.graphics.Color = MythosColors.Hint) {
    Text(text, style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.5.sp, lineHeight = 17.sp, color = color))
}

@Composable
private fun TextItemView(
    item: ChatItem,
    animate: Boolean,
    onTick: () -> Unit,
    sources: AnswerSources = AnswerSources(emptyList(), emptyList()),
    onRetry: (() -> Unit)? = null,
) {
    val rawText = when (item) {
        is ThoughtItem -> item.text
        is FinalItem -> item.text
        else -> ""
    }
    val text = remember(rawText) { cleanForDisplay(rawText, keepTables = true, keepQuotes = true) }
    val live = (item as? ThoughtItem)?.live == true
    val revealed = rememberRevealed(text, animate, onTick)
    val finished = revealed >= text.length
    // patch18: setelah huruf terakhir tampil, ekor yang masih pudar diangkat pelan ke warna penuh (300 ms), bukan ditahan lalu dilepas mendadak.
    val tailLift by animateFloatAsState(if (animate && finished) 1f else 0f, tween(300, easing = LinearEasing), label = "tailLift")
    LaunchedEffect(item.id, finished) {
        if (finished) RevealClock.markDone(item.id, SystemClock.uptimeMillis()) else RevealClock.clear(item.id)
    }
    val streaming = live || revealed < text.length
    val fading = revealed < text.length || (animate && tailLift < 0.999f)
    val visible = text.substring(0, revealed)
    val proseOf: (String, Boolean) -> AnnotatedString = { prose, isLast ->
        val base = markdownToAnnotated(prose)
        if (fading && isLast) withTailFade(base, MythosColors.Ink, tailLift) else base
    }
    Column(
        Modifier.fillMaxWidth().padding(start = ChatMargin, end = ChatMargin, top = 0.dp, bottom = 16.dp)
    ) {
        // PATCH37: selama teks mengalir tetap LineBreak.Simple (baris tidak goyang); setelah selesai pakai LineBreak.Paragraph
        // supaya kata terakhir paragraf tidak sendirian di baris bawah dan tepi kanan terlihat lebih rata.
        AnswerBody(visible, assistantStyle().copy(lineBreak = if (streaming) LineBreak.Simple else LineBreak.Paragraph), proseOf)
        // patch14: sebelum huruf pertama tampil blok ini tingginya 0, padahal baris "sedang berpikir" yang baru dicabut setinggi satu baris:
        // daftar menyusut sesaat dan terlihat kosong/melompat. Tahan setinggi satu baris sampai huruf pertama muncul.
        if (visible.isEmpty() && streaming) Spacer(Modifier.height(with(LocalDensity.current) { assistantStyle().lineHeight.toDp() }))
        // patch14: status dan tombol aksi muncul dengan fade + membuka tinggi, bukan menyembul sekaligus saat jawaban selesai.
        if (item is FinalItem && item.showStatus) {
            AnimatedVisibility(visible = !streaming, enter = fadeIn(tween(220)) + expandVertically(tween(220))) {
                Text(
                    if (item.verified) "✓ Perubahan sudah diperiksa ulang" else "Sebagian perubahan belum diperiksa ulang",
                    style = TextStyle(fontFamily = MythosSans, fontWeight = FontWeight.Light, fontSize = 12.5.sp, color = MythosColors.Hint),
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        if (item is FinalItem) {
            AnimatedVisibility(visible = !streaming, enter = fadeIn(tween(220)) + expandVertically(tween(220))) {
                AnswerActions(text = text, sources = sources, onRetry = onRetry)
            }
        }
    }
}

@Composable
private fun ItemView(
    item: ChatItem,
    active: Boolean,
    animate: Boolean,
    onTick: () -> Unit,
    canUndo: Boolean = false,
    onUndo: (ChangesItem) -> Unit = {},
    loadDiff: suspend (ChangesItem, String) -> String = { _, _ -> "" },
    onOpenFile: (ChangesItem, String, Boolean) -> Unit = { _, _, _ -> },
    onOpenPath: (String, Boolean) -> Unit = { _, _ -> },
    onSendEmail: (EmailDraftItem) -> Unit = {},
    onEditEmail: (EmailDraftItem, List<String>, List<String>, String, String) -> Unit = { _, _, _, _, _ -> },
) {
    when (item) {
        is UserItem -> Column(
            Modifier.fillMaxWidth().padding(end = ChatMargin, bottom = 12.dp),
            horizontalAlignment = Alignment.End
        ) {
            if (item.attachments.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = if (item.text.isNotBlank()) 6.dp else 0.dp)) {
                    item.attachments.forEach { AttachmentCard(it) }
                }
            }
            if (item.text.isNotBlank()) {
                val shape = RoundedCornerShape(15.dp)
                Box(
                    Modifier
                        .widthIn(max = 308.dp)
                        .clip(shape)
                        .background(MythosColors.Bubble)
                        .crispBorder(0.33.dp, MythosColors.BubbleBorder, shape)
                        .padding(start = 12.dp, end = 12.dp, top = 13.dp, bottom = 13.dp)
                ) {
                    SelectionContainer { Text(item.text, style = bodyStyle()) }
                }
            }
        }

        is ThoughtItem, is FinalItem -> TextItemView(item, animate, onTick)

        is ToolItem -> StepRow(
            title = toolTitle(item.tool, item.summary) + if (item.status == ToolStatus.RUNNING) "…" else "",
            active = active,
            animate = animate,
            failed = item.status == ToolStatus.ERROR,
            detail = {
                Column {
                    Mono(item.summary)
                    if (item.preview.isNotBlank()) Mono(item.preview, MythosColors.Ink)
                    if (item.millis > 0) Mono("${item.millis} ms")
                }
            }
        )

        is PlanItem -> {
            val done = item.steps.count { it.status == StepStatus.DONE }
            StepRow(
                title = "Rencana · $done/${item.steps.size} selesai",
                active = false,
                animate = animate,
                detail = {
                    Column {
                        item.steps.forEachIndexed { i, s ->
                            val mark = when (s.status) {
                                StepStatus.TODO -> "○"
                                StepStatus.DOING -> "◐"
                                StepStatus.DONE -> "●"
                                StepStatus.BLOCKED -> "✕"
                            }
                            Text("$mark ${i + 1}. ${s.title}", style = bodyStyle())
                        }
                    }
                }
            )
        }

        is NoticeItem -> StepRow(title = item.text, active = false, animate = animate, plainDot = false)

        is ErrorItem -> Text(
            item.text,
            style = bodyStyle(MythosColors.Error),
            modifier = Modifier.fillMaxWidth().padding(start = ChatMargin, end = ChatMargin, top = 8.dp, bottom = 8.dp)
        )

        is EmailDraftItem -> EmailDraftCard(item, onOpenPath, onEdit = { to, cc, subject, body -> onEditEmail(item, to, cc, subject, body) }) { onSendEmail(item) }

        is ChangesItem -> ChangesCard(item, canUndo, { onUndo(item) }, { path -> loadDiff(item, path) }, { path, share -> onOpenFile(item, path, share) })
    }
}

/** Kunci item ruang kosong di ujung daftar chat (agar pesan terakhir pengguna bisa naik ke atas layar). */
private const val TAIL_KEY = "tail-space"

/**
 * Kunci SATU slot untuk baris aktivitas hidup: dipakai bersama oleh baris tambahan (sebelum kelompok langkah dirilis) dan kelompok
 * langkah terakhir yang sedang berjalan. Pergantian keduanya jadi ganti isi di slot yang sama, bukan hapus + sisip, jadi tinggi
 * daftar tidak berubah sesaat (penyebab sentakan ~180 px dua bingkai pada rekaman). Keduanya tidak pernah ada bersamaan:
 * needsExtraLive selalu false bila blok terakhir adalah kelompok langkah.
 */
/** Kapan layar mulai mengikuti teks: jawaban sudah memenuhi layar (tak ada ruang kosong di bawahnya) dan pengguna belum menyentuh daftar. */
internal fun shouldStartFollowing(pinned: Long?, roomSeenFor: Long?, rawTail: Int, userDragged: Boolean): Boolean =
    pinned != null && roomSeenFor == pinned && rawTail <= 0 && !userDragged

private const val LIVE_SLOT_KEY = "live-slot"

/** Selisih (px) antara dasar isi daftar dan tepi bawah area terlihat; 0 bila sudah di dasar. Aman terhadap perbedaan offset: canScrollForward jadi penentu akhir. */
private fun distanceToBottom(state: androidx.compose.foundation.lazy.LazyListState): Float {
    if (!state.canScrollForward) return 0f
    val info = state.layoutInfo
    val last = info.visibleItemsInfo.lastOrNull() ?: return 0f
    if (last.index != info.totalItemsCount - 1) return info.viewportSize.height.toFloat()
    val edge = info.viewportEndOffset - info.afterContentPadding
    return (last.offset + last.size - edge).toFloat().coerceAtLeast(24f)
}

/** Daftar sudah tepat di awal item [idx] (tanpa selisih gulir): tidak perlu menggulir lagi, jadi tidak ada lompatan. */
private fun atItemTop(state: androidx.compose.foundation.lazy.LazyListState, idx: Int): Boolean =
    state.firstVisibleItemIndex == idx && state.firstVisibleItemScrollOffset == 0

/**
 * patch18: true = setelah kirim, pesan pengguna disematkan ke ATAS layar (terlihat sebagai layar yang tiba-tiba melompat ~900 px dalam ~150 ms,
 * padahal pengguna tidak menyentuh apa pun). false = pesan tetap di bawah dan layar hanya mengikuti dengan gulir halus yang sama seperti saat jawaban mengalir.
 */
internal const val PIN_USER_MESSAGE_ON_SEND = false

// patch18: satu bahasa gerak untuk seluruh alur (baris live muncul -> hilang -> teks mengetik -> baris live lagi): semua memakai kurva yang sama.
// Yang keluar memudar cepat (160 ms) dan yang masuk menunggu 120 ms, jadi baris live dan teks tidak bertumpuk saat bertukar tempat.
private val FLOW_FADE_IN: FiniteAnimationSpec<Float> = tween(380, delayMillis = 120, easing = LinearOutSlowInEasing)
private val FLOW_FADE_OUT: FiniteAnimationSpec<Float> = tween(160, easing = FastOutSlowInEasing)
private val FLOW_PLACE: FiniteAnimationSpec<IntOffset> = tween(380, easing = FastOutSlowInEasing)

/**
 * Margin kiri/kanan konten di SEMUA layar (Chat, Pengaturan, Proyek, File, Artefak; judul, gelembung pesan, balasan AI, ikon aksi, baris langkah, ikon titik tiga).
 * Sengaja sedikit lebih ke dalam daripada kartu input (16 dp) karena kartu berbentuk pil bersudut bulat sehingga tepinya
 * terasa menjorok. Ubah satu angka ini untuk menggeser semuanya sekaligus.
 */
internal val ChatMargin = 22.dp

/**
 * Baris langkah/aktivitas (titik, label, panah) ditarik ke tengah: menjorok sebanyak ini dari margin teks biasa di KIRI dan KANAN, seperti rekaman acuan
 * (tangkapan 1080 px: titik 14 dp dan panah 12 dp di dalam margin teks). Narasi dan jawaban tetap di ChatMargin. Ubah satu angka untuk menggeser.
 */
internal val ACTIVITY_INSET = 12.dp
