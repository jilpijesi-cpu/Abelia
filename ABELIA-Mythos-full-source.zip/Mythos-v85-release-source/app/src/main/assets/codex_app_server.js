'use strict';

// One short-lived Codex app-server session per Mythos completion; no Python or fixed HTTP listener.
const cp = require('child_process');
const net = require('net');

// --- Pengerasan (v81) -------------------------------------------------------------------------------------------
// Mythos hanya memakai Codex sebagai model bahasa. Argumen -c bersifat FAIL-CLOSED (v82): bila versi Codex menolaknya,
// sesi dihentikan dengan galat jelas, TIDAK dijalankan ulang tanpa pengerasan. Pemutus (tripwire) tetap jadi lapisan kedua.
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
// MODE NATIVE (MYTHOS_CODEX_NATIVE=1): akses penuh ke Termux atas permintaan pemilik (PATCH33).
// Kebijakan never + sandbox danger-full-access: tanpa sandbox dan tanpa dialog persetujuan; permintaan izin yang tetap muncul dijawab accept.
// Tanpa MYTHOS_CODEX_NATIVE (mode model-saja), Codex hanya menjadi model bahasa: read-only dan tool bawaan dibatalkan.
const NATIVE = process.env.MYTHOS_CODEX_NATIVE === '1';
const HARDENED_ARGS = ['-c', 'features.shell_tool=false', '-c', 'project_doc_max_bytes=0', '-c', 'history.persistence="none"'];
const NATIVE_HARDENED_ARGS = NATIVE ? ['-c', 'history.persistence="none"'] : [];
// patch9: opsi tambahan yang mematikan pencarian web bawaan Codex di tingkat konfigurasi (nama opsi berbeda antar versi Codex).
// Dicoba berurutan: bila Codex menolak satu tingkat saat start, tingkat berikutnya dipakai. Tingkat terakhir = hanya pengerasan inti.
// Pengerasan inti (HARDENED_ARGS) TIDAK PERNAH dilonggarkan; pemutus (tripwire) tetap lapisan kedua.
const EXTRA_ARG_TIERS = NATIVE ? [[]] : [
  ['-c', 'web_search="disabled"', '-c', 'tools.web_search=false', '-c', 'features.web_search_request=false'],
  ['-c', 'web_search="disabled"'],
  []
];
let argTier = 0;
const MAX_NATIVE_RETRIES = 2; // total 3 percobaan per pesan
// Mode native: tidak ada tool bawaan yang diblokir. Mode model-saja: semua tool bawaan dibatalkan (pemutus/tripwire).
const BLOCKED_ITEMS = new Set(NATIVE
  ? []
  : ['commandExecution', 'command_execution', 'fileChange', 'file_change', 'mcpToolCall', 'mcp_tool_call', 'webSearch', 'web_search']);
const KEEP_SESSIONS = process.env.MYTHOS_KEEP_CODEX_SESSIONS === '1';
function pad2(n) { return String(n).padStart(2, '0'); }
function purgeThread(threadId) {
  if (KEEP_SESSIONS || !/^[0-9A-Za-z-]{8,64}$/.test(String(threadId || ''))) return;
  setTimeout(() => {
    try {
      const root = path.join(process.env.CODEX_HOME || path.join(os.homedir(), '.codex'), 'sessions');
      const days = new Set();
      for (const off of [0, -1]) {
        const d = new Date(Date.now() + off * 86400000);
        days.add([d.getFullYear(), pad2(d.getMonth() + 1), pad2(d.getDate())].join('/'));
        days.add([d.getUTCFullYear(), pad2(d.getUTCMonth() + 1), pad2(d.getUTCDate())].join('/'));
      }
      for (const day of days) {
        const dir = path.join(root, day);
        let names = [];
        try { names = fs.readdirSync(dir); } catch (_) { continue; }
        for (const name of names) {
          if (name.endsWith('-' + threadId + '.jsonl')) { try { fs.unlinkSync(path.join(dir, name)); } catch (_) {} }
        }
      }
    } catch (_) {}
  }, 1500);
}
const PORT = Number(process.argv[2] || 0);
const TOKEN = String(process.argv[3] || '');
// Prompt lewat argumen hanya dipakai mode model-saja; mode native wajib menerima sesi melalui soket aplikasi.
const PROMPT_B64 = String(process.argv[4] || '');
const ARGV_PROMPT = PROMPT_B64.length > 0;
const TIMEOUT_MS = 15 * 60 * 1000;
let socket;
let socketBuffer = '';
let seq = 0;
const START_MS = Date.now();
const phaseSeen = new Set();
// Penanda fase (sekali per nama): dari sini terlihat ke mana waktu habis sebelum teks pertama (mulai Codex, sesi, berpikir, teks).
function mark(name) {
  if (phaseSeen.has(name)) return;
  phaseSeen.add(name);
  emit({type: 'phase', name, ms: Date.now() - START_MS});
}
let sockReady = false;
let sockQueue = [];
let inputBuffer = '';
let child;
let started = false;
let initDone = false;
let ended = false;
let threadId = '';
let SCRATCH_WORKDIR = null;
let scratchCleanupTimer = null;
// patch8: tool bawaan Codex tidak lagi membunuh seluruh giliran. Giliran dihentikan (turn/interrupt), lalu diulang SEKALI
// di thread baru dengan pengingat keras; peristiwa dari thread lama diabaikan.
let nativeRetries = 0;
let retryPrompt = '';
// Upaya berpikir dari aplikasi (low/medium/high); kosong = ikuti konfigurasi Codex. Ditolak Codex -> diulang tanpa (effortDropped).
const EFFORT = ['low', 'medium', 'high'].includes(process.env.MYTHOS_CODEX_EFFORT || '') ? process.env.MYTHOS_CODEX_EFFORT : '';
let effortDropped = false;
function turnParams(text) {
  const p = {threadId, cwd: process.cwd(), approvalPolicy: NATIVE ? 'never' : 'on-request', input: buildInput(text)};
  if (EFFORT && !effortDropped) p.effort = EFFORT;
  return p;
}
let IMAGE_ITEMS = []; // gambar lampiran (data URL) yang dikirim bersama teks; kosong = hanya teks
let imagesDropped = false;
function buildInput(text) {
  const items = [{type: 'text', text}];
  if (!imagesDropped) IMAGE_ITEMS.forEach(url => items.push({type: 'image', url}));
  return items;
}
function parseImages(list) {
  const out = [];
  if (!Array.isArray(list)) return out;
  for (const it of list.slice(0, 8)) {
    const mime = it && typeof it.mime === 'string' ? it.mime : '';
    const b64 = it && typeof it.base64 === 'string' ? it.base64 : '';
    if (!/^image\/(jpeg|png|webp|gif)$/.test(mime)) continue;
    if (!/^[A-Za-z0-9+\/=]+$/.test(b64) || b64.length === 0) continue;
    out.push('data:' + mime + ';base64,' + b64);
  }
  return out;
}
let currentTurnId = '';
const deadThreads = new Set();
function nativeReminder(level, blockedType) {
  const lines = [
    'KOREKSI (' + level + '): percobaan sebelumnya memanggil tool bawaan Codex (' + (blockedType || 'mcpToolCall/commandExecution/fileChange/webSearch') + ') dan DIBATALKAN.',
    'Kamu TIDAK punya tool bawaan di sini: tidak ada pencarian web bawaan, tidak ada shell, tidak ada baca/tulis file bawaan. Jangan memanggil tool lewat mekanisme Codex/MCP.',
    'PEMETAAN: mencari di web -> <tool_use>{\"name\": \"WebSearch\", \"input\": {\"query\": \"...\"}}</tool_use>; membuka halaman -> WebFetch {\"url\": \"...\"}; membaca file/lampiran -> Read/Glob/Grep. Semuanya ditulis sebagai TEKS BIASA di jawabanmu; Mythos yang menjalankannya.',
    'Mulai jawaban dengan satu kalimat singkat, lalu LANGSUNG tulis blok <tool_use> bila perlu mencari/membaca. Jangan hanya menjanjikan akan melakukannya.'
  ];
  if (level >= 2) lines.push('PERINGATAN TERAKHIR: sekali lagi memakai tool bawaan, sesi dibatalkan. Tulis <tool_use> sebagai teks, atau jawab langsung tanpa alat.');
  lines.push('');
  return lines.join('\n');
}
// Mode model-saja: ubah percobaan pencarian web bawaan menjadi alat WebSearch Mythos (sisanya tidak punya padanan aman).
// Perintah shell TIDAK diterjemahkan: Termux hanya bisa dipakai Codex lewat mode native.
function commandToText(item) {
  const c = item && (item.command !== undefined ? item.command : (item.action && item.action.command));
  if (Array.isArray(c)) {
    const parts = c.map(x => String(x));
    if (parts.length >= 3 && /^(bash|sh|zsh)$/.test(parts[0].split('/').pop()) && /^-l?c$/.test(parts[1])) return parts[2];
    return parts.join(' ');
  }
  return typeof c === 'string' ? c : '';
}
function nativeToMythosCall(item) {
  try {
    if (!item || (item.type !== 'webSearch' && item.type !== 'web_search')) return '';
    const a = item.action || {};
    let q = item.query || a.query || (Array.isArray(a.queries) && a.queries[0]) || '';
    q = String(q || '').replace(/\s+/g, ' ').trim();
    if (!q || q.length > 300) return '';
    return '\n<tool_use>' + JSON.stringify({status: 'Mencari di web', name: 'WebSearch', input: {query: q}}) + '</tool_use>';
  } catch (_) { return ''; }
}
let answer = '';
let currentText = '';
let stderr = '';
let timer;
let shutdownTimer;
let hardKillTimer;

// Tiap baris protokol bernomor urut n dan ditulis ke stdout (jalur cadangan yang dibaca aplikasi dari hasil Termux)
// DAN ke soket (aliran langsung). Aplikasi membuang baris ganda berdasarkan n, jadi soket putus tidak menghilangkan data.
function emit(event) {
  seq += 1;
  const line = JSON.stringify(Object.assign({n: seq}, event)) + '\n';
  try { process.stdout.write(line); } catch (_) {}
  if (!socket || socket.destroyed) return;
  if (sockReady) { try { socket.write(line); } catch (_) {} }
  else if (sockQueue.length < 2000) sockQueue.push(line);
}

function signalProcessGroup(signal) {
  if (!child || !child.pid) return;
  try { process.kill(-child.pid, signal); }
  catch (_) {
    if (child.exitCode === null) {
      try { child.kill(signal); } catch (_) {}
    }
  }
}
function stopProcessGroup() {
  if (!child || !child.pid) return;
  signalProcessGroup('SIGTERM');
  try {
    process.kill(-child.pid, 0);
    if (hardKillTimer) clearTimeout(hardKillTimer);
    hardKillTimer = setTimeout(() => {
      hardKillTimer = null;
      signalProcessGroup('SIGKILL');
    }, 1500);
  } catch (_) {}
}
function scheduleProcessGroupStop() {
  if (!child || !child.pid || shutdownTimer) return;
  shutdownTimer = setTimeout(() => {
    shutdownTimer = null;
    stopProcessGroup();
  }, 2000);
}

function send(obj) {
  if (child && child.stdin && !child.stdin.destroyed) child.stdin.write(JSON.stringify(obj) + '\n');
}
// Putus koneksi sementara antara Codex dan servernya (jaringan seluler goyah): aman diulang otomatis oleh aplikasi.
const TRANSIENT_NET = /stream disconnected|network error|error decoding response body|transport error|connection (reset|closed|refused|aborted)|econnreset|etimedout|enotfound|eai_again|socket hang up|timed? ?out|temporarily unavailable|bad gateway|service unavailable|overloaded|\b(502|503|504)\b/i;
function finish(error, retryable) {
  if (ended) return;
  if (error && !retryable && TRANSIENT_NET.test(String(error))) retryable = true;
  ended = true;
  if (timer) clearTimeout(timer);
  sendBackWorkspace();   // PATCH31: sebelum 'done', agar berkas hasil kerja sampai ke aplikasi lebih dulu
  scheduleScratchCleanup();
  purgeThread(threadId);
  if (error) {
    emit({type: 'error', message: String(error).slice(0, 8000), retryable: !!retryable});
    try { process.stderr.write(String(error).slice(0, 2000) + '\n'); } catch (_) {}
  }
  process.exitCode = error ? 1 : 0;
  emit({type: 'done'});
  if (child && child.stdin && !child.stdin.destroyed) {
    try { child.stdin.end(); } catch (_) {}
  }
  scheduleProcessGroupStop();
  if (socket && !socket.destroyed) socket.end();
}
function cleanError(value) {
  if (!value) return 'Codex app-server gagal.';
  if (typeof value === 'string') return value;
  return value.message || JSON.stringify(value);
}

// --- PATCH31: salinan kerja proyek Mythos ------------------------------------------------------------------------
// Folder proyek aplikasi tidak terjangkau Termux. Aplikasi mengirim berkas proyek yang berubah dalam permintaan ("workspace"),
// runner menulisnya ke ~/mythos-work/<id>/ dan menjalankan Codex di sana. Di akhir sesi, berkas yang berubah dibanding keadaan
// awal dikirim balik lewat soket (satu baris {type:'file'} per berkas, lalu {type:'files_done'}); TIDAK lewat stdout/berkas live.
const WORK_SKIP = new Set(['.git', 'node_modules', 'build', '.gradle', '.idea', '.mythos_codex', '.codex', '.ssh', '.aws', '.gnupg']);
const WORK_SECRET_BASENAMES = new Set(['.netrc', '.npmrc', '.pypirc', '.git-credentials', 'local.properties', 'keystore.properties', 'google-services.json']);
const WORK_SECRET_DIRS = new Set(['.mythos_codex', '.codex', '.ssh', '.aws', '.gnupg']);
const WORK_SECRET_PATTERNS = [/^\.env(?:\..*)?$/i, /^(?:auth|credentials|client_secret|service-account|firebase-adminsdk)[^/]*\.json$/i, /^id_(?:rsa|ed25519|ecdsa|dsa)(?:\.pub)?$/i, /\.(?:pem|key|p8|p12|pfx|jks|keystore|kdbx|asc)$/i];
const WORK_MAX_FILE = 8 * 1024 * 1024;
const WORK_RETURN_MAX_FILE = 700 * 1024;   // satu baris soket dibatasi 1.000.000 karakter di aplikasi (base64 = 4/3 ukuran)
const WORK_RETURN_MAX_TOTAL = 24 * 1024 * 1024;
const WORK_MAX_FILES = 5000;
let WORKDIR = process.cwd();
let WORK_BASE = null;   // Map path -> hash saat sesi mulai (setelah berkas dari aplikasi ditulis)

function isSecretPath(rel) {
  const parts = String(rel || '').replace(/\\/g, '/').split('/').filter(Boolean);
  if (parts.some(seg => WORK_SECRET_DIRS.has(seg.toLowerCase()))) return true;
  const base = parts[parts.length - 1] || '';
  return WORK_SECRET_BASENAMES.has(base.toLowerCase()) || WORK_SECRET_PATTERNS.some(re => re.test(base));
}
function safeRel(p) {
  const r = String(p || '').replace(/\\/g, '/').replace(/^\.\//, '');
  if (!r || r.startsWith('/') || r.split('/').some(seg => seg === '..' || seg === '' || WORK_SKIP.has(seg)) || isSecretPath(r)) return null;
  return r;
}
function ensureWorkRoot() {
  const home = fs.realpathSync(os.homedir());
  const root = path.join(home, 'mythos-work');
  fs.mkdirSync(root, {recursive: true, mode: 0o700});
  const st = fs.lstatSync(root);
  if (st.isSymbolicLink() || !st.isDirectory() || fs.realpathSync(root) !== root) {
    throw new Error('Folder mythos-work tidak boleh berupa symlink atau bukan direktori.');
  }
  try { fs.chmodSync(root, 0o700); } catch (_) {}
  return root;
}
function ensureProjectWorkspace(root, id) {
  const dir = path.join(root, id);
  try { fs.mkdirSync(dir, {mode: 0o700}); }
  catch (e) { if (e.code !== 'EEXIST') throw e; }
  const st = fs.lstatSync(dir);
  const real = fs.realpathSync(dir);
  if (st.isSymbolicLink() || !st.isDirectory() || path.dirname(real) !== root || real !== dir) {
    throw new Error('Folder workspace proyek tidak aman (symlink atau keluar dari root).');
  }
  return dir;
}
function safeWorkspaceTarget(dir, rel) {
  const parts = rel.split('/');
  let parent = dir;
  for (const part of parts.slice(0, -1)) {
    parent = path.join(parent, part);
    try { fs.mkdirSync(parent, {mode: 0o700}); }
    catch (e) { if (e.code !== 'EEXIST') throw e; }
    const st = fs.lstatSync(parent);
    if (st.isSymbolicLink() || !st.isDirectory()) throw new Error('Komponen folder workspace bukan direktori aman.');
  }
  const target = path.join(parent, parts[parts.length - 1]);
  try {
    const st = fs.lstatSync(target);
    if (st.isSymbolicLink() || !st.isFile()) throw new Error('Berkas workspace bukan berkas biasa.');
  } catch (e) { if (e.code !== 'ENOENT') throw e; }
  return target;
}
function removeWorkspaceSymlinks(dir) {
  let names = [];
  try { names = fs.readdirSync(dir, {withFileTypes: true}); } catch (_) { return; }
  for (const entry of names) {
    const full = path.join(dir, entry.name);
    if (entry.isSymbolicLink()) {
      try { fs.unlinkSync(full); } catch (_) {}
    } else if (entry.isDirectory()) removeWorkspaceSymlinks(full);
  }
}
function pruneStaleSecrets(dir, prefix = '') {
  let names = [];
  try { names = fs.readdirSync(dir, {withFileTypes: true}); } catch (_) { return; }
  for (const entry of names) {
    if (entry.isSymbolicLink()) continue;
    const rel = prefix ? prefix + '/' + entry.name : entry.name;
    const full = path.join(dir, entry.name);
    if (isSecretPath(rel)) {
      try { fs.rmSync(full, {recursive: true, force: true}); } catch (_) {}
    } else if (entry.isDirectory()) pruneStaleSecrets(full, rel);
  }
}
function workScan(dir) {
  const out = new Map();
  (function walk(d, prefix, depth) {
    if (depth > 14 || out.size >= WORK_MAX_FILES) return;
    let names = [];
    try { names = fs.readdirSync(d, {withFileTypes: true}); } catch (_) { return; }
    for (const e of names) {
      if (out.size >= WORK_MAX_FILES) return;
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) { if (!WORK_SKIP.has(e.name)) walk(path.join(d, e.name), rel, depth + 1); continue; }
      if (!e.isFile() || !safeRel(rel)) continue;
      try {
        const full = path.join(d, e.name);
        const size = fs.statSync(full).size;
        const hash = size > WORK_MAX_FILE ? 'big:' + size : crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
        out.set(rel, {size, hash});
      } catch (_) {}
    }
  })(dir, '', 0);
  return out;
}
function applyWorkspace(ws) {
  const id = String((ws && ws.id) || '').replace(/[^A-Za-z0-9._-]/g, '_').replace(/^\.+/, '').slice(0, 80);
  if (!id) return;
  const root = ensureWorkRoot();
  const dir = ensureProjectWorkspace(root, id);
  // Hilangkan symlink dari workspace tersimpan agar Codex tidak dapat mengakses folder di luarnya.
  removeWorkspaceSymlinks(dir);
  // Hapus rahasia yang mungkin tersalin oleh versi lama sebelum Codex dapat membacanya.
  pruneStaleSecrets(dir);
  for (const f of Array.isArray(ws.files) ? ws.files : []) {
    const rel = safeRel(f && f.path);
    if (!rel || typeof f.b64 !== 'string') continue;
    try {
      const target = safeWorkspaceTarget(dir, rel);
      fs.writeFileSync(target, Buffer.from(f.b64, 'base64'));
    } catch (_) {}
  }
  WORKDIR = dir;
  process.chdir(dir);   // Codex (anak proses) dan startThread/turnParams memakai process.cwd()
  WORK_BASE = workScan(dir);
}
function sockWrite(obj) {
  if (!socket || socket.destroyed || !sockReady) return;
  try { socket.write(JSON.stringify(obj) + '\n'); } catch (_) {}
}
let workSent = false;
function sendBackWorkspace() {
  if (!WORK_BASE || workSent) return;
  workSent = true;
  try {
    const now = workScan(WORKDIR);
    let total = 0;
    const skipped = [];
    for (const [rel, info] of now) {
      const base = WORK_BASE.get(rel);
      if (base && base.hash === info.hash) continue;
      if (info.size > WORK_RETURN_MAX_FILE || total + info.size > WORK_RETURN_MAX_TOTAL) { skipped.push(rel); continue; }
      try {
        sockWrite({type: 'file', path: rel, b64: fs.readFileSync(path.join(WORKDIR, rel)).toString('base64')});
        total += info.size;
      } catch (_) {}
    }
    const deleted = [];
    for (const rel of WORK_BASE.keys()) if (!now.has(rel)) deleted.push(rel);
    sockWrite({type: 'files_done', deleted: deleted.slice(0, 500), skipped: skipped.slice(0, 50)});
  } catch (_) {}
}

function createScratchWorkspace() {
  const root = ensureWorkRoot();
  const dir = fs.mkdtempSync(path.join(root, 'session-'));
  try { fs.chmodSync(dir, 0o700); } catch (_) {}
  SCRATCH_WORKDIR = dir;
  WORKDIR = dir;
  process.chdir(dir);
}
function cleanupScratchWorkspace() {
  const dir = SCRATCH_WORKDIR;
  SCRATCH_WORKDIR = null;
  if (scratchCleanupTimer) clearTimeout(scratchCleanupTimer);
  scratchCleanupTimer = null;
  if (!dir) return;
  let root;
  try { root = ensureWorkRoot() + path.sep; } catch (_) { return; }
  const target = path.resolve(dir);
  // Hapus hanya direktori session-* biasa yang masih berada langsung di root; jangan mengikuti symlink.
  if (target.startsWith(root) && path.dirname(target) + path.sep === root && path.basename(target).startsWith('session-')) {
    try {
      const st = fs.lstatSync(target);
      if (st.isDirectory() && !st.isSymbolicLink()) fs.rmSync(target, {recursive: true, force: true});
    } catch (_) {}
  }
}
function scheduleScratchCleanup() {
  if (!SCRATCH_WORKDIR || scratchCleanupTimer) return;
  // Fallback jika child tidak mengirim event close setelah SIGKILL.
  scratchCleanupTimer = setTimeout(cleanupScratchWorkspace, 5000);
  if (typeof scratchCleanupTimer.unref === 'function') scratchCleanupTimer.unref();
}

function startSession(request) {
  if (started) return;
  started = true;
  const prompt = typeof request.prompt === 'string' ? request.prompt : '';
  if (!prompt.trim()) { finish('Prompt Codex kosong.'); return; }
  IMAGE_ITEMS = parseImages(request.images);
  if (NATIVE) {
    try {
      if (request.workspace) applyWorkspace(request.workspace);
      else createScratchWorkspace();
    } catch (e) { finish('Tidak dapat menyiapkan ruang kerja Codex yang terisolasi: ' + e.message); return; }
  }
  timer = setTimeout(() => {
    stopProcessGroup();
    finish('Codex app-server melewati batas waktu 15 menit.');
  }, TIMEOUT_MS);
  spawnChild(prompt);
}
function spawnChild(prompt) {
  const hardenedArgs = NATIVE ? NATIVE_HARDENED_ARGS : HARDENED_ARGS;
  // Contract: HARDENED_ARGS.concat(EXTRA_ARG_TIERS[argTier], ['app-server', '--listen', 'stdio://'])
  const args = hardenedArgs.concat(EXTRA_ARG_TIERS[argTier], ['app-server', '--listen', 'stdio://']);
  child = cp.spawn('codex', args, {stdio: ['pipe', 'pipe', 'pipe'], detached: true});
  mark('spawn');
  const mine = child;
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdin.on('error', () => {}); // EPIPE bila Codex keluar lebih dulu; ditangani lewat event 'close' (galat fail-closed)
  child.stderr.on('data', chunk => { if (child !== mine) return; stderr = (stderr + chunk).slice(-8000); });
  child.stdout.on('data', chunk => {
    if (child !== mine) return;
    inputBuffer += chunk;
    if (inputBuffer.length > 64000000) { finish('Respons protokol Codex melebihi batas ukuran buffer.'); return; }
    let nl;
    while ((nl = inputBuffer.indexOf('\n')) >= 0) {
      const line = inputBuffer.slice(0, nl);
      inputBuffer = inputBuffer.slice(nl + 1);
      if (!line.trim()) continue;
      try { handle(JSON.parse(line), prompt); }
      catch (e) { finish('Respons protokol Codex tidak valid: ' + e.message); }
    }
  });
  child.on('error', e => { if (child !== mine) return; finish('Tidak dapat menjalankan Codex app-server: ' + e.message); });
  child.on('close', code => {
    if (child !== mine) return;
    if (!ended && !initDone && argTier < EXTRA_ARG_TIERS.length - 1) {
      // patch9: opsi tambahan (mis. web_search) ditolak versi Codex ini -> coba tingkat berikutnya; pengerasan inti tetap terpasang.
      argTier += 1;
      inputBuffer = '';
      spawnChild(prompt);
      return;
    }
    if (!ended && !initDone) {
      // Fail-closed: JANGAN ulangi tanpa -c. Tanpa pengerasan, perintah baca-saja "aman" bisa jalan sebelum pemutus bereaksi.
      if (shutdownTimer) clearTimeout(shutdownTimer);
      shutdownTimer = null;
      stopProcessGroup();
      finish('Codex menolak opsi pengerasan (-c features.shell_tool=false) atau gagal start; perbarui Codex CLI di Termux. ' + stderr.trim().slice(-500), false);
      return;
    }
    if (shutdownTimer) clearTimeout(shutdownTimer);
    shutdownTimer = null;
    stopProcessGroup();
    if (ended) { cleanupScratchWorkspace(); return; }
    if (inputBuffer.trim()) {
      try { handle(JSON.parse(inputBuffer), prompt); } catch (_) {}
    }
    if (code !== 0) finish(stderr.trim() || ('Codex app-server keluar dengan kode ' + code));
    else if (!answer) finish('Codex tidak mengeluarkan teks jawaban.');
    else finish(null);
  });
  send({
    method: 'initialize',
    id: 1,
    params: {clientInfo: {name: 'mythos_android', title: 'Mythos Android', version: '__MYTHOS_VERSION__'}}
  });
}
let threadExtended = false;
function startThread(extended) {
  threadExtended = extended;
  // Native dibatasi ke folder kerja sementara/salinan proyek; sandbox melarang perubahan di luar folder ini.
  // on-request mengirim permintaan ke aplikasi saat Codex perlu keluar dari batas sandbox atau mengakses jaringan.
  // Mode native = akses penuh ke Termux (permintaan pemilik): tanpa sandbox dan tanpa dialog persetujuan.
  const params = NATIVE
    ? {cwd: process.cwd(), approvalPolicy: 'never', sandbox: 'danger-full-access'}
    : {cwd: process.cwd(), approvalPolicy: 'on-request', sandbox: 'read-only'};
  if (extended) params.ephemeral = true; // tidak menyimpan rollout di ~/.codex/sessions
  send({method: 'thread/start', id: 2, params});
}
// Mode native = akses penuh (approvalPolicy 'never'), jadi Codex tidak pernah meminta izin. Bila versi Codex tetap menanyakannya, native menjawab 'accept'.
// Mode model-saja menolak: tool bawaan memang tidak boleh jalan di sana.
function handleServerRequest(message) {
  const method = String(message.method || '');
  if (method === 'item/commandExecution/requestApproval' || method === 'item/fileChange/requestApproval') {
    send({id: message.id, result: {decision: NATIVE ? 'accept' : 'decline'}});
    return;
  }
  send({id: message.id, error: {code: -32601, message: 'Unsupported request: ' + method}});
}
function handle(message, prompt) {
  if (message.method && message.id !== undefined && message.id !== null) {
    handleServerRequest(message);
    return;
  }
  if (message.id === 1) {
    mark('init');
    initDone = true;
    if (message.error) { finish('Inisialisasi Codex app-server gagal: ' + cleanError(message.error)); return; }
    send({method: 'initialized'});
    startThread(true);
    return;
  }
  if (message.id === 2) {
    if (message.error && threadExtended) { startThread(false); return; } // opsi ephemeral ditolak -> ulangi polos
    if (message.error) { finish('Gagal memulai sesi Codex: ' + cleanError(message.error)); return; }
    threadId = message.result && message.result.thread && message.result.thread.id || '';
    mark('thread');
    if (!threadId) { finish('Codex app-server tidak mengembalikan ID sesi.'); return; }
    send({method: 'turn/start', id: 3, params: turnParams(retryPrompt || prompt)});
    return;
  }
  if (message.id === 3 && message.result) {
    mark('turn');
    const t = message.result.turn || {};
    if (t.id) currentTurnId = String(t.id);
  }
  if (message.id === 3 && message.error && EFFORT && !effortDropped) {
    // Codex CLI lama menolak parameter effort: ulangi tanpa itu (tetap dengan gambar).
    effortDropped = true;
    send({method: 'turn/start', id: 3, params: turnParams(retryPrompt || prompt)});
    return;
  }
  if (message.id === 3 && message.error && IMAGE_ITEMS.length && !imagesDropped) {
    // Codex di Termux menolak input gambar (versi lama?): ulangi sebagai teks saja dan beri tahu model secara jujur.
    imagesDropped = true;
    send({method: 'turn/start', id: 3, params: turnParams('[Catatan sistem: Codex di Termux ini menolak input gambar, sehingga gambar pengguna TIDAK sampai. Katakan terus terang bahwa kamu tidak bisa melihat gambarnya dan sarankan memperbarui Codex CLI.]\n' + (retryPrompt || prompt))});
    return;
  }
  if (message.id === 3 && message.error) {
    finish('Permintaan Codex ditolak: ' + cleanError(message.error));
    return;
  }
  const params = message.params || {};
  if (params.threadId && deadThreads.has(params.threadId)) return;
  if (params.threadId && threadId && params.threadId !== threadId) return;
  if (params.turnId && !currentTurnId) currentTurnId = String(params.turnId);
  // Aktivitas langsung untuk UI (hanya penanda mulai/selesai; isi jawaban tetap lewat 'delta'). Mode native: perintah shell yang dijalankan Codex
  // sendiri tidak punya baris langkah di Mythos, jadi tanpa ini pengguna tidak melihat apa pun selama Codex bekerja.
  if ((message.method === 'item/started' || message.method === 'item/completed') && params.item) {
    const itType = String(params.item.type || '');
    const phase = message.method === 'item/started' ? 'start' : 'end';
    if (NATIVE && (itType === 'commandExecution' || itType === 'command_execution')) {
      emit({type: 'activity', kind: 'command', phase, command: commandToText(params.item).replace(/\s+/g, ' ').trim().slice(0, 200)});
    } else if (itType === 'reasoning') {
      mark('reasoning');
      emit({type: 'activity', kind: 'thinking', phase, command: ''});
    }
  }
  if ((message.method === 'item/started' || message.method === 'item/completed') && params.item && BLOCKED_ITEMS.has(params.item.type)) {
    const blockedType = params.item.type;
    // Tripwire tetap: giliran dihentikan SEGERA agar tool bawaan tidak sempat jalan.
    const deadThread = threadId;
    if (deadThread) {
      deadThreads.add(deadThread);
      send({method: 'turn/interrupt', id: 90 + deadThreads.size, params: {threadId: deadThread, turnId: currentTurnId || params.turnId || ''}});
    }
    // Teks yang sudah lengkap berisi <tool_use> tetap bisa dipakai Mythos.
    if (answer.indexOf('</tool_use>') >= 0) {
      stopProcessGroup();
      finish(null);
      return;
    }
    // patch9: pencarian web bawaan diterjemahkan menjadi WebSearch milik Mythos (kueri dari item), tanpa ulang dan tanpa galat.
    const translated = nativeToMythosCall(params.item);
    if (translated) {
      answer += translated;
      emit({type: 'delta', text: translated});
      stopProcessGroup();
      finish(null);
      return;
    }
    if (nativeRetries < MAX_NATIVE_RETRIES && deadThread) {
      nativeRetries += 1;
      // Kalimat pembuka yang sudah tampil tidak diulang; lanjutkan langsung dengan <tool_use>.
      const already = answer.trim() ? 'Kalimat pembuka sudah tampil ke pengguna; JANGAN mengulanginya, langsung tulis <tool_use>.\n' : '';
      retryPrompt = nativeReminder(nativeRetries, blockedType) + already + prompt;
      purgeThread(deadThread);
      threadId = '';
      currentTurnId = '';
      currentText = '';
      startThread(true);
      return;
    }
    stopProcessGroup();
    finish('Codex mencoba memakai tool bawaan (' + blockedType + ') ' + (nativeRetries + 1) + ' kali; Mythos membatalkannya. Coba kirim ulang atau ganti model.', true);
    return;
  }
  if (message.method === 'item/agentMessage/delta') {
    const delta = params.delta || '';
    if (typeof delta === 'string' && delta.length) {
      answer += delta;
      currentText += delta;
      mark('text');
      emit({type: 'delta', text: delta});
    }
    return;
  }
  if (message.method === 'item/completed') {
    const item = params.item || {};
    if (item.type === 'agentMessage' || item.type === 'agent_message') {
      const full = typeof item.text === 'string' ? item.text : '';
      if (full && currentText.length === 0) {
        answer += full;
        emit({type: 'delta', text: full});
      } else if (full && full.startsWith(currentText)) {
        const rest = full.slice(currentText.length);
        answer += rest;
        if (rest) emit({type: 'delta', text: rest});
      }
      currentText = '';
    }
    return;
  }
  if (message.method === 'error') {
    const detail = params.error && params.error.message || params.message;
    if (detail) stderr = String(detail).slice(-8000);
    return;
  }
  if (message.method === 'turn/completed') {
    const turn = params.turn || {};
    const status = turn.status || '';
    if (status && status !== 'completed' && status !== 'complete') {
      finish(cleanError(turn.error) || ('Giliran Codex berakhir dengan status: ' + status));
    } else if (!answer) {
      finish('Codex tidak mengeluarkan teks jawaban.');
    } else {
      finish(null);
    }
  }
}

function validSocketParams() {
  return Number.isInteger(PORT) && PORT >= 1 && PORT <= 65535 && /^[A-Za-z0-9_-]{32,128}$/.test(TOKEN);
}
// optional=true (prompt lewat argumen): kegagalan soket diabaikan, sesi tetap jalan dan hasil tetap sampai lewat stdout.
function connectSocket(optional) {
  try {
    socket = net.connect({host: '127.0.0.1', port: PORT});
  } catch (e) {
    socket = null;
    if (!optional) finish('Tidak dapat tersambung ke aplikasi: ' + e.message);
    return;
  }
  socket.setNoDelay(true);
  socket.on('connect', () => {
    socket.write(TOKEN + '\n');
    sockReady = true;
    const queued = sockQueue; sockQueue = [];
    queued.forEach(l => { try { socket.write(l); } catch (_) {} });
  });
  socket.on('data', chunk => {
    socketBuffer += chunk.toString('utf8');
    if (socketBuffer.length > 48000000) { finish('Permintaan dari aplikasi melebihi batas ukuran buffer.'); return; }
    let nl;
    while ((nl = socketBuffer.indexOf('\n')) >= 0) {
      const line = socketBuffer.slice(0, nl);
      socketBuffer = socketBuffer.slice(nl + 1);
      if (line.trim() === 'cancel') { stopProcessGroup(); finish('Dibatalkan oleh aplikasi.'); continue; }
      try {
        const request = JSON.parse(line);
        if (optional) continue;
        startSession(request);
      } catch (e) { finish('Permintaan dari aplikasi tidak valid: ' + e.message); }
    }
  });
  socket.on('error', e => {
    sockReady = false; sockQueue = [];
    if (!optional && !ended) finish('Sambungan langsung ke aplikasi terputus: ' + e.message);
  });
  socket.on('close', () => {
    sockReady = false; sockQueue = [];
    if (optional) return;
    if (!ended && child) {
      if (child.stdin && !child.stdin.destroyed) {
        try { child.stdin.end(); } catch (_) {}
      }
      stopProcessGroup();
    }
  });
}

// Native selalu dimulai lewat soket terautentikasi; mode model-saja dapat membawa prompt lewat argumen.
for (const sig of ['SIGTERM', 'SIGHUP', 'SIGINT']) {
  process.on(sig, () => {
    stopProcessGroup();
    finish('Dibatalkan oleh aplikasi.');
    setTimeout(() => process.exit(process.exitCode || 1), 4000);
  });
}

if (ARGV_PROMPT && !NATIVE) {
  let decoded = '';
  try { decoded = Buffer.from(PROMPT_B64, 'base64').toString('utf8'); } catch (_) {}
  if (validSocketParams()) connectSocket(true);
  startSession({prompt: decoded});
} else if (!validSocketParams()) {
  process.stderr.write('Parameter sesi Codex tidak valid.\n');
  process.exit(2);
} else {
  connectSocket(false);
}
