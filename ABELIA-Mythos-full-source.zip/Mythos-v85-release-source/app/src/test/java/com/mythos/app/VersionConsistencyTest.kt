package com.mythos.app

import com.mythos.app.agent.TermuxLauncher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.Properties

/** Menjaga agar nomor versi tidak melenceng lagi dari changelog (audit v83, temuan 6). Tes dijalankan dari folder `app/`. */
class VersionConsistencyTest {
    private fun props(): Properties = Properties().apply { File("../gradle.properties").inputStream().use { load(it) } }

    @Test fun versiBerasalDariSatuSumberDanCocokDenganChangelogTerbaru() {
        val p = props()
        val code = p.getProperty("mythosVersionCode").trim().toInt()
        assertEquals("1.0.$code", p.getProperty("mythosVersionName").trim())
        val latest = File("../docs/changelog").listFiles { f -> f.name.startsWith("CHANGELOG-v") }!!
            .mapNotNull { Regex("""CHANGELOG-v(\d+)""").find(it.name)?.groupValues?.get(1)?.toInt() }.maxOrNull()!!
        assertEquals("versionCode harus sama dengan nomor changelog terbaru", latest, code)
    }

    @Test fun namaApkDanArtefakCiMengikutiVersionCode() {
        val code = props().getProperty("mythosVersionCode").trim()
        val gradle = File("build.gradle.kts").readText()
        val name = Regex("""archivesName\.set\("Mythos-v(\d+)[^"]*"\)""").find(gradle)?.groupValues?.get(1)
        assertEquals("archivesName harus memuat versionCode saat ini", code, name)
        val ci = File("../.github/workflows/ci.yml").readText()
        assertTrue("nama artefak CI harus memuat v$code", ci.contains("Mythos-v$code"))
        assertFalse("CI tidak boleh menyebut versi lain", Regex("""Mythos-v(?!$code)\d+""").containsMatchIn(ci))
        assertFalse("README tidak boleh menyebut APK versi lain", Regex("""Mythos-v(?!$code)\d+[^\s]*\.apk""").containsMatchIn(File("../README.md").readText()))
    }

    @Test fun buildGradleTidakMenuliskanVersiKeras() {
        val gradle = File("build.gradle.kts").readText()
        assertTrue(gradle.contains("versionCode = mythosVersionCode"))
        assertTrue(gradle.contains("versionName = mythosVersionName"))
        assertFalse(Regex("""versionCode\s*=\s*\d+""").containsMatchIn(gradle))
        assertFalse(Regex("""versionName\s*=\s*"""").containsMatchIn(gradle))
    }

    @Test fun runnerCodexMemakaiPlaceholderVersiBukanAngkaKeras() {
        val src = File("src/main/assets/codex_app_server.js").readText()
        assertTrue(src.contains(TermuxLauncher.VERSION_PLACEHOLDER))
        assertFalse(Regex("""version:\s*'\d+\.\d+""").containsMatchIn(src))
        val out = TermuxLauncher.withAppVersion(src, "1.0.83")
        assertFalse(out.contains(TermuxLauncher.VERSION_PLACEHOLDER))
        assertTrue(out.contains("version: '1.0.83'"))
        // versionName aneh tidak boleh menyusup ke kode JS
        assertTrue(TermuxLauncher.withAppVersion(src, "1'); process.exit(); ('").contains("version: '0'"))
    }

    @Test fun releaseTidakDitandatanganiDenganDebugKeySecaraDefault() {
        val p = props()
        assertEquals("false", p.getProperty("useDebugKeystoreForRelease").trim())
        val gradle = File("build.gradle.kts").readText()
        assertTrue(gradle.contains("if (useDebugKeystoreForRelease)"))
        assertTrue(gradle.contains("signingConfigs.getByName(\"debug\")"))
        assertTrue("release key harus terpisah dari debug key", gradle.contains("releaseKeystorePropertiesFile"))
    }

    @Test fun ciMemvalidasiWrapperGradle() {
        val ci = File("../.github/workflows/ci.yml").readText()
        assertTrue(ci.contains("gradle/actions/wrapper-validation@"))
    }
}
