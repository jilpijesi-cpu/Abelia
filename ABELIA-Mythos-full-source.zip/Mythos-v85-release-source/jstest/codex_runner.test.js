'use strict';
// Uji runner Codex (app/src/main/assets/codex_app_server.js) dengan `codex` palsu. Jalankan: node jstest/codex_runner.test.js
const assert = require('assert');
const cp = require('child_process');
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');

const RUNNER = path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'codex_app_server.js');
const TOKEN = 'a'.repeat(40);

const FAKE_CODEX = `#!/usr/bin/env node
const fs = require('fs');
const log = process.env.FAKE_LOG;
fs.appendFileSync(log, JSON.stringify({argv: process.argv.slice(2)}) + '\\n');
let buf = '';
const out = o => process.stdout.write(JSON.stringify(o) + '\\n');
let thread = 'thread-12345678'; let nth = 0;
process.stdin.on('data', c => {
  buf += c;
  let i;
  while ((i = buf.indexOf('\\n')) >= 0) {
    const line = buf.slice(0, i); buf = buf.slice(i + 1);
    if (!line.trim()) continue;
    const m = JSON.parse(line);
    fs.appendFileSync(log, JSON.stringify({recv: m}) + '\\n');
    if (m.method === 'initialize') out({id: m.id, result: {}});
    else if (m.method === 'thread/start') { nth += 1; thread = 'thread-1234567' + nth; out({id: m.id, result: {thread: {id: thread}}}); }
    else if (m.method === 'turn/start') {
      if (process.env.FAKE_WRITE) { // PATCH31: Codex palsu mengubah, membuat, dan menghapus berkas di direktori kerjanya
        fs.writeFileSync('a.txt', 'diubah codex');
        fs.mkdirSync('uploads', {recursive: true});
        fs.writeFileSync('uploads/baru.txt', 'dibuat codex');
        fs.unlinkSync('del.txt');
        fs.writeFileSync('besar.bin', Buffer.alloc(800 * 1024, 1));
        fs.appendFileSync(log, JSON.stringify({secretsAbsentAtStart: !fs.existsSync('.env') && !fs.existsSync('.codex/auth.json') && !fs.existsSync('secret.pem')}) + '\\n');
        fs.writeFileSync('.env', 'API_TOKEN=must-not-return');
        fs.mkdirSync('.codex', {recursive: true});
        fs.writeFileSync('.codex/auth.json', '{\"token\":\"secret\"}');
        fs.writeFileSync('generated-key.pem', 'PRIVATE KEY');
        fs.mkdirSync('.git', {recursive: true});
        fs.writeFileSync('.git/x', 'jangan dikembalikan');
        fs.appendFileSync(log, JSON.stringify({cwd: process.cwd()}) + '\\n');
      }
      out({id: m.id, result: {turn: {id: 'turn-1'}}});
      const item = {type: 'commandExecution', id: 'it1', command: ['bash', '-lc', 'echo hai'], cwd: process.cwd()};
      out({method: 'item/started', params: {threadId: thread, turnId: 'turn-1', item}});
      out({id: 500, method: 'item/commandExecution/requestApproval', params: {threadId: thread, turnId: 'turn-1', itemId: 'it1', command: 'echo hai', cwd: process.cwd()}});
    } else if (m.id === 500) {
      const d = m.result && m.result.decision;
      out({method: 'item/agentMessage/delta', params: {threadId: thread, delta: 'hasil:' + d}});
      out({method: 'turn/completed', params: {threadId: thread, turn: {status: 'completed'}}});
    }
  }
});
`;

function setup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mythos-runner-'));
  const bin = path.join(dir, 'codex');
  fs.writeFileSync(bin, FAKE_CODEX, {mode: 0o755});
  return {dir, log: path.join(dir, 'log.jsonl')};
}

// Menjalankan runner (Codex palsu selalu meminta izin menjalankan `echo hai`).
function run({native, useSocket = true}) {
  const {dir, log} = setup();
  return new Promise((resolve, reject) => {
    const events = [];
    let sock = null;
    const server = net.createServer(s => {
      sock = s;
      let b = '';
      let handshake = false;
      s.on('data', d => {
        b += d.toString('utf8');
        let i;
        while ((i = b.indexOf('\n')) >= 0) {
          const line = b.slice(0, i); b = b.slice(i + 1);
          if (!handshake) {
            assert.strictEqual(line, TOKEN); handshake = true;
            if (native) s.write(JSON.stringify({prompt: 'halo'}) + '\n');
            continue;
          }
          const ev = JSON.parse(line);
          events.push(ev);
        }
      });
      s.on('error', () => {});
    });
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      const env = Object.assign({}, process.env, {PATH: dir + path.delimiter + process.env.PATH, FAKE_LOG: log, HOME: dir});
      if (native) env.MYTHOS_CODEX_NATIVE = '1'; else delete env.MYTHOS_CODEX_NATIVE;
      const prompt = Buffer.from('halo').toString('base64');
      const args = native
        ? [RUNNER, String(useSocket ? port : 0), useSocket ? TOKEN : 'x']
        : [RUNNER, String(useSocket ? port : 0), useSocket ? TOKEN : 'x', prompt];
      const child = cp.spawn(process.execPath, args, {env, cwd: dir});
      let stdout = '';
      child.stdout.on('data', c => { stdout += c; });
      const killer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('timeout; stdout=' + stdout)); }, 15000);
      child.on('close', () => {
        clearTimeout(killer);
        server.close();
        const lines = stdout.split('\n').filter(Boolean).map(l => JSON.parse(l));
        const fake = fs.existsSync(log) ? fs.readFileSync(log, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l)) : [];
        resolve({events, lines, fake, exitCode: child.exitCode, dir});
      });
    });
  });
}

// PATCH31: permintaan lewat soket membawa "workspace"; runner bekerja di ~/mythos-work/<id>/ lalu mengirim balik perubahan.
function runWorkspace() {
  const {dir, log} = setup();
  const home = path.join(dir, 'home');
  fs.mkdirSync(home, {recursive: true});
  const oldWorkspace = path.join(home, 'mythos-work', 'proyek-1');
  fs.mkdirSync(path.join(oldWorkspace, '.codex'), {recursive: true});
  const outsideDir = path.join(home, 'outside');
  fs.mkdirSync(outsideDir, {recursive: true});
  fs.symlinkSync(outsideDir, path.join(oldWorkspace, 'linked'), 'dir');
  fs.writeFileSync(path.join(oldWorkspace, '.env'), 'STALE_TOKEN=old-version-secret');
  fs.writeFileSync(path.join(oldWorkspace, '.codex/auth.json'), 'stale token');
  fs.writeFileSync(path.join(oldWorkspace, 'secret.pem'), 'stale private key');
  const b64 = t => Buffer.from(t).toString('base64');
  return new Promise((resolve, reject) => {
    const events = [];
    const server = net.createServer(s => {
      let b = '', handshake = false;
      s.on('data', d => {
        b += d.toString('utf8');
        let i;
        while ((i = b.indexOf('\n')) >= 0) {
          const line = b.slice(0, i); b = b.slice(i + 1);
          if (!handshake) {
            assert.strictEqual(line, TOKEN); handshake = true;
            s.write(JSON.stringify({prompt: 'halo', workspace: {id: 'proyek-1', files: [
              {path: 'a.txt', b64: b64('asli')}, {path: 'del.txt', b64: b64('hapus aku')},
              {path: 'uploads/x/ada.txt', b64: b64('lampiran')}, {path: '../keluar.txt', b64: b64('jahat')}, {path: '.git/config', b64: b64('x')},
              {path: '.env', b64: b64('API_TOKEN=do-not-copy')}, {path: '.codex/auth.json', b64: b64('token')}, {path: 'secret.pem', b64: b64('private key')}, {path: 'linked/escaped.txt', b64: b64('must-not-escape')},
            ]}}) + '\n');
            continue;
          }
          const ev = JSON.parse(line);
          events.push(ev);
        }
      });
      s.on('error', () => {});
    });
    server.listen(0, '127.0.0.1', () => {
      const env = Object.assign({}, process.env, {PATH: dir + path.delimiter + process.env.PATH, FAKE_LOG: log, HOME: home, FAKE_WRITE: '1', MYTHOS_CODEX_NATIVE: '1'});
      const child = cp.spawn(process.execPath, [RUNNER, String(server.address().port), TOKEN], {env, cwd: dir});
      const killer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('timeout')); }, 15000);
      child.on('close', () => {
        clearTimeout(killer); server.close();
        const fake = fs.readFileSync(log, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l));
        resolve({events, fake, home, dir, outsideDir});
      });
    });
  });
}

const text = lines => lines.filter(e => e.type === 'delta').map(e => e.text).join('');
const tests = [];
const test = (name, fn) => tests.push([name, fn]);

test('native: akses penuh (approvalPolicy never + danger-full-access), tanpa dialog; izin yang tetap diminta Codex dijawab accept', async () => {
  const r = await run({native: true});
  assert.ok(!r.events.some(e => e.type === 'approval'), 'tidak boleh ada event approval ke aplikasi');
  assert.ok(text(r.lines).includes('hasil:accept'), text(r.lines));
  assert.ok(!r.lines.some(e => e.type === 'error'), JSON.stringify(r.lines));
  const argv = r.fake.find(x => x.argv).argv.join(' ');
  assert.ok(!argv.includes('features.shell_tool=false'), argv);
  assert.ok(!argv.includes('project_doc_max_bytes=0'), argv);
  assert.ok(!argv.includes('web_search'), argv);
  const ts = r.fake.find(x => x.recv && x.recv.method === 'thread/start').recv.params;
  assert.strictEqual(ts.approvalPolicy, 'never');
  assert.strictEqual(ts.sandbox, 'danger-full-access');
  const tp = r.fake.find(x => x.recv && x.recv.method === 'turn/start').recv.params;
  assert.strictEqual(tp.approvalPolicy, 'never');
  const scratchRoot = path.join(r.dir, 'mythos-work');
  assert.ok(!fs.existsSync(scratchRoot) || fs.readdirSync(scratchRoot).length === 0, 'folder sesi sementara harus dibersihkan setelah proses berhenti');
});

test('native: tanpa soket aplikasi tidak memulai Codex dan gagal tertutup', async () => {
  const r = await run({native: true, useSocket: false});
  assert.notStrictEqual(r.exitCode, 0);
  assert.ok(r.lines.some(e => e.type === 'error') || r.fake.length === 0, JSON.stringify(r));
});

test('non-native (model-saja): pengerasan penuh, shell bawaan dibatalkan dan TIDAK diterjemahkan ke alat Termux, tidak ada approval', async () => {
  const r = await run({native: false});
  const argv = r.fake.find(x => x.argv).argv.join(' ');
  assert.ok(argv.includes('features.shell_tool=false'), argv);
  assert.ok(!r.lines.some(e => e.type === 'approval'));
  const t = text(r.lines);
  assert.ok(!t.includes('Termux'), t);
  assert.ok(!t.includes('<tool_use>'), t); // dulu: <tool_use> Termux; kini tidak ada terjemahan shell sama sekali
  assert.ok(t.includes('hasil:decline'), t); // izin eksekusi di mode model-saja selalu ditolak
  const ts = r.fake.find(x => x.recv && x.recv.method === 'thread/start').recv.params;
  assert.strictEqual(ts.sandbox, 'read-only');
  assert.strictEqual(ts.approvalPolicy, 'on-request');
});

function runWorkspaceRootSymlink() {
  const {dir, log} = setup();
  const home = path.join(dir, 'home');
  const outside = path.join(dir, 'outside');
  fs.mkdirSync(home, {recursive: true});
  fs.mkdirSync(outside, {recursive: true});
  fs.writeFileSync(path.join(outside, '.env'), 'DO_NOT_DELETE=secret');
  fs.mkdirSync(path.join(home, 'mythos-work'), {recursive: true});
  fs.symlinkSync(outside, path.join(home, 'mythos-work', 'proyek-1'), 'dir');
  return new Promise((resolve, reject) => {
    const server = net.createServer(s => {
      let b = '', handshake = false;
      s.on('data', d => {
        b += d.toString('utf8');
        let i;
        while ((i = b.indexOf('\n')) >= 0) {
          const line = b.slice(0, i); b = b.slice(i + 1);
          if (!handshake) { assert.strictEqual(line, TOKEN); handshake = true; s.write(JSON.stringify({prompt: 'halo', workspace: {id: 'proyek-1', files: []}}) + '\n'); }
        }
      });
      s.on('error', () => {});
    });
    server.listen(0, '127.0.0.1', () => {
      const env = Object.assign({}, process.env, {PATH: dir + path.delimiter + process.env.PATH, FAKE_LOG: log, HOME: home, MYTHOS_CODEX_NATIVE: '1'});
      const child = cp.spawn(process.execPath, [RUNNER, String(server.address().port), TOKEN], {env, cwd: dir});
      let stdout = '';
      child.stdout.on('data', c => { stdout += c; });
      const killer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('timeout pada symlink root')); }, 10000);
      child.on('close', () => {
        clearTimeout(killer); server.close();
        const lines = stdout.split('\n').filter(Boolean).map(l => JSON.parse(l));
        const fake = fs.existsSync(log) ? fs.readFileSync(log, 'utf8') : '';
        resolve({outside, lines, fake, exitCode: child.exitCode});
      });
    });
  });
}

test('workspace: berkas dari aplikasi ditulis ke ~/mythos-work/<id>, Codex bekerja di sana, perubahan dikirim balik sebelum done', async () => {
  const r = await runWorkspace();
  const work = path.join(r.home, 'mythos-work', 'proyek-1');
  assert.strictEqual(fs.realpathSync(r.fake.find(x => x.cwd).cwd), fs.realpathSync(work));
  assert.ok(!fs.existsSync(path.join(r.home, 'mythos-work', 'keluar.txt')) && !fs.existsSync(path.join(r.dir, 'keluar.txt')), 'path ".." harus ditolak');
  const files = r.events.filter(e => e.type === 'file');
  const byPath = Object.fromEntries(files.map(e => [e.path, Buffer.from(e.b64, 'base64').toString()]));
  assert.ok(r.fake.some(x => x.secretsAbsentAtStart === true), 'rahasia dari workspace lama harus dibersihkan sebelum Codex berjalan');
  assert.strictEqual(byPath['a.txt'], 'diubah codex');
  assert.strictEqual(byPath['uploads/baru.txt'], 'dibuat codex');
  assert.ok(!('uploads/x/ada.txt' in byPath), 'berkas tak berubah tidak dikirim balik');
  assert.ok(!fs.existsSync(path.join(r.outsideDir, 'escaped.txt')), 'penulisan lewat symlink di dalam workspace harus ditolak');
  assert.ok(!fs.existsSync(path.join(work, 'linked')) || !fs.lstatSync(path.join(work, 'linked')).isSymbolicLink(), 'symlink workspace harus dihapus sebelum Codex mulai');
  assert.ok(!('besar.bin' in byPath), 'berkas > 700 KB tidak dikirim balik');
  assert.ok(!Object.keys(byPath).some(k => k.startsWith('.git')), '.git tidak dikembalikan');
  assert.ok(!Object.keys(byPath).some(k => k === '.env' || k.startsWith('.codex/') || k.endsWith('.pem')), 'berkas rahasia tidak boleh disalin balik');
  const done = r.events.find(e => e.type === 'files_done');
  assert.deepStrictEqual(done.deleted, ['del.txt']);
  assert.ok(done.skipped.includes('besar.bin'));
  const iDone = r.events.findIndex(e => e.type === 'files_done');
  const iEnd = r.events.findIndex(e => e.type === 'done');
  assert.ok(iDone >= 0 && iEnd > iDone, 'files_done harus lebih dulu dari done: ' + JSON.stringify(r.events.map(e => e.type)));
});

test('workspace: root proyek berupa symlink ditolak tanpa menyentuh target', async () => {
  const r = await runWorkspaceRootSymlink();
  assert.notStrictEqual(r.exitCode, 0);
  assert.ok(r.lines.some(e => e.type === 'error'), JSON.stringify(r.lines));
  assert.strictEqual(r.fake, '', 'Codex tidak boleh dijalankan di dalam symlink');
  assert.strictEqual(fs.readFileSync(path.join(r.outside, '.env'), 'utf8'), 'DO_NOT_DELETE=secret');
});

(async () => {
  let failed = 0;
  for (const [name, fn] of tests) {
    try { await fn(); console.log('ok   - ' + name); }
    catch (e) { failed++; console.log('FAIL - ' + name + '\n' + (e && e.stack || e)); }
  }
  process.exit(failed ? 1 : 0);
})();
