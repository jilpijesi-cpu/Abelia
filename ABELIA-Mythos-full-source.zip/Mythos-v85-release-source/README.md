# Mythos

## Alur aplikasi
Beranda -> ketik tugas -> (jika belum diatur) layar Model & penyedia -> layar obrolan yang menjalankan agen.
- Ketuk label model di kolom input untuk membuka pengaturan (penyedia, API key terenkripsi Keystore). Model dipilih OTOMATIS:
  aplikasi mengambil daftar model dari penyedia (sesuai hak akses key), mengurutkan menurut perkiraan mutu, lalu mengetes SATU PER SATU dengan permintaan kecil.
  Model pertama yang merespons langsung dipakai dan pengujian berhenti (tidak menunggu model lain). Model yang kuota/kreditnya habis, error, atau tidak merespons
  dalam 10 detik (Ollama lokal: 60 detik) dilewati ke model berikutnya. OpenRouter dikecualikan: modelnya terkunci `openrouter/free`. Beberapa model berikutnya disiapkan sebagai cadangan TANPA diuji; model/kunci yang error atau sibuk saat tugas berjalan
  diganti sendiri ke cadangan itu, diam-diam di latar belakang (tanpa notifikasi di obrolan; hanya kegagalan total yang ditampilkan).
  Model reasoning yang menolak `temperature`/`max_tokens` (HTTP 400) disesuaikan otomatis (tanpa temperature, `max_completion_tokens`), saat uji maupun saat tugas berjalan; tidak ada tombol "Mode model reasoning" lagi. Hasil pemeriksaan di-cache 15 menit, jadi tugas berikutnya langsung jalan. Begitu kunci dimasukkan di Pengaturan, aplikasi langsung memindai dengan cara yang sama (terbaik dulu, berhenti di yang pertama merespons) dan hasilnya dipakai tugas berikutnya tanpa tes ulang.
  Nama model manual (opsional) hanya dicoba lebih dulu; cadangan otomatis tetap dipakai.
- Obrolan menampilkan alur streaming seperti rekaman aplikasi Claude: narasi singkat agen mengalir selagi model menulis, tiap kelompok langkah
  menjadi satu baris aktivitas yang bisa diketuk, dan jawaban akhir mengalir di tempat yang sama. Rencana tampil sebagai daftar tugas.
- Aksi berisiko memunculkan dialog Izinkan/Tolak (ringkasannya bisa digulir): `Delete`, dan `GithubBuild` saat workflow baru/berubah. AskUserQuestion memunculkan dialog pertanyaan.
- Hasil proyek ada di filesDir/projects/<nama>; menu di bilah atas mengekspornya sebagai ZIP.
- Menekan Kembali / "Chat baru" saat agen masih bekerja menampilkan konfirmasi (Hentikan & keluar / Tetap di sini); chat lain tak bisa dibuka sebelum tugas dihentikan.
- Draf pesan, pilihan incognito, dan isian Pengaturan yang belum disimpan disimpan di ViewModel: selamat dari rotasi layar dan dari berpindah ke Pengaturan.
- Dari beranda, tugas baru selalu membuat proyek baru; tugas lanjutan di layar obrolan memakai proyek yang sama.
- Build proyek pengguna dapat dijalankan lewat GitHub Actions dari Pengaturan > Build. Isi nama repo (`pemilik/nama`) dan token fine-grained dengan izin Contents: Read and write, Workflows: Read and write, serta Actions: Read (token classic memerlukan scope `repo` + `workflow`). Repo harus memiliki minimal satu commit. Build aplikasi Mythos sendiri dilakukan lokal melalui Android Studio/`./gradlew` seperti bagian Build di bawah. Termux digunakan untuk integrasi Codex CLI dan alat shell agen.
  Workflows wajib karena agen menulis file di `.github/workflows/`; tanpa izin itu GitHub menolak push-nya.
  Alat `GithubBuild` mem-push proyek sebagai satu commit ke branch `mythos/<proyek>` (branch utama tidak disentuh), menunggu run GitHub Actions
  untuk commit itu (trigger `push`), lalu mengembalikan hasil + potongan log job yang gagal. Run hijau berarti workflow yang ditulis agen lolos,
  bukan jaminan bahwa workflow itu benar-benar membangun/menguji aplikasinya.
  - Berkas asli lampiran di `uploads/` (gambar/PDF/dokumen/zip) TIDAK dikirim ke GitHub; folder hasil ekstrak zip tetap ikut.
  - File teks yang baru/berubah dikirim inline di dalam permintaan tree (tanpa satu permintaan per file) supaya tidak menabrak batas laju sekunder
    GitHub; hanya file biner yang diunggah sebagai blob. Branch diperbarui lewat POST + `X-HTTP-Method-Override: PATCH` (atomik), jatuh ke DELETE + POST bila ditolak.
  - Workflow dijalankan GitHub dengan secrets repo. Karena itu workflow yang baru/berubah SELALU meminta persetujuan pengguna (isinya ditampilkan)
    sebelum didorong, apa pun mode izinnya. Pakai repo khusus tanpa secrets dan token fine-grained yang dibatasi ke repo itu.
  Agen harus menulis sendiri `.github/workflows/*.yml` dengan `on: { push: { branches: ['mythos/**'] } }`; tanpa itu `GithubBuild` menolak.
  Tanpa token/repo, agen tetap menulis kode tetapi tidak bisa build/tes (ada pemberitahuan di obrolan).
- Browser Agent: tombol kirim langsung menjalankan perintah tunggal yang jelas, atau menyerahkan kalimat bebas/tujuan majemuk ke agen otonom. Pemantau live menampilkan langkah, fase, aksi, dan riwayat; elemen yang dikerjakan disorot di halaman. Tindakan final tetap menunggu konfirmasi pengguna.
- Riwayat: ikon sidebar di beranda membuka daftar obrolan/proyek (tersimpan di penyimpanan privat aplikasi; tidak ikut cadangan cloud karena `allowBackup=false`).
  Disimpan di awal, tiap ±2 detik selama agen bekerja, dan di akhir, sehingga progres tidak hilang bila proses dimatikan.
  Ketuk untuk melanjutkan; ikon sampah (atau tekan lama) menghapus riwayat saja atau beserta file proyek.
  Tugas yang gagal/dihentikan tetap dicatat di konteks sehingga "lanjutkan" pada giliran berikutnya tahu apa yang terjadi.
- Incognito: tidak masuk riwayat. Folder proyeknya di `cacheDir/incognito` dan dihapus tiap proses aplikasi baru. Pesan tetap dikirim ke penyedia model yang dipilih.
- Tugas berjalan di layanan latar (`AgentService`, foreground type `dataSync`, notifikasi "Mythos sedang bekerja" + wake lock parsial) agar tugas panjang tidak mati
  saat layar padam / aplikasi di latar belakang. Layanan hanya menjaga proses; agennya tetap berjalan di ViewModel. Izin notifikasi (Android 13+) ditanyakan sekali.
- Kunci: tiap penyedia memakai kunci utama dari Pengaturan, ditambah kunci tambahan (opsional, tersimpan terenkripsi Keystore).
  Tetap di satu kunci selama sehat; pindah saat 429/kuota habis/401-403/5xx/jaringan; kunci pulih dipakai lagi.
  Permintaan yang ditolak 400/413/422 hanya mengistirahatkan entri 45 detik; bila SEMUA entri menolak permintaan yang sama, tugas gagal seketika
  dan tidak ada kunci yang dihukum. Tidak ada kunci yang tertanam di APK.
- Codex CLI: pilih Codex di Pengaturan > Model, lalu gunakan tombol **Pasang & masuk dengan ChatGPT** atau **Masuk dengan ChatGPT**.
  Login berjalan dalam sesi Termux yang terlihat; `codex login status` memverifikasi autentikasi.
  Paket `nodejs` dan `codex` dipasang dari repositori Termux yang aktif. Password/token ChatGPT tetap dikelola Codex CLI di Termux.
  Default menjalankan `codex app-server` per completion melalui `RUN_COMMAND` dan socket loopback acak sementara; process group Codex/MCP
  dihentikan saat selesai atau dibatalkan. Tidak ada mode "selalu aktif": jalur app-server persisten (foreground service `specialUse`,
  boot receiver, runner persisten) dihapus di v83 karena tidak pernah aktif dan sering putus.
  Bila soket pembatalan tidak sampai, aplikasi mematikan runner lewat `pkill` (port+token sesi); berkas live/runner sementara yang lebih tua dari
  60 menit dibersihkan di awal tiap sesi.
  Sesi memakai socket loopback dengan port/token acak; tidak ada daemon Python, endpoint HTTP, token bridge, atau port tetap 8787.
  Bila Termux menolak perintah aplikasi, aktifkan `allow-external-apps=true` di `~/.termux/termux.properties`.
  **Mode native (bawaan hidup, PATCH33):** Codex adalah SATU-SATUNYA jalur ke Termux. Ia berjalan di salinan proyek pada `~/mythos-work/<id>` (atau
  folder sesi sementara untuk chat tanpa proyek) dengan `approvalPolicy: 'never'` dan sandbox `danger-full-access`: akses penuh ke Termux, tanpa
  dialog persetujuan. Penyedia lain (Gemini, OpenAI, Anthropic, dll.) tidak punya alat Termux dan tidak diberi tahu jalurnya ada.
  Risiko yang diterima pemilik: instruksi tersembunyi di web/email yang dibaca Codex dapat langsung menjalankan perintah di Termux.
  **Mode model-saja (sakelar native dimatikan):** Codex hanya menghasilkan completion; tool bawaan Codex dibatasi (`features.shell_tool=false`,
  `read-only`) dan tidak ada akses shell sama sekali.
  Dalam kedua mode, native membutuhkan socket aplikasi terautentikasi; tanpa socket sesi gagal tertutup. `approvalPolicy: 'untrusted'` sudah tidak
  digunakan. Thread dibuat `ephemeral` bila didukung dan berkas rollout miliknya di `~/.codex/sessions` dihapus setelah selesai (set
  `MYTHOS_KEEP_CODEX_SESSIONS=1` untuk menyimpannya). Tag pembatas prompt di dalam isi pesan dinetralkan; handshake socket dibatasi dan token
  dibandingkan waktu-konstan. Runner ditulis atomik (`mv`) agar sesi paralel tidak membaca `app_server.js` yang terpotong.
- HTTP polos (cleartext) hanya diizinkan ke `localhost`, `127.0.0.1`, dan `10.0.2.2` (Ollama lokal/emulator) lewat `network_security_config.xml`;
  semua tujuan lain wajib HTTPS. Ollama di jaringan lokal: tambahkan IP-nya di berkas itu.
- Build release memakai R8 (`isMinifyEnabled`) dan `isShrinkResources`; aturan keep ada di `proguard-rules.pro`.

Layar beranda Mythos (Jetpack Compose) + inti agen AI (paket `com.mythos.app.agent`).
Kotlin 1.9.24, AGP 8.6.1, Gradle 8.7, minSdk 26.

## Build
- Android Studio: File > Open > pilih folder ini > tunggu sync > Run.
- Terminal (JDK 17 + Android SDK, ANDROID_HOME terisi):
    ./gradlew assembleDebug               # APK: app/build/outputs/apk/debug/Mythos-v85-debug.apk
    ./gradlew test                        # uji unit logika agen

## CI untuk Mythos sendiri
`.github/workflows/ci.yml` (bukan untuk proyek yang dibuat agen): pada push ke `main`/`master`, pull request, dan manual menjalankan
`./gradlew :app:testDebugUnitTest`, `:app:lintDebug` (gate yang memblokir), `:app:assembleDebug`, dan `:app:assembleRelease` (cek R8), lalu mengunggah laporan tes, laporan lint,
dan APK debug sebagai artefak.
- Action GitHub dipatok ke commit SHA penuh; Gradle wrapper memverifikasi ZIP distribusi dengan SHA-256 resmi Gradle 8.7.
- Cabang `mythos/**` sengaja tidak memicu CI ini, supaya alat `GithubBuild` aplikasi tidak ikut memicunya bila repo yang sama dipakai sebagai target build.

## Alat pengaduan, pengaman, GitHub & Google (v76)
`CaseLedger` (catatan kasus + hitung tenggat), playbook bawaan BI/OJK/e-commerce, `SensitiveDataGuard` (konten eksternal), `SecurityAuditLog`, unduh PDF publik lewat `WebFetch`, alat GitHub tambahan (`GithubImportRepo`, `GithubCreatePR`, `GithubIssues`, `GithubDownloadArtifact`), dan Google Workspace (`GmailSearchRead`, `GmailDraftSend`, `GoogleCalendarSync`, `GoogleDriveCaseVault`; login di Pengaturan > Google Workspace dengan Client ID OAuth milik Anda sendiri). Rincian: `docs/changelog/CHANGELOG-v76-alat-dari-gemini.md`.

## Pengaduan dan sengketa (v70)
Alat `ComposeEmail` menampilkan kartu draf email berlampiran PDF. Tombol kartu mengirim langsung lewat Gmail API bila Gmail terhubung dan aktif; jika tidak, tombol membuka aplikasi email dan pengguna menekan Kirim di sana. Percobaan Gmail dicatat sebelum POST; bila hasilnya tidak diketahui, status tetap terkunci, tidak dicoba ulang otomatis, dan perlu rekonsiliasi manual di Gmail > Terkirim. Jangan menyamakan hasil ini dengan jaminan exactly-once. Alat ini tidak mengirim saat draf dibuat. `SetReminder` (alarm/kalender untuk tenggat),
berkas memori `KASUS.md` (dimuat otomatis), dan aturan perilaku pengaduan di prompt. Rincian: `docs/changelog/CHANGELOG-v70-pengaduan.md`.

## Titik pulih per tugas
Setiap tugas agen dicatat agar perubahannya bisa dilihat dan dibatalkan:
- Tepat SEBELUM `Write`/`Edit`/`Delete` mengubah sebuah file untuk pertama kalinya dalam satu tugas, isi aslinya disalin (copy-on-write; seluruh proyek
  tidak disalin). Saat tugas selesai (atau dihentikan/gagal di tengah jalan) isi akhirnya disalin juga dan kartu "N file diubah  +A −R" muncul di obrolan.
- Ketuk kartu untuk daftar file (A = baru, M = diubah, D = dihapus), ketuk file untuk diff-nya (konteks 3 baris, maks. 400 baris).
- "Batalkan tugas ini" mengembalikan setiap file ke keadaan sebelum tugas dan merapikan folder yang dulu dibuat agen. File yang SUDAH diubah lagi
  sesudah tugas itu (isinya beda dari isi akhir tercatat) DILEWATI, jadi pekerjaan sesudahnya tidak hilang. Pembatalan hanya bisa sekali; agen diberi tahu
  lewat catatan riwayat supaya membaca ulang file sebelum mengubahnya. Tombol nonaktif selama agen bekerja.
- Disimpan di `filesDir/checkpoints/<proyek>/<id>/` (di luar folder proyek: tak terlihat agen, tak ikut ZIP ekspor, tak didorong ke GitHub), maksimum 15 per
  proyek (yang tertua dihapus). Dihapus bersama riwayat obrolannya. Chat incognito: `cacheDir/incognito-checkpoints`, dibersihkan tiap proses baru.
- Batas: file > 10 MB tidak dicadangkan (perubahannya tak bisa dibatalkan; ditandai di laporan), file teks > 2 MB tidak dihitung barisnya, dan file biner hanya
  ditandai "biner" tanpa diff. Diff memakai LCS dengan pemangkasan awalan/akhiran; pasangan file yang terlalu besar (> 4 juta sel) ditampilkan sebagai "ganti semua".
- Hanya alat Write/Edit/Delete yang mengubah file proyek, jadi jurnal lengkap. Perubahan oleh `GithubBuild` tidak ada (ia hanya membaca).

## Memakai agen
```kotlin
val agent = MythosAgent.create(
    provider = Presets.anthropic(apiKey, "<nama-model>"),   // atau openAi / deepSeek / groq / ollama / gemini
    projectDir = File(filesDir, "projects/todo-app"),
    approver = Approver { tool, summary -> /* tampilkan dialog Setuju/Tolak */ true },
    builder = GitHubBuildService(GitHubConfig(token, "pemilik", "repo")),   // opsional; null = tanpa build
    ask = { question -> /* tampilkan pertanyaan, kembalikan jawaban pengguna */ "" },
)
lifecycleScope.launch {
    agent.events("Buat aplikasi catatan sederhana ...").collect { e ->
        when (e) {
            is AgentEvent.Thought -> {}      // alasan singkat tiap langkah
            is AgentEvent.PlanChanged -> {}  // rencana + status
            is AgentEvent.ToolStart, is AgentEvent.ToolEnd -> {}
            is AgentEvent.Notice -> {}       // format diperbaiki, duplikat diblokir, konteks dipadatkan
            is AgentEvent.Final -> {}        // ringkasan + flag verified
            is AgentEvent.Failed -> {}
        }
    }
}
```
Model OpenAI terbaru: set `temperature = null` dan `tokenParam = "max_completion_tokens"` di `ProviderConfig`.

## Logika agen (meniru siklus kerja Claude Code)
Siklus: **kumpulkan konteks -> bertindak dengan alat -> lihat hasil -> ulangi**. Model menulis teks bebas dan boleh memanggil beberapa alat
sekaligus dalam satu balasan; giliran berakhir ketika model membalas **tanpa** pemanggilan alat (teks itu adalah jawaban akhir). Tidak ada lagi
JSON `thought/final`, klasifikasi niat, penjaga sapaan, atau gerbang yang menolak jawaban akhir.
1. Transport tetap teks polos supaya pergantian model/kunci di tengah tugas mulus. Pemanggilan alat:
   `<tool_use>{"name": "Read", "input": {"file_path": "a.kt"}}</tool_use>`; hasil kembali sebagai `<tool_result id= name= is_error=>`.
   Pengingat dari aplikasi memakai `<system-reminder>`.
2. Alat (nama & parameter mengikuti Claude Code): `Read` (offset/limit, keluaran `nomor<TAB>teks`), `Edit` (old_string/new_string/replace_all),
   `Write`, `Glob`, `Grep` (output_mode content/files_with_matches/count, -i, -n, -A/-B/-C, glob, head_limit), `LS`, `TodoWrite`, `AskUserQuestion`,
   `Delete`, `GithubBuild` (hanya bila GitHub diatur), `ExitPlanMode` (hanya mode PLAN). Tidak ada Bash karena tidak ada shell di ponsel.
3. Baca-sebelum-ubah: `Edit`/`Write` pada file yang ada ditolak bila belum di-`Read` atau file berubah sejak dibaca (pesan galat seperti Claude Code).
4. Mode izin (`AgentConfig.permissionMode`): `DEFAULT` (Write/Edit/GithubBuild/Delete minta izin), `ACCEPT_EDITS` (bawaan; Delete dan GithubBuild dengan workflow
   baru/berubah minta izin), `PLAN` (hanya alat baca, rencana diajukan lewat `ExitPlanMode` dan butuh persetujuan; tersedia lewat API, juga bisa dipilih di Pengaturan > Izin).
5. Memori proyek: `CLAUDE.md` (atau `MYTHOS.md`) di akar proyek dimuat ke pesan pertama, bersama lingkungan dan pohon proyek.
6. Gaya jawaban: ringkas, langsung, tanpa pembuka/penutup, mengikuti bahasa pengguna. Sapaan bawaan "BOS" (`AgentConfig.userAddress`); isi `null` untuk mematikannya.
7. Pengaman yang dipertahankan (tidak ada di Claude Code, perlu di ponsel): aksi identik di kondisi tak berubah diblokir; 2 gagal = petunjuk,
   3 gagal = refleksi, 7 gagal = berhenti; batas giliran; hasil alat lama dipadatkan otomatis; pengingat `TodoWrite` bila lama tak diperbarui.
8. Balasan pendek yang hanya berisi niat ("Saya akan mencari ...") tanpa alat tidak dianggap jawaban akhir: agen diminta benar-benar bertindak (maks. 2 kali per tugas).
   Penutup ("Selesai."), permintaan ke pengguna ("Saya perlu tahu ...", "tolong kirim ...") dan "menunggu instruksi" dikecualikan dari deteksi ini.
9. Lampiran zip: isi hasil ekstraksi (3 tingkat teratas) disertakan di catatan lampiran agar agen langsung tahu file apa yang ada.
10. `verified` pada hasil akhir hanya informasi: true bila tidak ada file berubah yang belum dibaca ulang / belum lolos build. UI menampilkannya sebagai
    "Perubahan sudah diperiksa ulang", BUKAN jaminan kode berjalan.
11. Batas keluaran: tiap balasan dibatasi (4096 token; dinaikkan ke 8K–16K untuk keluarga model yang batasnya diketahui lega: Gemini, Anthropic, OpenAI resmi, DeepSeek).
    Balasan yang terpotong (JSON panggilan alat tak seimbang) tidak dikirim ulang apa adanya: agen diminta memecah file (Write bagian pertama, lanjutkan dengan Edit,
    atau bagi ke beberapa file kecil). Prompt sistem juga menyuruh ≤ ~150 baris per Write.
12. Keamanan masukan: isi `<tool_result>` (isi file, teks lampiran, nama file) diperlakukan sebagai DATA, bukan perintah. `<system-reminder>` hanya dipercaya di luar `<tool_result>`.
13. Pembatalan: tombol Stop memutus koneksi HTTP seketika (tidak menunggu read timeout); Glob/Grep memeriksa pembatalan per file, sehingga timeout alat benar-benar berlaku.
    `StackOverflowError` (regex rumit) dan `OutOfMemoryError` pada alat menjadi galat alat, bukan crash.

## Lampiran (file, dokumen, gambar, kamera)
Tombol "+" > Tambahkan ke chat: **Kamera**, **Foto**, **File**. Lampiran tampil sebagai kartu di atas kolom input (X untuk batal), maks. 20 per pesan, 25 MB per file.
- Disalin ke `uploads/` di proyek. Gambar diperkecil (maks. 1600 px), diputar sesuai EXIF, PNG/WebP transparan diberi latar putih (JPEG tak punya alfa), dikirim ke model sebagai gambar (Claude, OpenAI-kompatibel, Gemini).
- Teks/kode (termasuk `.svg`): dibaca agen dengan `Read`. `.docx/.pptx/.xlsx`: teks diekstrak ke `<nama>.txt` (sel tabel dipisah TAB, sheet berurutan alami, `inlineStr` didukung). `.zip`: diekstrak aman (anti zip-slip) ke `uploads/<nama>/`.
- Satu lampiran yang gagal diproses dilewati dengan catatan di obrolan; lampiran lain dan pesan tetap terkirim.
- PDF: 20 halaman pertama dirender menjadi gambar (teks juga diekstrak bila tersedia); butuh model yang bisa melihat gambar untuk halaman gambar.
- Model yang bisa melihat gambar (dikenali dari nama) dicoba lebih dulu secara otomatis; model tanpa kemampuan itu tidak diberi gambar dan agen diberi catatan.
- Gambar hanya dikirim pada 12 panggilan pertama agar hemat token; agen diminta mencatat isi pentingnya.

## Tampilan streaming agen (v31)

Alurnya meniru rekaman aplikasi Claude dan sekarang **streaming sungguhan**, bukan animasi setelah balasan selesai.

**Dari model ke layar**
1. `LlmClient.stream()` membaca Server-Sent Events (OpenAI-compatible, Anthropic, Gemini) dan melaporkan teks *kumulatif* (paling sering tiap 40 ms).
   Server yang membalas JSON biasa tetap jalan; klien yang hanya punya `complete()` jatuh ke satu potongan di akhir.
   Coba ulang dan pergantian kunci mengosongkan teks parsial (`onText("")`).
2. `Agent` meneruskan teks itu sebagai `AgentEvent.Streaming(text, tool, target)`: `text` = narasi tanpa blok `<tool_use>`; `tool`/`target` terisi begitu
   model mulai menulis pemanggilan alat (label "Menulis X.kt" muncul selagi JSON-nya masih mengalir). Pendengar jaringan menulis ke
   `Channel.CONFLATED`, jadi jaringan tidak pernah menunggu UI.
3. `TimelineReducer` (`Timeline.kt`, murni Kotlin) membuat satu `ThoughtItem(live = true)` dan memperbaruinya di tempat. Saat balasan selesai, item yang
   sama menjadi narasi (ada alat) atau `FinalItem` (jawaban akhir) dengan id tetap, sehingga tidak berkedip dan animasinya tidak mengulang.

**Di layar (`ChatScreen`)**
- Urutan blok: pesan pengguna → narasi → baris aktivitas → narasi → … → jawaban akhir. Tanpa antrean tampilan: semuanya tampil saat terjadi.
- Narasi dan jawaban memakai serif (jarak baris 22 dp, margin 20 dp); 9 karakter terakhir memudar selama mengalir dan dikejar mulus
  (`rememberRevealed`), jadi tampilan hanya tertinggal beberapa karakter dari aliran asli.
- Baris aktivitas: aktif = tiga titik oranye + label berkilau yang berganti di tempat (ditahan ≥ 500 ms); selesai = titik berubah (pudar-silang)
  menjadi ikon jam (ikon terminal untuk kelompok yang menjalankan build) dan label menjadi judul kelompok (satu alat → judulnya, beberapa → ringkasan).
  Saat teks sedang mengalir tidak ada baris di bawahnya; baris baru muncul setelah teks selesai.
- Label aktif: alat yang sedang ditulis model → alat yang sedang jalan → "Proses berpikir".
- "Masih diproses…" muncul bila ±10 detik tidak ada perubahan yang terlihat (`progressKey`) dan hilang begitu ada yang baru.
- Tombol bulat "ke bawah" muncul saat pengguna menggeser menjauh dari ujung percakapan. Titik dan kilau memakai jam bingkai absolut (`rememberPhase`),
  jadi tidak melompat ketika baris berpindah komposable.

**Tidak ditiru (tidak ada padanannya di Mythos):** kartu file ZIP (alat `present_files` milik Claude) dan judul ringkasan "berpikir" dari model.
Ringkasan perubahan file tetap tampil sebagai kartu `ChangesCard` di akhir giliran.

---

## Browser Agent (v5 + v6)

Berkas: `app/src/main/assets/mythos_form.js`, `agent/BrowserInstruction.kt`, `agent/BrowserActionGuard.kt`, `ui/BrowserAgentScreen.kt`.
Fitur: isi teks, dropdown standar/kustom, checkbox, radio, tanggal, editor teks/contenteditable/iframe sama-origin, peta field.
Keamanan: semua aksi final (kirim, setuju, tutup kasus, terima penyelesaian, keberatan, unggah final, hapus, bayar, tarik) selalu minta konfirmasi;
teks tombol sebenarnya diperiksa lewat dry-run, tombol submit dari DOM ikut dijaga.

Uji JS form (butuh playwright + chromium): `node jstest/form.test.js` atau `python3 tools/test_form_js.py` (keduanya menguji aset yang dikirim, `app/src/main/assets/mythos_form.js`)
Uji Kotlin: `./gradlew :app:testDebugUnitTest`
Rencana pengisian otomatis (v78): `agent/FormPlan.kt` — model menyusun rencana dari catatan kasus + teks halaman, pengguna meninjau, rencana TIDAK bisa berisi klik/kirim.
Keterbatasan: iframe lintas-origin, datepicker kustom tertentu, wizard bertahap/modal, belum ada ekstraksi PDF/foto (roadmap #2) dan penyimpanan kasus (#3).

## Penandatanganan rilis
Keystore TIDAK disertakan dalam paket ini. Letakkan folder `release-keystore/` (berisi `keystore.properties` dan `.jks`) di SEBELAH folder MythosV6, bukan di dalamnya.
Tanpa keystore, build rilis tetap jalan tetapi tidak ditandatangani.

### Identitas APK debug yang dibagikan
APK debug hasil build pada 2026-11-14 ditandatangani dengan sertifikat debug bawaan Android:
- Subject: `C=US, O=Android, CN=Android Debug`
- SHA-256 sertifikat: `27d2c97141b30739f45edc92affd75c392e8713c149488ed258819363c8aa942`
- Skema tanda tangan: APK Signature Scheme v2

Ini adalah identitas **debug**, bukan identitas penerbit/rilis. Keystore dan kunci privat tidak disertakan dalam kode sumber. Build debug pada mesin lain dapat memakai keystore debug berbeda, sehingga fingerprint-nya juga berbeda; sertifikat publik/fingerprint ini saja tidak cukup untuk menandatangani APK berikutnya dengan identitas yang sama.

## Rilis
Versi aplikasi hanya ditulis di `gradle.properties` (`mythosVersionCode`/`mythosVersionName`) dan harus sama dengan nomor changelog terbaru di `docs/changelog/` (dijaga `VersionConsistencyTest`).
Sebelum rilis: `bash scripts/pin-actions.sh --check` (tanpa jaringan) menunjukkan action CI yang belum dipin; `bash scripts/pin-actions.sh` dan
`bash scripts/pin-gradle-wrapper.sh` (butuh jaringan) memin action ke SHA dan menambah `distributionSha256Sum` wrapper.
