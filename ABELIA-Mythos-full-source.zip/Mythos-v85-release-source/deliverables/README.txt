Mythos v85 — paket source hasil audit keamanan

- Isi: source proyek Android/Kotlin beserta tes dan dokumentasi.
- APK tidak disertakan. Bangun dari source dengan Android Studio atau `./gradlew assembleDebug`.
- `local.properties`, cache Gradle, dan kredensial mesin lokal tidak disertakan.
- Build release tidak menggunakan debug keystore. Untuk menghasilkan APK release bertanda tangan, sediakan keystore rilis milik pemilik proyek dan konfigurasi signing lokal/CI; tanpa konfigurasi itu artefak release tidak ditandatangani.

Status Codex/Termux (PATCH33, permintaan pemilik, 16 November 2026):
- Codex native BAWAAN HIDUP dan memberi akses penuh ke Termux: `approvalPolicy: 'never'` + sandbox `danger-full-access`, tanpa dialog persetujuan. Izin yang tetap diminta Codex dijawab `accept` otomatis. Migrasi satu kali v33 menyalakan kembali nilai native; setelah itu pilihan pengguna di Pengaturan dihormati.
- Codex adalah SATU-SATUNYA jalur ke Termux. Penyedia model lain tidak punya alat Termux dan prompt-nya tidak menyebut Codex/Termux.
- Risiko yang diterima pemilik: instruksi tersembunyi di web/email yang dibaca Codex dapat langsung menjalankan perintah di Termux. Backup data penting sebelum tugas bersih-bersih dan beri Codex folder sasaran yang jelas.
- Karena sandbox mati, filter berkas rahasia pada mirror workspace hanya berlaku untuk salinan proyek; Codex tetap dapat membaca HOME Termux (termasuk `~/.codex`, `~/.ssh`).
- Mode model-saja (sakelar native dimatikan): Codex hanya menghasilkan teks, `read-only`, tool bawaan dibatalkan.
- Native membutuhkan socket aplikasi terautentikasi; tanpa socket sesi gagal tertutup. Runner menolak root workspace symlink dan membersihkan folder sesi sementara.
- Hasil audit 16 November yang masih berlaku: WebFetch pasca-taint membatasi kepercayaan ke URL spesifik, release signing tidak memakai debug keystore secara default, GitHub Actions dipatok commit SHA, checksum Gradle 8.7, lint menjadi gate CI.
- Bagian audit yang tentang `on-request`/`workspace-write`/opt-in untuk Codex native TIDAK berlaku lagi (dibalik oleh PATCH33).

Tes yang tersedia:
- `node jstest/codex_runner.test.js` — 6/6 skenario runner/workspace lulus pada pemeriksaan lokal.
- `node --check app/src/main/assets/codex_app_server.js` dan `node --check jstest/codex_runner.test.js` — lulus.
- Tes Gradle/Kotlin dan build Android belum dapat diverifikasi di lingkungan audit karena Gradle 8.7 tidak dapat diunduh (DNS/jaringan tidak tersedia) dan Android SDK tidak terpasang.
- Tes browser `jstest/form.test.js` belum dapat dijalankan secara lokal karena Playwright/Chromium tidak tersedia; workflow CI memasang keduanya.

Lihat `docs/AUDIT-ABELIA-2026-11-16.md` untuk temuan, perbaikan, bukti tes, dan risiko tersisa.
