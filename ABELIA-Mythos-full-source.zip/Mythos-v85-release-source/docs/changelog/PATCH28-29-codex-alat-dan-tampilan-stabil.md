# PATCH28-29 - Codex tidak lagi mengaku Read/Glob tak tersedia, dan tampilan lebih stabil

Tanpa kenaikan versi (versionCode tetap 85). BELUM dikompilasi/dijalankan: jalankan `./gradlew testDebugUnitTest`.

## PATCH28 - Read/Glob di mode Codex native
Masalah (rekaman layar): Codex menjawab "alat Mythos Glob dan Read tidak tersedia" dan "shell dibatasi ke HOME Termux", padahal Read/Glob dipanggil lewat blok teks `<tool_use>`, bukan fungsi bawaan Codex.
- `CodexAppServerClient.kt` (prompt native): penegasan bahwa Read/Glob/Grep/Write/Edit/WebSearch/WebFetch bukan tool bawaan Codex (memang tak ada di daftar tool-nya), dipakai lewat blok `<tool_use>`; batasan HOME hanya untuk tool shell; dilarang menjawab alat/lampiran tak tersedia.
- `Agent.kt`: bila model mengaku alat tak tersedia (koreksi sekali per tugas), aplikasi menjalankan `Glob uploads/**` sendiri dan mengirim hasilnya dalam format protokol beserta contoh blok Read, agar model melihat alurnya bekerja.
- Tes: `CodexNativeTest` (satu tes baru), `ToolClaimProbeTest` (baru, dua tes).

## PATCH29 - tampilan tidak melompat saat percobaan diulang
Masalah: balasan yang ditolak agen dibuang seketika (`items.removeAt`), daftar chat memendek lalu memanjang lagi; layar melompat ke atas dan berhenti mengikuti teks (rekaman 1000247013, detik 15).
- `Timeline.kt`: `streaming("")` kini menandai item hidup sebagai usang dan menahannya; diganti di tempat oleh teks berikutnya (`streaming`, `thought`, `finalAnswer`), atau dibuang oleh `settle()`.
- Tes: `TimelineTest` (tes lama diganti, satu tes baru).
- Tidak diubah: logika gulir `ChatScreen.kt` (tidak bisa diverifikasi tanpa perangkat).

## PATCH30 - Codex tidak berhenti setelah alat jalan (BELUM dikompilasi)
Masalah (rekaman 1000247059-67): alat Glob/Read sempat jalan ("Mencari file uploads/", "Membaca 2 file"), tapi Codex lalu menulis "Saya lanjutkan ..." atau "Saya belum dapat memeriksa ..." dan giliran berakhir tanpa tindakan.
- `Agent.kt`: koreksi klaim "alat tidak tersedia" tidak lagi disyaratkan `!usedTools` (tetap sekali per tugas); probe Glob hanya bila belum ada alat yang jalan, selain itu pengingat menyebut bahwa blok sudah terbukti jalan.
- `Agent.kt`: `TOOL_CLAIM` diperluas (arsip, proyek, source, kode, patch; "alat tidak tampil", "sesi ini tidak dapat menjalankan").
- `Agent.kt`: `INTENT_PRESENT` menangkap niat bentuk kini ("Saya lanjutkan ...", "Saya membaca ... lalu ...") sehingga dorongan lanjut (maks. 2) ikut terpicu.
- Tes: `Patch30IntentClaimTest` (baru). Jalankan `./gradlew testDebugUnitTest`.

## PATCH31 - salinan kerja proyek di Termux untuk Codex native (BELUM dikompilasi/dijalankan di Gradle)
Akar masalah: folder proyek (`filesDir/projects/<id>`, termasuk `uploads/`) tak terjangkau Termux, sementara Codex native bekerja di HOME Termux, sehingga Codex dipaksa memakai alat Mythos tiruan lewat teks.
- Baru `agent/WorkspaceMirror.kt`: awal sesi mengirim berkas proyek yang berubah (hash SHA-256, maks. 8 MB/berkas, 24 MB total, tanpa `.git`/`build`/`node_modules`/`.gradle`); akhir sesi menulis balik hasil kerja lewat `ProjectSandbox.resolve` (path `..`, absolut, dan folder terlarang ditolak).
- `codex_app_server.js`: permintaan soket boleh membawa `workspace`; berkas ditulis ke `~/mythos-work/<id>/`, `process.chdir` ke sana, lalu sebelum `done` runner mengirim `{type:'file'}` per berkas yang berubah (maks. 700 KB/berkas karena batas baris 1 juta karakter) dan `{type:'files_done', deleted, skipped}`. Hanya lewat soket, tidak lewat stdout/berkas live.
- `TermuxLauncher.runCodexAppServer`: parameter `workspace`; bila ada, prompt selalu lewat soket, `CodexStreamState` menampung berkas balik, dan sesudah soket selesai (tunggu hingga 15 dtk) hasilnya diterapkan.
- `CodexAppServerClient`/`AgentViewModel`: `WorkspaceMirror { projectDir }` hanya dipasang pada mode native; prompt baru `codexWorkspacePrompt` (direktori kerja = salinan proyek, shell dan edit bawaan boleh dipakai langsung).
- Batasan yang diketahui: sinkron hanya di batas sesi; hasil kerja Codex ditulis ke proyek tanpa lewat checkpoint (undo bawaan belum mencakupnya); berkas > 700 KB yang diubah Codex tidak dikembalikan; bila Termux membersihkan `~/mythos-work`, app tidak tahu dan baru mengirim ulang berkas yang berubah.
- Tes: `WorkspaceMirrorTest` (Kotlin, baru) dan satu tes baru di `jstest/codex_runner.test.js` (sudah dijalankan: 4/4 lulus).

## PATCH31 r2 - perbaikan galat kompilasi dari build pertama (Manus)
- `CodexAppServerClient.kt`: kutip mentah pada "Permission denied" di dalam string prompt (galat sintaks yang SUDAH ADA di source v85 asli) dilolosi menjadi \"Permission denied\".
- `TermuxLauncher.kt` (`CodexStreamState.accept`): blok `synchronized` dijadikan pernyataan (cabang `else -> Unit` dan `Unit` penutup) agar `when`/`if` tanpa else tidak dianggap ekspresi.
- Pemindaian heuristik baris `appendLine("...")` lain: tidak ada kutip mentah lain (8 temuan di CaseLedger.kt adalah templat `${...}` yang sah).

## PATCH31 r3 - galat kompilasi tes (build r2)
- Build r2: kode utama (`compileDebugKotlin`) sudah berhasil; yang gagal hanya `compileDebugUnitTestKotlin`: `ToolClaimProbeTest.kt:67 Unclosed comment`.
- Penyebab: KDoc baris 19 memuat `uploads/**`; di Kotlin komentar blok BERSARANG, jadi `/**` di dalam komentar membuka komentar baru yang tak pernah ditutup. Kalimatnya diganti tanpa `/*`. Pemindai komentar bersarang pada seluruh `*.kt` tidak menemukan berkas lain yang bermasalah.
