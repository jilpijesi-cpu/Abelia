# PATCH23: lanjutan audit v85 (upload GitHub dan digest persetujuan)

Belum dikompilasi dan belum dites di Gradle. Jalankan `./gradlew testDebugUnitTest` lebih dulu.

| # | Perbaikan | Berkas |
|---|-----------|--------|
| 1 | Regex kunci privat `[\s\S]*?` (kuadratik: 437 KB = 28 dtk) diganti pemindai linear `redactPrivateKeyBlocks`; hasil setara regex lama. | GitHubActions.kt |
| 2 | `workflowDigest(root, strict)` kini juga memuat sidik jari SHA-1 semua berkas yang dinilai `isBuildSensitivePath` (buildSrc, package.json, pom.xml, JS action lokal, ...). Tes `*.kt` ikut hanya bila `strict` (sesi tercemar). Agent.kt memanggil dengan `strict = st.taintedByExternal`. | GitHubActions.kt, Agent.kt |
| 3 | `isSecretFile`: keystore (.jks/.keystore/.p12/.pfx), .pem, .env*, local.properties, keystore.properties, .npmrc, .netrc, kunci SSH, service-account*.json tidak pernah dikirim. Baris `*password*`/`*token*`/`*secret*` di berkas `.properties` disamarkan (`redactCredentialLines`). | GitHubActions.kt |

Tes baru: `AuditV86HardeningTest.kt`.

## Belum dikerjakan
- `Llm.kt`: `instanceFollowRedirects = false` pada `Http.postJson`/`postSse` dan batas ukuran badan respons.
- Peninjauan `Protocol.kt` utuh, `Checkpoints.kt`, `codex_app_server.js`, dan alur tunggu/unduh log di `GitHubActions.kt`.
- Kompromi: berkas rahasia yang dilewati tidak ikut build; penandatanganan di CI harus lewat GitHub Secrets.
