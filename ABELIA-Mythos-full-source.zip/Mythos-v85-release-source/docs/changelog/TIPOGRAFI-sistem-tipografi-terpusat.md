# Sistem tipografi terpusat (acuan: pengalaman baca percakapan di HP)

Status: BELUM dikompilasi dan belum dites di Gradle/perangkat (tidak ada kompiler Kotlin di lingkungan pengerjaan).
Jalankan: `./gradlew testDebugUnitTest` lalu `assembleDebug`, lalu cek daftar visual di bagian bawah.

## Temuan analisis (masalah sebenarnya)
1. Jetpack Compose + Material3 (BOM 2024.09.00); Inter (OFL) sudah ada di `res/font` dan sudah jadi gaya "Default". Jadi font BUKAN masalahnya.
2. `Theme.kt` memakai `MaterialTheme.typography` bawaan. Material `bodyLarge` membawa **letter-spacing 0,5sp** dan **lineHeight 24sp**,
   dan `LocalTextStyle` mewarisinya ke hampir semua `Text`. Akibatnya Inter terlihat renggang, dan teks kecil (12sp) yang tidak menulis
   lineHeight punya tinggi baris 24sp (tidak konsisten).
3. Ukuran tersebar tanpa sistem: isi jawaban 16/25sp, `bodyStyle` 15,5/23, input 16,5/24, gelembung pengguna 14,5/19, judul 24/22/18, kode 13,5.
4. Jarak antarblok ditulis langsung di renderer (5/12/20dp); nomor "10." membuat teks butir bergeser dibanding "9.".
5. Kutipan (`> teks`) dibuang penanda-nya oleh `CleanText` dan tidak punya gaya sendiri.

## Perubahan
- BARU `ui/Typography.kt`: `TypeScale` (angka murni + aturan jarak, dites di JVM) dan `MythosType` (pembangun TextStyle/Typography).
  Isi 16sp / 1,6; h1 24, h2 20, h3 18, h4-h6 16 (semua SemiBold 600); tabel 14/1,5 dengan angka tabular; kode inline 14, blok 13.
  Semua gaya: rata kiri, `letterSpacing = 0`, `LineBreak.Simple` (pemenggalan serakah, stabil saat teks mengalir), `Hyphens.None`,
  `LineHeightStyle(Center, Trim.None)` (baseline konsisten), fitur OpenType `kern, liga, calt`.
- `Theme.kt`: `typography = MythosType.materialTypography()` (semua peran Inter, spasi 0). `withFamily` dihapus.
- `Design.kt`: `bodyStyle`, `inputStyle`, `assistantStyle` hanya memanggil `MythosType`; ukuran kode inline lewat `TypeScale`.
- `CopyBlocks.kt`: jarak antarblok lewat satu fungsi `TypeScale.gapDp` (paragraf 14dp, tabel/kutipan 16dp, butir 6dp, judul menempel
  ke isinya 8dp); kolom penanda daftar selebar tetap per daftar (nomor rata kanan); blok kutipan baru (garis kiri 3dp, warna lebih lembut);
  sel tabel memakai `MythosType.table`.
- `CleanText.kt`: `cleanForDisplay(..., keepQuotes)`; hanya `ChatScreen` yang mengaktifkannya (salin teks tetap polos).
- `ChatScreen.kt`: gelembung pengguna memakai `bodyStyle()` (16/25,6), tidak lagi 14,5/19.
- Tes: `TypographyTest` (baru), `PolishStyleTest` disesuaikan.

## Sengaja tidak diubah
- Kartu bergaya Gmail (`FixedScale`, `GmFont` Roboto, kotak "Teks siap salin"/kode): dikunci terpisah oleh `CardsFixedStyleTest`.
- Antialiasing, hinting, dan subpixel positioning: memakai mesin teks bawaan Android (Compose tidak menyediakan kendali hinting).
- Layar Pengaturan/riwayat/browser: ukuran lokalnya dibiarkan; mereka hanya ikut berubah lewat default (letter-spacing 0, Inter).
- Lebar kolom maksimum di tablet/layar lipat belum dibatasi (margin 20dp tetap).

## Daftar cek visual (HP kecil ~320dp, standar ~393dp, besar ~430dp; skala font Kecil..Terbesar)
Paragraf panjang; banyak judul h1-h4; daftar bernomor sampai 10+ dan bertingkat; bullet; kutipan 1 dan 3 baris; tabel 2-4 kolom;
`kode` di tengah kalimat; teks campuran Indonesia-Inggris dan URL panjang; teks yang sedang mengalir (tidak boleh melompat);
tidak ada teks terpotong atau gulir horizontal.
