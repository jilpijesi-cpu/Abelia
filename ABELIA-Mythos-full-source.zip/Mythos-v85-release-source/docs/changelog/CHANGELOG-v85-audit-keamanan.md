# v85 — Audit keamanan menyeluruh dan pengerasan Codex/Termux (16-11-2026)

> **Diperbarui PATCH33:** butir Codex native dan alat Termux di bawah dibalik atas permintaan pemilik (native bawaan hidup, `never` + `danger-full-access`, tanpa dialog persetujuan; Codex satu-satunya jalur Termux). Butir lain tetap berlaku.

- [DIBALIK PATCH33] Codex native menjadi fitur opt-in (bawaan mati); migrasi satu kali juga mereset nilai `true` yang mungkin tersimpan dari versi lama agar pengguna harus mengaktifkannya kembali secara sadar. `approvalPolicy: on-request`, `sandbox: workspace-write`, persetujuan native ditangani aplikasi, timeout 120 detik ditolak, dan tidak ada auto-accept. Tanpa socket aplikasi terautentikasi, runner gagal tertutup.
- WebFetch sesudah konten eksternal masuk konteks: trust dibatasi ke URL spesifik yang berasal dari pengguna/hasil WebSearch atau sudah berhasil dibuka; path/host lain dan query baru meminta persetujuan, termasuk pada GitHub.
- Mode model-saja menonaktifkan tool shell bawaan Codex serta memakai `read-only`; operasi shell dialihkan ke alat Termux Mythos.
- [DIBALIK PATCH33 untuk Codex] Semua perintah Termux berisiko `DANGEROUS` kembali wajib melewati persetujuan pengguna; tidak ada pengecualian khusus untuk mode ACCEPT_EDITS.
- Tambahkan pemfilteran direktori/nama file kredensial pada mirror workspace, write-back, dan pembersihan pola rahasia lama pada workspace Termux. Runner juga menolak root workspace symlink dan menghapus symlink di dalam workspace sebelum Codex berjalan. Tambahkan uji regresi untuk berkas rahasia dan symlink.
- Bersihkan direktori kerja sementara Codex setelah proses selesai.
- Release signing tidak lagi menggunakan debug keystore secara default.
- Pin GitHub Actions ke commit SHA penuh, tambahkan SHA-256 distribusi Gradle 8.7, jadikan lint sebagai gate CI, dan perbarui versi Playwright pada workflow.
- Perbarui README, catatan rilis, dan panduan keamanan agar sesuai implementasi aktif; tandai PATCH25 sebagai historis.
- Verifikasi lokal: tes runner JavaScript 6/6 lulus; pemeriksaan sintaks JavaScript lulus. Build Android/tes Kotlin dan tes browser lokal belum dapat dijalankan karena keterbatasan toolchain (rincian dalam laporan audit).

Laporan lengkap: `docs/AUDIT-ABELIA-2026-11-16.md`.
