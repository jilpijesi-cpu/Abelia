# PATCH27 - aturan ambigu/berlawanan di prompt dihapus

Masalah: di mode Codex CLI, Codex sempat menolak menjalankan perintah karena instruksi saling bertentangan.

- `CodexAppServerClient.kt` (prompt native): kalimat "Alat Termux milik Mythos tidak dipakai di mode ini" diganti aturan satu arti: perintah shell selalu lewat tool shell bawaan Codex; jangan menulis blok `<tool_use>` bernama Termux.
- `CodexAppServerClient.kt` (prompt model-only): larangan "menjalankan perintah" kini menyatakan semuanya hanya lewat alat Mythos di bawahnya (tidak lagi bertabrakan dengan PEMETAAN ALAT).
- `Protocol.kt`: langkah verifikasi tidak lagi menyatakan mutlak "no local shell"; baris Platform di lingkungan memakai `shellVia` ("alat Termux" atau "Codex") sehingga mode Codex tidak lagi dilabeli "tanpa shell".
- `Agent.kt`/`AgentViewModel.kt`: `AgentConfig.ownShell` diisi true saat Codex native aktif.
- Tes: `CodexNativeTest` (dua tes baru). BELUM dikompilasi/dijalankan: jalankan `./gradlew testDebugUnitTest`.
