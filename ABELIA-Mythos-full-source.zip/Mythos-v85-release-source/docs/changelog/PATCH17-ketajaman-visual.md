# PATCH17 — ketajaman visual + form input seragam

- Form input di dalam chat kini memakai bentuk dua baris yang sama dengan layar awal (tanpa mode `compact`), placeholder "Chat Mythos...".
- `crispBorder` (Design.kt): garis tepi 0,67/0,5/0,33 dp dibulatkan ke piksel fisik utuh (minimal 1 px) sehingga tidak lagi kabur karena anti-alias setengah piksel.
- Gambar bitmap (thumbnail lampiran, pratinjau gambar Workspace, logo penyedia/situs) memakai `FilterQuality.Medium/High` (mipmap) agar hasil perkecilan tidak bergerigi/berkedip.
- Teks status aktif (`ShimmerText`) kini berwarna aksen yang sama dengan titik `LoaderDots`; kilau menyapu dari aksen pudar (45%) ke aksen penuh. Bobot/ukuran huruf tidak berubah; teks selesai (abu-abu) dan elemen lain tidak diubah.
- `WebFetchGuard`: `github.com` (api.github.com) dan `githubusercontent.com` (raw.githubusercontent.com) dikecualikan dari batas 8 alamat/situs dan catatan lunak ke-5, supaya audit repo lewat WebFetch tidak berhenti di file ke-8. Pengaman halaman kembar tetap berlaku untuk semua situs. Tes baru: `repoGithubTidakKenaBatasAlamat`.
- `ChatScreen`: area bawah (kartu input + area tombol navigasi) kini berlatar solid; pudar halus hanya di tepi atas 14 dp. Teks yang tergulir tidak lagi tembus terlihat di belakang kartu/tombol navigasi.
