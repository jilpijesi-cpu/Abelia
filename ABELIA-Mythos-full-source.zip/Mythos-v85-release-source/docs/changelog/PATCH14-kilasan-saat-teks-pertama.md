# patch14: kilasan layar saat teks pertama muncul
Ditemukan dari rekaman layar (bingkai demi bingkai, 60 fps), tepat ketika baris "Proses berpikir" berganti jadi teks pertama:
1. 2 bingkai: pesan pengguna turun ke bawah dan isi lama (kartu "Batalkan tugas ini") muncul sekilas. Sebab: `snapshotFlow` penghitung spacer (`rawTail`) membaca hasil ukur sebelum daftar baru terukur, mendapat `after.size < n - ui` dan menyimpulkan 0, sehingga spacer ambruk dan daftar terjepit. **Perbaikan:** hasil dilewati (nilai lama dipertahankan) bila `totalItemsCount != n + 1`.
2. +-4 bingkai kosong: blok teks tingginya 0 sampai huruf pertama tampil, padahal baris yang dicabut setinggi satu baris. **Perbaikan:** tahan setinggi satu baris (`lineHeight`) selama masih streaming dan belum ada huruf.
3. Saat jawaban selesai, status dan tombol aksi (salin/bagikan/suka) menyembul sekaligus dan menggeser isi. **Perbaikan:** `AnimatedVisibility` (fade + expandVertically, 220 ms).
- Tidak diubah: peralihan "disematkan" ke "mengikuti" saat jawaban memenuhi layar masih berupa gulir cepat sekitar 20 px.
- Tes: `LiveHandoffTest`. Nama APK kini `Mythos-v83-patch14-debug.apk`. Versi tidak berubah (83).
