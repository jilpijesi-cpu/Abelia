# v84 - Pengaturan Tampilan bergaya iOS: ukuran teks 7 langkah, Teks Tebal, gaya Default (iOS), pratinjau langsung

## Ukuran Font
- Slider kini 7 langkah standar iOS (Dynamic Type): XS, S, M, Default (L), XL, XXL, XXXL. Skala = ukuran isi iOS / 17 pt (14, 15, 16, 17, 19, 21, 23).
- Huruf "A" kecil di kiri dan "A" besar di kanan slider. Kunci simpanan baru `font_scale_step_v3` (bawaan indeks 3).

## Ketebalan Font -> Teks Tebal
- Slider 0-100% diganti sakelar hidup/mati seperti "Bold Text" iOS: Regular 400 menjadi Semibold 600 (+200, `FontTheme.BOLD_ADJ`).
- `FontTheme.setWeight` hanya menerima 0 atau BOLD_ADJ; tambah `FontTheme.isBold`. Kunci simpanan baru `font_weight_adj_v3`.
- Pengaturan lama (v2) tidak dimigrasi: semua pengguna mulai dari Default dan Teks Tebal mati.

## Gaya font
- Gaya "default" diberi nama "Default (iOS)" (Inter). Balasan AI dan judul kini ikut Inter, tidak lagi serif khusus pada gaya Default.
- "Android (Roboto)" diganti nama menjadi "Default (Android)" dan dipindah ke urutan kedua (kunci `android` tetap).

## Pratinjau
- `FontPreviewCard` di Pengaturan > Tampilan (di atas Gaya font): contoh judul dan paragraf yang berubah seketika mengikuti gaya, ukuran, dan Teks Tebal.

## Versi dan tes
- versionCode 84 / versionName 1.0.84; nama APK menjadi `Mythos-v84-ios-font`.
- Tes disesuaikan: `FontScaleTest` (7 langkah, Teks Tebal hidup/mati), `FontAnswerStyleTest` (Default memakai Inter untuk balasan).
- Catatan: tes Gradle belum dijalankan; hanya pemeriksaan keseimbangan kurung dan pencarian sisa referensi.
