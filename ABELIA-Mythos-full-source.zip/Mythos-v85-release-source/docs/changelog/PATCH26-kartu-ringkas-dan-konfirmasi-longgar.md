# PATCH26 - Kartu konfirmasi ringkas dan konfirmasi dilonggarkan

Tanpa kenaikan versi (versionCode tetap 85).

## Kartu "Izinkan aksi ini?" (MainActivity.kt, ApprovalDialog)
- Menampilkan satu kalimat inti, maksimal 2 langkah, dan peringatan terpenting saja (Perhatian/bersarang/ditolak).
- Sisanya (langkah lain, dampak lain, folder kerja, perintah mentah) ada di tombol "Lihat detail" (dulu "Lihat perintah teknis").
- ApprovalExplainer tidak berubah perilakunya; hanya tampilan yang diringkas.

## Konfirmasi dilonggarkan (ApprovalExplainer.kt: termuxNeedsNoConfirm)
Langsung jalan tanpa kartu: perintah baca-saja, mkdir/touch, git add/commit/init/clone/fetch, build/tes (gradle, make, cmake, ninja, tsc, javac, cargo/go build|test|check|vet, npm/pnpm/yarn/bun run|test|build).
Tetap minta konfirmasi: hapus, timpa/ubah berkas yang ada (mv, cp, sed -i, ">"), pasang paket, kirim data keluar (git push, curl -d), skrip/program lain, perintah bersarang, teks multi-baris, berkas kredensial atau yang lazim berisi rahasia (.ssh, .env, token, printenv, ...), dan perintah tak dikenal (fail-closed).
- Dipakai di jalur Codex native (CodexAppServerClient.askApproval) dan alat Termux di Agent.kt (tidak berlaku bila konteks sudah memuat konten eksternal).
- Pengaman lama tetap: pemeriksaan kredensial di TermuxLauncher dan TermuxShell.run, approvalPolicy 'untrusted' di runner JS.

## Teks diselaraskan
Teks pengaturan (CodexNativeRow, TermuxShellRow), prompt Codex, doc alat Termux, dan komentar tidak lagi menyebut "tiap perintah disetujui".

## Tes
ApprovalExplainerTest: bacaTambahRinganDanBangunTidakPerluKonfirmasi, hapusTimpaPasangKirimDanSkripTetapMintaKonfirmasi.

## Kilau gelombang cahaya teks live (Design.kt: ShimmerText, lightWave)
Penyebab kilau kurang terlihat: (1) kilau memutih ke arah putih sedangkan latar aplikasi terang, jadi tampak seperti teks memudar, bukan cahaya;
(2) pada baris langkah, Text diberi weight(1f) sehingga lebar sapuan = lebar baris, bukan lebar teks, dan sebagian siklus tersapu di area kosong;
(3) kilau hanya satu titik runcing (segitiga) selebar ±96 dp.
Perbaikan: dasar = aksen dipudarkan, kilau = aksen penuh sedikit gelap (kontras di latar terang); Text dibungkus Box agar lebar sapuan mengikuti teks;
kilau punya dataran penuh (core 30%) dan lebih lebar (halfDp 64, periode 1600 ms). Angka ada di SHIMMER_BASE_FADE / SHIMMER_PEAK_DEEPEN.

## Ketajaman visual: ikon mikrofon jadi vektor
- res/drawable-nodpi/ic_voice_mic.png (260x505 px, hanya pas di kepadatan 3x) diganti res/drawable/ic_voice_mic.xml (VectorDrawable hasil penelusuran gambar asli: dua lapis, oranye + tinta, gaya tangan tetap).
- Nama resource sama, jadi Sheets.kt (painterResource(R.drawable.ic_voice_mic)) tidak berubah. Ukuran tampil tetap 86x168 dp.
- Tidak diubah: ic_drawer_avatar.png (ilustrasi, tidak bisa divektorkan; 128 px untuk 43 dp, butuh sumber 256+ px bila ingin lebih tajam di layar 4x) dan bg_langit_biru.png (1340 px).

## Agen bekerja lebih seperti Claude
- Protocol.kt: bagian baru "# Working like a careful expert" di prompt sistem penuh: FOLLOW INSTRUCTIONS EXACTLY (patuhi instruksi panjang dan yang masih berlaku dari awal chat), THINK BEFORE CONCLUDING (timbang dulu, jawab ringkas), BE CALIBRATED (jangan menyebut angka/versi/tanggal yang tak pasti, koreksi premis keliru dengan sopan), LARGE CODE WORK (Grep semua pemakai sebelum mengubah, perbarui pemanggil, baca ulang), ONE LANGUAGE (tanpa huruf asing di tengah jawaban Indonesia), STAY ON COURSE (tujuan dan batasan tidak hanyut di tugas panjang).
- agent/ScriptGuard.kt: lapis kedua untuk "ONE LANGUAGE". Huruf Mandarin/Jepang/Korea yang nyasar di jawaban akhir dibuang (kasus "dan可解释." pada tangkapan layar). Tidak aktif bila pengguna sendiri memakai huruf itu; blok kode dan `kode satu baris` tidak disentuh. Dipasang di Agent.kt saat jawaban akhir dikirim.
- Tes: ScriptGuardTest.
- Batas: ini mengubah cara agen diarahkan, bukan kemampuan model di baliknya. Kualitas akhir tetap bergantung pada model yang dipilih.
