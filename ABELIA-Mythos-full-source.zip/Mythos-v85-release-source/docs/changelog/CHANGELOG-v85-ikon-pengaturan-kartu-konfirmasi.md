# v85: baris ikon di kolom input, pengaturan satu pintu, kartu konfirmasi, pilihan model ringkas
- Kolom input: ikon Proyek, Code, Artefak, dan Pengaturan (gerigi) sejajar dengan ikon AI (`Design.kt`, `NavShortcuts`).
- Ikon hamburger kiri atas dihapus di beranda dan layar chat; ikon hantu tetap. Riwayat chat, Browser Agent, dan semua bagian Pengaturan dibuka lewat ikon gerigi.
- Kartu konfirmasi bergaya Play Protect (`ConfirmCard.kt`): izin aksi, batalkan tugas, agen masih bekerja, hapus obrolan, konfirmasi Browser Agent.
- Pemilihan model: satu baris per penyedia, label pendek hanya untuk OpenRouter, Ollama, dan Codex (`Sheets.kt`).
- Belum dikompilasi dan belum dites di Gradle.
