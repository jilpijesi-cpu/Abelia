# PATCH18: perbaikan temuan audit v85

Belum dikompilasi dan belum dites di Gradle (sandbox tanpa Android SDK/jaringan). Jalankan `./gradlew testDebugUnitTest` lebih dulu.

| # | Perbaikan | Berkas |
|---|-----------|--------|
| 1 | `Tool.taintsContext`; `TaskTool` (dengan web) dan `runTasksParallel` menandai sesi tercemar + dicatat di audit log. `Read` atas `uploads/` dan `GithubDownloadArtifact` juga menandai taint. Daftar berkas build sensitif diperluas (`isBuildSensitivePath`: gradlew, Makefile, package.json, buildSrc, properties, tes `*.kt`). | Tools.kt, SubAgent.kt, Agent.kt |
| 2 | Setelah tercemar, `WebFetch` ke URL ber-query, path > 120 karakter, atau situs yang tidak disebut pengguna/hasil pencarian/belum dibuka WAJIB persetujuan (sub-agen: ditolak). Redaksi NIK, kartu 16 digit tanpa pemisah (Luhn), dan nomor rekening/VA berkata kunci. | WebFetchGuard.kt, Agent.kt, SensitiveDataGuard.kt |
| 3 | Regex HTML `.*?` diganti pemindai linear (komentar, blok script/style, tag, `<a>`, title); batas 1 juta karakter; `callTimeout` OkHttp (2x timeout). | Web.kt |
| 4 | `DeadlineNotices.fire` tidak lagi menghapus pengingat bila izin notifikasi ditolak; `retryOverdue`/`overdue` dipanggil di `onResume` (toast bila masih ditolak). `calculate_sla` menerima `holidays` dan memberi PERINGATAN bila tidak ada daftar libur. | DeadlineNotices.kt, MainActivity.kt, CaseLedger.kt |
| 5 | `BrowserActionGuard`: beli/langganan/top up/lapor. `onRenderProcessGone` di BrowserAgentScreen dan WebPreview. | BrowserActionGuard.kt, BrowserAgentScreen.kt, Workspace.kt |
| 6 | `escapeProtocolTags` toleran spasi/atribut/huruf besar; mencakup tool_call, invoke, function=, parameter, arg_key/arg_value, dan token `<|...|>`. | SensitiveDataGuard.kt |
| 7 | Nama APK/artefak CI/README menjadi v85; `VersionConsistencyTest` menjaganya. | build.gradle.kts, ci.yml, README.md |
| 8 | `tools/form-test` (menguji salinan usang) dihapus; README menunjuk `jstest/form.test.js` dan `tools/test_form_js.py`. | tools/ |
| 10 | `AgentService.onTimeout` memberi notifikasi "tugas mungkin terhenti" dan mencatat `lastTimeoutAtMs`. | AgentService.kt |

Tidak dikerjakan (butuh jaringan atau keputusan pemilik): #9 pin SHA action CI dan `distributionSha256Sum` (jalankan `scripts/pin-actions.sh` dan `scripts/pin-gradle-wrapper.sh`), #11 verifikasi scope Gmail, #12 AAD pada SecretBox (dinilai dapat diterima).

Tes baru: `AuditV85FixesTest.kt`, `VersionConsistencyTest.namaApkDanArtefakCiMengikutiVersionCode`.

## Belum dikerjakan / perlu tindakan pemilik
1. #9: pin SHA action CI dan `distributionSha256Sum` (butuh jaringan): jalankan `scripts/pin-actions.sh` dan `scripts/pin-gradle-wrapper.sh`; lint CI masih `continue-on-error`.
2. #11: scope `gmail.readonly` perlu verifikasi Google untuk distribusi luas; proyek OAuth berstatus Testing membuat refresh token kedaluwarsa 7 hari.
3. #12: `SecretBox` tanpa AAD (dinilai dapat diterima).
4. Daftar libur SLA TIDAK diisi di kode (sengaja, agar tidak menebak tanggal untuk tenggat hukum): agen harus mengirim `holidays` dari SKB resmi; tanpa itu hasilnya hanya batas bawah dan diberi peringatan.
5. Kompromi disengaja: setelah sesi tercemar, menulis berkas tes `src/test/**/*.kt` meminta persetujuan (CI mengeksekusinya). Bila terlalu mengganggu, hapus dua baris `src/test`/`src/androidtest` di `isBuildSensitivePath` (Agent.kt).
6. Sisa risiko #2: situs dari hasil WebSearch dianggap tepercaya; path pendek tanpa query ke situs itu masih bisa membawa sedikit data. Pertahanan utama tetap persetujuan `GithubBuild`.
7. SEMUA perubahan PATCH18 belum dikompilasi dan belum dites: jalankan `./gradlew testDebugUnitTest assembleRelease`, perbaiki galat kompilasi bila ada.
