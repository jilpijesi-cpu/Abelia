# v84b - Ukuran & Ketebalan Font disamakan dengan pengaturan font sistem

- Ukuran Font: 5 langkah (Kecil, Default, Besar, Sangat Besar, Terbesar), Default di langkah ke-2. Kunci simpanan `font_scale_step_v4`.
- Ketebalan Font: slider mulus (bukan sakelar). Default ada di 40% dari kiri; ke kiri lebih tipis sampai Thin (-300), ke kanan lebih tebal (+300). Ditambahkan Inter Thin (100) dan ExtraLight (200) di res/font. Tombol "Kembalikan" muncul bila bukan Default. Kunci simpanan `font_weight_adj_v4`.
- Tes `FontScaleTest` disesuaikan. Tes Gradle belum dijalankan.
- Warna teks (Ink, Hint, Placeholder, Chevron, biru slider) menggelap otomatis saat Ketebalan ditarik ke tipis (`FontTheme.thinBoost`), supaya huruf Thin tidak tampak pudar.
