# PATCH25 — Eksekusi Codex di Termux seperti Codex CLI

> **Catatan supersesi (16-11-2026):** dokumen ini merekam rancangan PATCH25 yang historis. Perilaku native bawaan hidup, `danger-full-access`, dan model persetujuan pada snapshot ini **sudah tidak berlaku**. PATCH32 mengubah native menjadi opt-in (bawaan mati), `on-request` + `workspace-write`, persetujuan UI fail-closed, dan dokumentasi batas isolasi baca. Lihat `CHANGELOG-v85-audit-keamanan.md` serta `../AUDIT-ABELIA-2026-11-16.md`.

## Sebelumnya
Codex hanya dipakai sebagai model bahasa: tool shell dimatikan (`features.shell_tool=false`), sandbox `read-only`, dan setiap
`commandExecution` yang dicoba Codex dibatalkan lalu diterjemahkan menjadi alat `Termux` milik Mythos (jalan di HOME, stdin kosong,
hasil kembali ke loop Mythos). Di Codex CLI sungguhan, Codex menjalankan perintah sendiri di dalam gilirannya dan memakai hasilnya
langsung.

## Sekarang (mode native, bawaan HIDUP)
Pengaturan > Model > Codex CLI > **"Eksekusi seperti Codex CLI"** (`SettingsStore.loadCodexNative/saveCodexNative`).

- Runner (`assets/codex_app_server.js`) berjalan dengan `MYTHOS_CODEX_NATIVE=1`: tool shell Codex aktif, `AGENTS.md` dibaca,
  direktori kerja = HOME Termux (`TermuxLauncher.buildAppServerCommand(..., native = true)`).
- Codex menjalankan perintah sendiri, melihat stdout/stderr sendiri, dan melanjutkan gilirannya (loop agen Codex), seperti di CLI.
- Persetujuan seperti prompt y/n di CLI: `item/commandExecution/requestApproval` diteruskan ke aplikasi (`{type:"approval"}`),
  muncul sebagai dialog "Izinkan aksi ini?" berisi perintah LENGKAP, jawaban kembali lewat soket (`{"approval":id,"decision":...}`).
- Sandbox `danger-full-access` (Android tidak punya sandbox Linux Codex) DENGAN `approvalPolicy: 'untrusted'`: hanya perintah
  baca-saja yang dikenal aman jalan otomatis; sisanya wajib disetujui pengguna.
- Alat `Termux` Mythos tidak ditawarkan ke Codex saat mode ini hidup (satu jalur eksekusi saja). Model lain tidak terpengaruh.

## Yang tetap dijaga (fail-closed)
- Tidak ada soket ke aplikasi, jawaban tidak valid, sesi selesai/dibatalkan, atau mode Rencana: perintah DITOLAK.
- Perintah yang menyentuh `auth.json` / `~/.codex/auth|config` / `.mythos_codex` ditolak di sisi aplikasi (`touchesCredentials`).
- Permintaan paralel ditanyakan satu per satu (dialog hanya punya satu slot).
- Edit berkas bawaan Codex (`fileChange`), MCP, dan pencarian web bawaan tetap diblokir/diterjemahkan ke alat Mythos
  (WebSearch/Write/Edit), karena berkas proyek Mythos ada di folder privat aplikasi, bukan di HOME Termux.
- Sakelar dimatikan = perilaku lama persis (model-saja + alat Termux Mythos).

## Batas yang disengaja
- Keluaran perintah belum ditampilkan langsung di UI Mythos (hanya perintah yang disetujui terlihat); Codex memakainya di dalam
  gilirannya. Menampilkannya butuh jenis event baru di Timeline.
- Batas waktu sesi tetap 15 menit termasuk waktu menunggu persetujuan.

## Berkas
`assets/codex_app_server.js`, `agent/TermuxLauncher.kt`, `agent/CodexAppServerClient.kt`, `agent/TermuxShell.kt`, `Settings.kt`,
`ui/AgentViewModel.kt`, `ui/CodexNativeRow.kt` (baru), `ui/SettingsScreen.kt`.
Tes: `jstest/codex_runner.test.js` (runner + `codex` palsu, sudah dijalankan: lulus), `CodexNativeTest.kt` (baru),
`TermuxShellTest.kt` (pin sandbox disesuaikan). Kotlin BELUM dikompilasi: jalankan `./gradlew testDebugUnitTest`.
