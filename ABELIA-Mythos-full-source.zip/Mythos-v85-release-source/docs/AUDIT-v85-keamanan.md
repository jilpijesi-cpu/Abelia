# Audit statis Mythos v85 (1.0.85)

> **Snapshot historis 14-11-2026.** Status dan temuan di dokumen ini mendahului PATCH32. Gunakan `AUDIT-ABELIA-2026-11-16.md` untuk status audit terbaru dan perbaikan Codex/Termux/workspace/CI; dokumen ini dipertahankan sebagai jejak audit sebelumnya.

Tanggal: 2026-11-14. Jenis: tinjauan kode statis. **Belum dikompilasi dan tes Gradle belum dijalankan** (sandbox tanpa jaringan/Android SDK; `CATATAN-PERUBAHAN.txt` juga menyatakan belum dikompilasi).

## Cakupan
Dibaca: build/manifest/CI/skrip, `Web.kt`, `WebFetchGuard`, `SecretBox` (Settings.kt), OAuth Google (GoogleWorkspace.kt, AgentViewModel, MainActivity), `TermuxLauncher` (pembentukan perintah), `ProjectSandbox`, `unzipSafely`, logika persetujuan/taint (`Agent.kt`, `SubAgent.kt`), `SensitiveDataGuard`, `SecurityAuditLog`, WebView (BrowserAgentScreen, Workspace), `BrowserActionGuard`, `BrowserDomainPolicy`, `DeadlineNotices`, `AgentService`, `CaseLedger.addBusinessDays`.
Belum dibaca/dalam: `Llm.kt`, `KeyPool`, `Protocol.kt` utuh, upload/build `GitHubActions`, `Checkpoints`, `codex_app_server.js`, UI Compose, sebagian besar tes.

## Ringkasan
| # | Tingkat | Temuan |
|---|---------|--------|
| 1 | Tinggi | Sub-agen `Task` mencuci status "tercemar" (taint) |
| 2 | Tinggi | Eksfiltrasi data kasus lewat `WebFetch` |
| 3 | Sedang | Regex HTML kuadratik (DoS CPU) + tanpa `callTimeout` |
| 4 | Sedang | Tenggat hilang bila izin notifikasi ditolak; SLA tanpa hari libur |
| 5 | Sedang | `BrowserActionGuard` berbasis kata; `onRenderProcessGone` tak ditangani |
| 6 | Sedang | `escapeProtocolTags` hanya cocok persis |
| 7-12 | Rendah | Kebersihan build/CI/tes/layanan/scope |

## 1. Sub-agen `Task` mencuci taint (Tinggi)
`Agent.kt:569` menandai `st.taintedByExternal = true` hanya setelah `WebFetch`, `WebSearch`, `GithubIssues`, `GmailSearchRead`. `TaskTool` (SubAgent.kt) menjalankan agen lain yang memegang `WebSearch`+`WebFetch` dengan `RunState` sendiri; hasilnya masuk ke agen utama tanpa menandainya. `runTasksParallel` bahkan tidak lewat `runTool` (tanpa taint, tanpa audit log).

Rantai serangan: halaman web berisi injeksi -> `Task` merangkum -> agen utama tidak tercemar -> `Write` file build (mode bawaan `ACCEPT_EDITS`, tanpa izin) -> `GithubBuild` (gerbang taint terlewati) -> kode berjalan di GitHub Actions dengan secrets repo. Penjaga "workflow berubah" tidak menutupnya, karena kode proyek (tes, skrip Gradle) tetap dieksekusi CI.

Perbaikan:
```kotlin
// Agent.kt, setelah execTool di runTool
if (result.ok && (tool.name in setOf("WebFetch","WebSearch","GithubIssues","GmailSearchRead","GithubDownloadArtifact")
        || (tool.name == "Task" && withWebTask))) st.taintedByExternal = true
// runTasksParallel: setelah awaitAll, bila ada hasil ok -> st.taintedByExternal = true
```
Pertimbangkan juga menandai `Read` atas `uploads/` (lampiran/zip dari pihak luar). Daftar nama file build (`.sh`, `.gradle`) bersifat porous (`gradlew`, `Makefile`, `package.json`, `buildSrc/**`, tes `*.kt` juga dieksekusi); gerbang utamanya sebaiknya `GithubBuild` saat tercemar.

## 2. Eksfiltrasi lewat WebFetch (Tinggi)
`WebFetch` berisiko `SAFE`, boleh ke domain publik mana pun tanpa persetujuan (Web.kt ~541). Batas URL 800/query 300 dan 8 alamat per situs hanya memperlambat; path juga bisa membawa data, dan jumlah domain tidak dibatasi. `SensitiveDataGuard` hanya menyamarkan OTP/PIN/sandi/token/kartu 16 digit **berpemisah**; NIK, rekening, nama, alamat tidak disamarkan (kartu 16 digit tanpa spasi pun lolos).

Perbaikan: saat `taintedByExternal`, minta persetujuan untuk host yang belum pernah dibuka dalam tugas atau URL ber-query/path panjang; tambahkan redaksi NIK/rekening; bila perlu blok query string pasca-taint.

## 3. Regex HTML kuadratik (Sedang)
`Web.kt`: `RE_DROP`, `RE_COMMENT` (juga `RE_LINK`, `RE_TITLE`) memakai `.*?` + `DOT_MATCHES_ALL`; tag tak tertutup berulang memicu O(n^2). Hasil uji (JVM 21, sandbox): `<script>x` x10.000 (90 KB) = 2,2 dtk; x40.000 (360 KB) = 36 dtk (RE_COMMENT 21 dtk). Batas unduh 2 MB, regex Java tidak memeriksa pembatalan coroutine, jadi timeout alat tidak menghentikannya dan wake lock tetap menyala. OkHttp juga hanya punya connect/read timeout (tanpa `callTimeout`; server tetes-lambat bisa menahan koneksi).

Perbaikan: potong teks sebelum regex (mis. 300 KB), ganti dengan pemindai linear (cari `</script` dengan `indexOf`), tambah `.callTimeout(...)` di `WEB_CLIENT`.

## 4. Domain pengaduan (Sedang)
- `DeadlineNotices.fire` menghapus entri dari prefs **sebelum** cek `POST_NOTIFICATIONS`; bila izin ditolak (API 33+), pengingat hilang tanpa jejak. Cek izin dulu atau simpan entri dan tampilkan di dalam aplikasi.
- `CaseLedger.addBusinessDays` hanya melewati Sabtu-Minggu: libur nasional/cuti bersama tidak dihitung. Tanggal bisa salah untuk tenggat hukum; tampilkan peringatan lebih jelas atau sediakan daftar libur.
- Alarm memakai `setAndAllowWhileIdle` (tidak presisi, terdokumentasi); judul/teks tenggat disimpan polos di SharedPreferences `deadline_notices`.

## 5. Browser Agent (Sedang)
- `BrowserActionGuard` tidak mencakup aksi pembelian/langganan ("beli", "buy", "order", "pesan", "langganan", "top up") maupun tombol "Lapor". Deteksi submit DOM (`isSubmit`) menutup sebagian.
- `WebViewClient` di BrowserAgentScreen tidak meng-override `onRenderProcessGone`; bila renderer mati, proses aplikasi ikut mati. Kembalikan `true` dan bangun ulang WebView.
- `WebPreview` (Workspace.kt): bila pengguna menyalakan JS, HTML buatan agen bisa membuat permintaan jaringan; bawaan nonaktif, jadi risiko rendah.

## 6. `escapeProtocolTags` (Sedang, pertahanan berlapis)
Hanya mengganti string persis (`</tool_result>`, `<tool_use>`, `<system-reminder>`). `</tool_result >`, `<tool_use name=..>`, `<tool_call>`, `<invoke>`, `<function=` lolos, padahal `Protocol.kt` mengonversi banyak format itu menjadi panggilan alat. Pakai regex toleran spasi/atribut dan perluas daftar tag.

## 7-12. Rendah
7. `app/build.gradle.kts` `archivesName = "Mythos-v84-ios-font"`, artefak CI dan README masih "v84" (versi 85). `VersionConsistencyTest` tidak menangkapnya; tambahkan asersi.
8. `tools/form-test/run.js` menguji `formtools.js` (beda 109 baris dari `app/src/main/assets/mythos_form.js`) dan memakai path `/opt/npm-tools`. Lulusnya bukan bukti untuk aset yang dikirim. Hapus atau arahkan ke aset; tes yang benar: `jstest/form.test.js`, `tools/test_form_js.py`.
9. `distributionSha256Sum` belum ada di `gradle-wrapper.properties` (jalankan `scripts/pin-gradle-wrapper.sh`); action CI belum dipin SHA; lint `continue-on-error`.
10. `AgentService.onTimeout` hanya `stopSelf()`; agen tetap berjalan tanpa penjaga dan tanpa pemberitahuan (batas dataSync Android 15).
11. `gmail.readonly` termasuk scope terbatas (butuh verifikasi Google untuk distribusi luas); proyek OAuth berstatus Testing membuat refresh token kedaluwarsa 7 hari.
12. `SecretBox`: GCM tanpa AAD (ciphertext antar-field bisa dipertukarkan oleh pihak dengan akses lokal); regenerasi kunci pada `UnrecoverableKeyException` membuat rahasia lama tak terbaca (sudah ditandai `unreadableSecret`). Dapat diterima.

## Terverifikasi baik
- Tidak ada API key/keystore/token di repo; tidak ada panggilan `Log.*`.
- Guard SSRF: IPv4/IPv6 privat, Teredo/6to4/NAT64/ISATAP, `PublicOnlyDns` saat connect, redirect diperiksa ulang tiap hop, API key hanya ke tujuan awal. (OkHttp tidak memanggil DNS untuk IP literal; itu ditutup `checkPublicUrl`.)
- `ProjectSandbox` (canonical path) dan `unzipSafely` (zip-slip, batas 500 file/50 MB).
- `TermuxLauncher`: prompt/runner di-base64, port bilangan bulat, token dan path live divalidasi regex; handshake soket berbatas dan waktu-konstan.
- OAuth: PKCE S256, `state` waktu-konstan, gerbang callback sekali pakai, hanya `com.mythos.app:/oauth2redirect`.
- `FileProvider` tidak diekspor, PendingIntent `IMMUTABLE` (kecuali callback Termux yang memang perlu mutable dan dibatasi `setPackage`), cleartext hanya ke localhost/127.0.0.1/10.0.2.2, `allowBackup=false`.

## Urutan perbaikan yang disarankan
1 -> 2 -> 3 -> 4 -> 6 -> 5 -> sisanya. Setelah itu jalankan `./gradlew testDebugUnitTest assembleRelease` dan tambahkan tes: taint setelah `Task`, `htmlToText` dengan 100 KB tag tak tertutup (batas waktu), `DeadlineNotices` tanpa izin.

## Status perbaikan (PATCH18)
Temuan 1-8 dan 10 sudah diterapkan di kode; lihat `docs/changelog/PATCH18-perbaikan-audit-v85.md`. Temuan 9 (pin SHA), 11, dan 12 belum. Semua perubahan BELUM dikompilasi.
Catatan sisa risiko #2: situs dari hasil WebSearch dianggap tepercaya, dan path pendek tanpa query ke situs itu masih bisa membawa sedikit data; gerbang persetujuan `GithubBuild` tetap menjadi pertahanan utama.

## Belum dikerjakan / perlu tindakan pemilik
1. #9: pin SHA action CI dan `distributionSha256Sum` (butuh jaringan): jalankan `scripts/pin-actions.sh` dan `scripts/pin-gradle-wrapper.sh`; lint CI masih `continue-on-error`.
2. #11: scope `gmail.readonly` perlu verifikasi Google untuk distribusi luas; proyek OAuth berstatus Testing membuat refresh token kedaluwarsa 7 hari.
3. #12: `SecretBox` tanpa AAD (dinilai dapat diterima).
4. Daftar libur SLA TIDAK diisi di kode (sengaja, agar tidak menebak tanggal untuk tenggat hukum): agen harus mengirim `holidays` dari SKB resmi; tanpa itu hasilnya hanya batas bawah dan diberi peringatan.
5. Kompromi disengaja: setelah sesi tercemar, menulis berkas tes `src/test/**/*.kt` meminta persetujuan (CI mengeksekusinya). Bila terlalu mengganggu, hapus dua baris `src/test`/`src/androidtest` di `isBuildSensitivePath` (Agent.kt).
6. Sisa risiko #2: situs dari hasil WebSearch dianggap tepercaya; path pendek tanpa query ke situs itu masih bisa membawa sedikit data. Pertahanan utama tetap persetujuan `GithubBuild`.
7. SEMUA perubahan PATCH18 belum dikompilasi dan belum dites: jalankan `./gradlew testDebugUnitTest assembleRelease`, perbaiki galat kompilasi bila ada.

## Status perbaikan lanjutan (PATCH24 — Audit Menyeluruh & Pengerasan Presisi v85)
Seluruh 18 temuan baru dari audit mendalam lintas seluruh berkas sumber telah diperbaiki:
1. **`Llm.kt` & `ModelCatalog.kt`**: menonaktifkan redirect HTTP otomatis (`instanceFollowRedirects = false`), membatasi ukuran pembacaan respons HTTP/JSON (`readBoundedText`, maks. 8 MB) serta baris/peristiwa streaming SSE (`readSseLine`, `MAX_SSE_EVENT_CHARS`), dan menyamakan redaksi kredensial galat HTTP di `ModelScanner.list` memakai `httpErrorMessage`.
2. **`Agent.kt`, `SubAgent.kt`, `Models.kt`, `Tools.kt`, `ViewImages.kt`**: menutup celah pencucian taint (`taintedByExternal`) saat `TaskTool` (`withWeb = false`), `Grep`, atau `ViewImages` membaca berkas tak tepercaya di `uploads/`; menormalisasi path relatif (`normalizeRelPath`) dan memakai path kanonik sandbox sebelum pemeriksaan `isBuildSensitivePath`; mencakup direktori tes akar (`src/test/`, `src/androidTest/`) serta berkas tes `.java`; dan melindungi folder `draf/` dari penulisan/pengeditan/penghapusan langsung oleh model.
3. **`WebFetchGuard.kt` & `Agent.kt`**: memeriksa query string (`?...`) dan userinfo (`@`) pada `exfilRisk` termasuk untuk situs di `UNLIMITED_SITES` (`github.com`, `githubusercontent.com`), membuang bagian userinfo sebelum ekstraksi host di `WebFetchGuard.parse`, dan menyaring `userOnlyTextForTrust(task)` agar URL di balasan `Mythos:` terdahulu atau catatan otomatis `uploads/_catatan.md` tidak ikut ditandai tepercaya.
4. **`SensitiveDataGuard.kt` & `CleanText.kt`**: memperluas `escapeProtocolTags` (tanpa lookbehind berlebar variabel) dan `stripLeaks` untuk menangkap tag penutup `</function>`, pembungkus berawalan `<..._function_call>` / `<toolcall>`, serta token khusus penutup `<|/tool_name|>` dan `</|file_path|>`.
5. **`Web.kt` & `AttachmentText.kt`**: mengganti seluruh sisa regex `.*?` (`DOT_MATCHES_ALL`) pada `parseLiteResults`, `parseBingResults`, dan `extractOfficeText` (`.docx`, `.pptx`, `.xlsx`) dengan pemindai elemen linear `O(N)` (`findElements`, `findXmlElements`, `stripTags`).
6. **`GitHubActions.kt`**: menyaring log kegagalan CI melalui `redactSecrets` + `SensitiveDataGuard.sanitizeExternalContent`, mengecualikan `draf/` dan `uploads/web_docs/` dari push ke repositori, memperluas `isSecretFile` (`.key`, `.p8`, `.pypirc`, `.git-credentials`, `id_ecdsa`, `id_dsa`), dan memvalidasi host redirect log/artefak terhadap SSRF/host privat.
7. **`codex_app_server.js` & `TermuxLauncher.kt`**: mengabaikan event dari proses anak `codex` lama (`if (child !== mine) return;`) saat fallback `argTier`, serta membatasi ukuran buffer baris soket (`readLineLimited` 1 MB, `CodexLineSplitter` 4 MB, `inputBuffer` 8 MB).
8. **`mythos_form.js`, `BrowserAgentScreen.kt`, `Workspace.kt`**: mengecualikan `:not([type=password]):not([type=reset]):not([type=image])` pada `fillText`, meneruskan `action.label` ke `BrowserActionGuard.reasonForButton` pada mode otonom, mematikan `allowFileAccess`/`allowContentAccess`, dan mengaktifkan `blockNetworkLoads = true` pada `WebPreview` (`Workspace.kt`).
9. **`GoogleWorkspace.kt`, `CaseLedger.kt`, `EditMath.kt`, `ChatStore.kt`, `ProviderLogos.kt`, `AgentService.kt`, `MainActivity.kt`**: menambahkan `callTimeout` dan `followRedirects(false)` pada `OkHttpClient`, fallback ekstraksi `text/html` untuk email Gmail tanpa bagian `text/plain`, penjagaan urutan penanda `BEGIN_MARKER`/`END_MARKER` di `KASUS.md`, `toIntOrNull()` aman di `parsePageRanges`, sanitasi ID di `ChatStore`, pembacaan berbatas pada `ProviderLogos`, pelepasan `wakeLock` seketika saat `onTimeout`, dan pemberitahuan `consumeLastTimeout()` di `MainActivity.onResume`.
