# Laporan audit dan perbaikan Mythos v85

**Tanggal:** 16 November 2026
**Versi proyek:** 1.0.85 (versionCode 85)
**Jenis pemeriksaan:** audit statis kode, konfigurasi build/CI, alur Codex–Termux, sinkronisasi workspace, dan uji regresi yang dapat dijalankan pada lingkungan audit.

> **Pembaruan PATCH33 (16-11-2026, permintaan pemilik):** temuan A-01 dan A-02 untuk jalur Codex native SENGAJA DIBALIK. Codex native kini bawaan hidup dengan `approvalPolicy: 'never'` + `danger-full-access`, tanpa dialog persetujuan, dan Codex adalah satu-satunya jalur ke Termux. Bagian di bawah yang menyebut `on-request`, `workspace-write`, opt-in, bawaan mati, timeout 120 detik, atau migrasi `codex_native_safety_migrated_v32` adalah catatan historis dan tidak lagi mencerminkan kode. Temuan A-03 sampai A-09 tetap berlaku, dengan catatan: filter rahasia mirror tidak membatasi Codex native karena sandbox mati. Berkas `TermuxShell.kt` yang disebut di laporan tidak ada pada arsip ini.

## Ringkasan eksekutif

Audit menemukan beberapa jalur yang dapat memberi agen akses shell atau kredensial lokal tanpa persetujuan yang konsisten, kebijakan Codex native yang terlalu longgar, kelemahan pada pemilihan URL WebFetch sesudah konten eksternal masuk ke konteks, risiko symlink pada workspace Termux, dan konfigurasi signing release yang mengizinkan debug keystore. Perbaikan sudah diterapkan pada source.

**Temuan prioritas tinggi yang diperbaiki:**

1. (DIBALIK oleh PATCH33) Perbaikan awal menjadikan Codex native opt-in dengan `on-request` + `workspace-write`. Atas permintaan pemilik, native kini bawaan hidup dengan `never` + `danger-full-access`.
2. Jalur alat Termux tidak lagi memiliki pengecualian yang melewati dialog persetujuan untuk risiko `DANGEROUS`.
3. Berkas dan folder rahasia yang umum tidak lagi dimirror ke workspace Codex, tidak dapat ditulis balik melalui jalur mirror, dan pola rahasia lama yang dikenal dibersihkan dari workspace persisten sebelum sesi native.
4. WebFetch setelah konten eksternal masuk konteks kini mempercayai URL spesifik, bukan seluruh domain; host/path baru dan query string membutuhkan persetujuan, termasuk pada GitHub.
5. Workspace proyek yang berupa symlink atau memiliki komponen direktori symlink ditolak agar operasi mirror tidak keluar dari folder kerja.
6. (DIBALIK oleh PATCH33) Migrasi v33 menyalakan kembali native; setelah itu pilihan pengguna di Pengaturan dihormati.

Perbaikan tambahan: signing release tidak menggunakan debug keystore secara default; GitHub Actions dipatok ke commit SHA penuh; checksum distribusi Gradle ditambahkan; lint dijadikan gate CI; direktori sesi sementara Codex dibersihkan; dokumentasi lama yang tidak lagi sesuai diberi penanda supersesi.

**Status verifikasi:** uji runner JavaScript 6/6 lulus; pemeriksaan sintaks JavaScript lulus; `WebFetchGuard.kt` berhasil dikompilasi terpisah dan smoke test URL lulus; YAML workflow dapat diparse. Build Android dan suite tes Gradle/Kotlin penuh belum dapat diverifikasi karena unduhan Gradle 8.7 gagal pada DNS/jaringan dan Android SDK tidak tersedia. Uji browser lokal tidak dapat dijalankan karena Playwright/Chromium tidak tersedia. Jadi, source sudah diperbaiki, tetapi APK belum dibangun dan kelulusan build Android belum dapat diklaim.

## Cakupan

Arsip sumber yang diterima berisi **323 berkas**. Pemeriksaan mendalam memprioritaskan permukaan berisiko tinggi dan interaksinya:

- `app/src/main/assets/codex_app_server.js` dan `jstest/codex_runner.test.js`.
- `TermuxLauncher.kt`, `TermuxShell.kt`, `CodexAppServerClient.kt`, `Agent.kt`, `AgentViewModel.kt`, `Settings.kt`, dan UI pengaturan Codex.
- `WorkspaceMirror.kt`, `ProjectSandbox`, alur socket, penyalinan dan pengembalian berkas proyek.
- `WebFetchGuard.kt` dan gerbang persetujuan WebFetch di `Agent.kt`.
- `app/build.gradle.kts`, `gradle.properties`, Gradle wrapper, dan `.github/workflows/ci.yml`.
- Tes regresi terkait Codex native, Termux, workspace mirror, dan WebFetch; README, catatan perubahan, dan changelog.

Pemeriksaan ini adalah audit statis berbasis source dan pengujian yang dapat dijalankan, bukan penetration test perangkat Android atau sertifikasi keamanan formal. Beberapa status lama PATCH18/PATCH24 dicatat di dokumen audit terdahulu; dokumen ini memperbarui khususnya temuan Codex/Termux/workspace/CI yang diperiksa ulang pada tanggal di atas.

## Temuan dan perbaikan

### A-01 — Eksekusi Codex native dapat melewati persetujuan (Kritis) — DITERIMA PEMILIK (PATCH33)

**Keputusan pemilik:** akses penuh tanpa persetujuan dipertahankan karena Codex dipakai pemilik untuk membersihkan perangkatnya sendiri. Risiko yang diterima: prompt injection dari web/email yang dibaca Codex dapat menjalankan perintah di Termux tanpa konfirmasi. Rincian perbaikan di bawah adalah rancangan audit awal dan TIDAK aktif.

**Sebelum:** snapshot PATCH30 mengaktifkan native secara default dengan `approvalPolicy: never`, sandbox `danger-full-access`, dan menghapus mekanisme approval aplikasi. Akibatnya, perintah shell dan perubahan file dari Codex dapat berjalan tanpa persetujuan yang dapat dilihat pengguna.

**Perbaikan:**
- Native sekarang opt-in dan bawaan mati.
- `thread/start` dan `turn/start` menggunakan `approvalPolicy: 'on-request'` dan sandbox `workspace-write`.
- Permintaan `commandExecution` dan `fileChange` dikirim sebagai event approval ke aplikasi. Tidak ada keputusan otomatis `accept`.
- Jika native tidak memiliki socket aplikasi yang tervalidasi, permintaan ditolak. Jika pengguna tidak menjawab dalam 120 detik, permintaan ditolak.
- Permintaan approval paralel diserialkan oleh mutex; error callback diperlakukan sebagai penolakan.
- Tes runner mencakup persetujuan, penolakan, dan keadaan socket tidak tersedia.

**Migrasi upgrade:** karena versi lama pernah menyimpan `codex_native_exec=true`, mengubah default saja tidak mematikan preferensi lama. `SettingsStore.loadCodexNative()` kini menjalankan migrasi satu kali (`codex_native_safety_migrated_v32`) yang mereset nilai lama ke `false`; pengguna harus mengaktifkan ulang secara eksplisit.

### A-02 — Alat Termux pernah melewati gerbang persetujuan (Kritis) — DIBALIK UNTUK CODEX (PATCH33)

**Catatan:** model non-Codex tidak punya alat Termux sama sekali (`termuxExecutorOrNull()` selalu null). Untuk Codex native, tidak ada dialog persetujuan. Deskripsi di bawah adalah rancangan audit awal.

**Sebelum:** jalur `Termux` pada agen memiliki pengecualian khusus yang membiarkan perintah berjalan tanpa approval, termasuk pada mode `ACCEPT_EDITS`, sementara kelas risiko alat sudah ditandai `DANGEROUS`.

**Perbaikan:** cabang pengecualian dihapus. `Agent.kt` selalu meminta approval untuk `Risk.DANGEROUS`, atau untuk kondisi eksfiltrasi lain yang terdeteksi. Tes regresi memeriksa bahwa tidak ada lagi jalur `readOnlyTermux` yang melompati approval.

`TermuxShell.kt` juga memblokir sejumlah pola akses kredensial yang umum, termasuk path absolut Termux, dan menyamarkan pola rahasia umum dari hasil shell. Ini pertahanan berlapis, bukan parser shell lengkap atau sandbox OS.

### A-03 — Berkas rahasia dapat ikut disalin ke workspace Termux — DIPERBAIKI DENGAN BATASAN

**Sebelum:** mirror proyek dapat menyalin berkas biasa tanpa membedakan `.env`, `credentials.json`, key, atau folder kredensial. Berkas hasil kerja juga dapat kembali ditulis ke proyek melalui socket.

**Perbaikan:**
- Filter mirror mengecualikan direktori rahasia yang dikenal seperti `.codex/`, `.ssh/`, `.aws/`, `.gnupg/`, dan `.mythos_codex/`.
- Nama/pola file rahasia umum dikecualikan, termasuk `.env*`, `auth*.json`, `credentials*.json`, `client_secret*.json`, key SSH, sertifikat/kunci (`.pem`, `.key`, `.p8`, `.p12`, `.pfx`, `.jks`, `.keystore`, dan pola terkait), `local.properties`, serta `google-services.json`.
- Jalur write-back menolak path yang sama.
- Runner menghapus pola rahasia lama yang dikenal dari workspace persisten sebelum Codex native berjalan.
- Tes Kotlin workspace mirror dan tes runner memeriksa file rahasia yang dikirim, dikembalikan, dan tersisa dari versi lama.

**Batasan:** filter memakai pola nama dan direktori, bukan klasifikasi isi file. Rahasia yang disimpan dalam file bernama biasa mungkin tidak dikenali. Jangan menyimpan kredensial di proyek yang dipakai dengan native Codex; tetap gunakan hanya proyek tepercaya.

### A-04 — Symlink pada workspace dapat mengalihkan operasi ke luar folder kerja — DIPERBAIKI

**Sebelum:** runner memercayai `~/mythos-work/<id>` dan membentuk target file secara leksikal. Direktori proyek atau komponen subfolder yang berupa symlink dapat mengarahkan operasi ke lokasi lain.

**Perbaikan:** runner memverifikasi root workspace dan folder proyek dengan `lstat`/`realpath`, menolak root proyek symlink, dan memeriksa setiap komponen parent/target sebelum penulisan. Pembersihan sesi sementara juga memverifikasi bahwa target adalah direktori biasa langsung di root workspace.

**Regresi:** tes menyiapkan root proyek yang merupakan symlink ke folder luar, lalu memastikan sesi gagal tertutup, Codex palsu tidak dijalankan, dan `.env` pada target tidak dihapus. Tes lain memastikan penulisan melalui symlink subfolder tidak keluar dari workspace.

### A-05 — WebFetch setelah konten eksternal dapat mengirim data lewat path URL — DIPERBAIKI

**Sebelum:** setelah WebSearch atau sumber eksternal menandai sesi tercemar, hasil pencarian dapat membuat seluruh domain dipercaya. Pengecualian GitHub untuk URL tanpa query juga membuat path lain pada domain itu tidak selalu meminta persetujuan.

**Perbaikan:** `WebFetchGuard` kini mencatat URL spesifik dari teks pengguna/hasil pencarian dan URL spesifik yang berhasil dibuka. Setelah sesi tercemar, hanya URL yang sama yang dapat diulang tanpa approval. URL lain, query string, dan userinfo memerlukan persetujuan; tidak ada bypass khusus untuk domain GitHub. Path dipertahankan case-sensitive pada kunci URL dan host/port tidak dilebur menjadi satu.

**Regresi:** tes memverifikasi bahwa URL GitHub yang disebut di hasil pencarian boleh dibuka, tetapi file/path lain dan host `raw.githubusercontent.com` membutuhkan persetujuan; URL yang sudah dibuka boleh diulang, sedangkan path baru dan query baru tidak.

### A-06 — Release dapat ditandatangani dengan debug keystore — DIPERBAIKI

**Sebelum:** release signing memakai debug keystore sebagai jalur default melalui property konfigurasi.

**Perbaikan:** `useDebugKeystoreForRelease=false`. Signing release hanya dikonfigurasi ketika pemilik menyediakan `../release-keystore/keystore.properties`. Tanpa keystore rilis, artefak release tidak ditandatangani. Tidak ada keystore pribadi yang ditambahkan ke arsip.

### A-07 — Integritas build/CI belum dipatok dan lint non-blocking — DIPERBAIKI

**Perbaikan:**
- GitHub Actions dipatok ke commit SHA penuh, bukan tag yang dapat berpindah.
- `persist-credentials: false` digunakan pada checkout.
- `gradle-wrapper.properties` berisi SHA-256 resmi distribusi Gradle 8.7.
- CI menjalankan unit test, lint, debug build, kompilasi androidTest, dan release build; lint kini menjadi gate blocking.
- Playwright pada workflow form test diperbarui dan workflow memasang Chromium.

Validitas sintaks YAML diperiksa secara lokal. Workflow belum dijalankan di GitHub dalam audit ini.

### A-08 — Folder sementara Codex dapat tertinggal setelah proses berakhir — DIPERBAIKI

Chat tanpa proyek menggunakan folder `session-*` sementara di `~/mythos-work/`. Runner kini menjadwalkan pembersihan setelah proses selesai dan memiliki fallback bila proses anak tidak mengirim event `close`. Tes runner memastikan folder sesi tidak tertinggal setelah sesi palsu selesai.

### A-09 — Dokumentasi tidak sesuai dengan implementasi keamanan aktif — DIPERBAIKI

README, catatan perubahan, deliverables README, dan changelog v85 diperbarui. Dokumen PATCH25 dan audit 14 November diberi catatan bahwa isinya adalah snapshot historis dan sudah disupersesi PATCH32/audit terbaru.

## Status uji

| Pemeriksaan | Hasil | Catatan |
|---|---|---|
| `node --check app/src/main/assets/codex_app_server.js` | Lulus | Sintaks runner |
| `node --check jstest/codex_runner.test.js` | Lulus | Sintaks uji regresi |
| `node jstest/codex_runner.test.js` | **6/6 lulus** | Approval accept/decline, socket fail-closed, mode read-only, workspace secrets, sinkronisasi, dan symlink |
| Kompilasi terpisah `WebFetchGuard.kt` dengan `kotlinc` | Lulus | Syntax compilation file guard |
| Smoke test URL WebFetch | Lulus | URL tepat dipercaya; path lain/query baru meminta approval |
| Parse `.github/workflows/ci.yml` | Lulus | YAML dapat diparse |
| `./gradlew :app:testDebugUnitTest --no-daemon` | Terblokir | Wrapper perlu mengunduh Gradle 8.7; DNS/jaringan tidak tersedia (`UnknownHostException` pada `services.gradle.org`) |
| Android build/lint | Belum dijalankan | Android SDK tidak tersedia pada lingkungan audit |
| `node jstest/form.test.js` / `tools/test_form_js.py` | Belum dijalankan | Playwright/Chromium tidak tersedia lokal; workflow CI memasangnya |

Karena build Android belum dapat dilakukan, kemungkinan error kompilasi Kotlin/Android atau temuan lint baru belum dapat dieliminasi. Jalankan seluruh gate CI setelah source dibuka di mesin yang memiliki Android SDK dan akses unduh dependency.

## Risiko tersisa / tindakan pemilik

1. **Native Codex tanpa sandbox (keputusan pemilik).** Sandbox mati dan tidak ada dialog persetujuan, sehingga Codex dapat membaca dan menulis seluruh HOME Termux. Bagian berikut adalah catatan audit awal tentang `workspace-write`: **Native Codex bukan sandbox baca penuh.** `workspace-write` membatasi ruang lingkup penulisan yang didukung sandbox Codex, tetapi tidak memberi jaminan isolasi pembacaan seluruh HOME Termux. Perintah di dalam workspace dapat berjalan tanpa dialog per-perintah. Fitur dibuat opt-in, default OFF, dengan peringatan UI; aktifkan hanya untuk proyek/prompt tepercaya. Untuk jaminan lebih kuat dibutuhkan isolasi OS/container yang benar-benar didukung pada perangkat/Termux, bukan regex aplikasi.
2. **Penyaringan kredensial berbasis pola.** Nama file yang tidak umum atau file rahasia dengan nama generik dapat lolos dari filter mirror. Simpan kredensial di luar proyek dan jangan mengaktifkan native pada sumber yang tidak dipercaya.
3. **Guard shell Termux bukan parser bash.** Perintah yang diobfuscate, disusun ulang, memakai alias, encoding, atau program lain dapat melewati daftar pola. Persetujuan `DANGEROUS` tetap wajib, tetapi keputusan akhir yang salah dari pengguna tetap dapat menjalankan perintah. Jangan mengizinkan perintah yang tidak dipahami.
4. **Google OAuth Gmail.** Scope `gmail.readonly` merupakan scope terbatas yang dapat memerlukan proses verifikasi Google untuk distribusi luas. Bila proyek OAuth masih berstatus Testing, refresh token dapat memiliki masa berlaku terbatas (pada konfigurasi Google Testing umumnya 7 hari). Ini memerlukan tindakan pemilik Cloud Console dan verifikasi kebijakan Google.
5. **`SecretBox` belum memakai AAD.** Enkripsi AES-GCM menggunakan Android Keystore dan autentikasi GCM, tetapi tidak mengikat ciphertext ke nama field melalui Additional Authenticated Data. Penggantian memerlukan migrasi ciphertext lama. Risiko ini dicatat sebagai peningkatan kriptografi, bukan diubah tanpa migrasi data.
6. **Kalender hari libur SLA.** `CaseLedger` menerima daftar tanggal `holidays` dari pemanggil dan menampilkan peringatan bila daftar kosong. Daftar libur nasional/cuti bersama tidak ditanam permanen agar tanggal hukum tidak ditebak; pemilik/agen harus memasukkan daftar dari SKB resmi atau mengonfirmasi ke penyelenggara.
7. **Rilis belum dibangun.** Tidak ada APK release yang dapat dinyatakan valid/ditandatangani pada audit ini. Pemilik perlu memasang SDK, menjalankan CI, menyediakan keystore rilis, lalu memeriksa APK pada perangkat Android.

## Berkas utama yang berubah

- `app/src/main/assets/codex_app_server.js`
- `app/src/main/java/com/mythos/app/Settings.kt`
- `app/src/main/java/com/mythos/app/agent/Agent.kt`
- `app/src/main/java/com/mythos/app/agent/CodexAppServerClient.kt`
- `app/src/main/java/com/mythos/app/agent/TermuxLauncher.kt`
- `app/src/main/java/com/mythos/app/agent/TermuxShell.kt`
- `app/src/main/java/com/mythos/app/agent/WorkspaceMirror.kt`
- `app/src/main/java/com/mythos/app/agent/WebFetchGuard.kt`
- `app/src/main/java/com/mythos/app/ui/AgentViewModel.kt`
- `app/src/main/java/com/mythos/app/ui/CodexNativeRow.kt`
- `app/src/test/java/com/mythos/app/agent/CodexNativeTest.kt`
- `app/src/test/java/com/mythos/app/agent/TermuxShellTest.kt`
- `app/src/test/java/com/mythos/app/agent/WorkspaceMirrorTest.kt`
- `app/src/test/java/com/mythos/app/agent/WebFetchGuardTest.kt`
- `jstest/codex_runner.test.js`
- `app/build.gradle.kts`, `gradle.properties`, `gradle/wrapper/gradle-wrapper.properties`, `.github/workflows/ci.yml`
- `README.md`, `deliverables/README.txt`, `CATATAN-PERUBAHAN.txt`, dan changelog/audit terkait.

## Kesimpulan

Temuan keamanan yang dapat diperbaiki pada source telah diterapkan dan tes yang bisa berjalan di lingkungan audit lulus. Risiko tersisa yang paling penting adalah keterbatasan sandbox native di Termux dan ketergantungan pada daftar pola untuk mengidentifikasi file rahasia. **Belum ada klaim bahwa APK berhasil dikompilasi atau seluruh suite Android lulus**; langkah final wajib adalah menjalankan workflow CI pada lingkungan Android/Gradle yang lengkap, memperbaiki setiap hasil lint/compile/test yang muncul, kemudian menguji native Codex di perangkat Termux nyata.
